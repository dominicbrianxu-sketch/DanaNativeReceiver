# DANA Native Receiver V4 — AUTO CLICK

Receiver ini menyinkronkan hosting → ntfy → HP tanpa Termux.

## Fitur
- Foreground Service `remoteMessaging`.
- Auto-reconnect ke ntfy.
- Auto-start setelah boot dan update aplikasi jika receiver sebelumnya aktif.
- Percobaan buka DANA langsung.
- Fallback notification dengan tombol `BUKA DANA`.
- **Auto Click:** Accessibility Service opsional yang mencoba menekan tombol `BUKA DANA` pada notifikasi secara otomatis.

## Setup
1. Install APK.
2. Masukkan Server, Topic, dan Token yang sama dengan hosting.
3. Tekan **Simpan & Aktifkan Receiver**.
4. Tekan **Aktifkan Auto Klik BUKA DANA**.
5. Di Pengaturan Aksesibilitas Android, aktifkan **DANA Auto Click**.
6. Kembali ke aplikasi dan pastikan `Auto Klik: AKTIF ✓`.
7. Pastikan notifikasi aplikasi diizinkan dan baterai disetel **Tidak ada pembatasan**.

## Alur
Hosting → ntfy → Receiver → notifikasi DANA → Accessibility Service → klik `BUKA DANA` → DANA.

## Catatan
Accessibility Service hanya aktif setelah pengguna mengaktifkannya di pengaturan Android. Android/vendor dapat membatasi atau menyajikan UI notifikasi secara berbeda, sehingga auto-click tidak dapat dijamin 100% pada semua perangkat.

Jangan membagikan Topic/Token.
