# DANA Native Receiver — AUTO OPEN V2

Versi ini mempertahankan sinkronisasi hosting → ntfy → HP tanpa Termux.

## Perubahan penting
- Receiver tetap memakai Foreground Service `remoteMessaging` agar cocok untuk listener pesan yang berjalan lama.
- Saat trigger DANA diterima, aplikasi mencoba `startActivity()` ke package `id.dana`.
- Jika Android mengizinkan background activity launch, DANA dapat langsung dibawa ke depan.
- Jika Android menahan pembukaan dari background, receiver otomatis membuat notifikasi prioritas tinggi dengan tombol **BUKA DANA**. Tombol tersebut memakai `PendingIntent` langsung ke aplikasi DANA, sehingga tidak menggunakan notification trampoline.
- Log membedakan `ActivityNotFoundException`, `SecurityException`, dan error lainnya.

## Catatan Android
Android 10+ membatasi aplikasi background untuk membawa aplikasi lain ke foreground, dan Android 14/15 memperketat aturan tersebut. Karena itu aplikasi normal tidak dapat menjamin pembukaan DANA 100% diam-diam dari background. Jalur yang paling kompatibel adalah notifikasi + PendingIntent ketika OS menolak pembukaan otomatis.

## Instalasi
1. Buka project ini di Android Studio.
2. Build APK.
3. Instal APK di HP.
4. Masukkan Server, Topic, dan Token yang sama dengan konfigurasi hosting.
5. Tekan **Simpan & Aktifkan Receiver**.
6. Pastikan notifikasi receiver diizinkan.
7. Untuk pengujian, gunakan tombol **Tes Buka Aplikasi DANA**.

## Penting
- Tidak membutuhkan Termux.
- Jangan membagikan Topic/Token ke orang lain.
- Jangan mengandalkan notifikasi `DANA dipanggil otomatis` sebagai bukti bahwa DANA benar-benar foreground; bukti sebenarnya adalah aplikasi DANA tampil.
