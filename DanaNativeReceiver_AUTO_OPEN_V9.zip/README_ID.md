# DANA Native Receiver V6 — SAFE BACKGROUND AUTO-CLAIM

V6 memprioritaskan satu hal: proses receiver/claim tidak merebut layar dari aplikasi yang sedang digunakan.

## Prinsip utama
- Receiver ntfy tetap berjalan sebagai Foreground Service `remoteMessaging`.
- Auto-reconnect tetap aktif.
- Accessibility Service tetap user-enabled dan akan siap kembali saat Android melakukan rebind.
- Trigger DANA yang valid disimpan sebagai `pending_dana_url`.
- **V6 tidak memanggil `startActivity()` ke DANA dari background.**
- **V6 tidak membuka notification shade secara otomatis.**
- Accessibility hanya melakukan `ACTION_CLICK` / gesture jika node yang dituju berasal dari package `id.dana`.
- Jika pengguna sedang berada di WhatsApp/Telegram/Chrome/game/aplikasi lain, V6 tidak mengirim tap ke layar tersebut.
- Saat UI DANA sudah terlihat, V6 mencoba tombol target secara otomatis.

## Batasan Android yang penting
Android tidak menyediakan API umum untuk menjalankan UI interaksi aplikasi pihak ketiga sepenuhnya "off-screen" tanpa menjadikannya UI yang sedang aktif. `dispatchGesture()` adalah gesture nyata pada touch screen. Karena itu V6 sengaja memilih mode aman: **tidak mengganggu aplikasi yang sedang dipakai** daripada memaksa DANA ke foreground.

## Setup
1. Install APK.
2. Masukkan Server, Topic, dan Token yang sama dengan notifier.py.
3. Tekan **Simpan & Aktifkan Receiver**.
4. Tekan **Aktifkan Auto Klik DANA**.
5. Aktifkan **DANA Auto Click** di Pengaturan Aksesibilitas Android.
6. Izinkan notifikasi.
7. Set baterai ke **Tidak ada pembatasan** jika tersedia.

## Alur V6
Hosting → ntfy → Receiver → simpan pending claim → tanpa merebut layar → jika UI DANA terlihat → Accessibility klik target.

## Catatan
- Accessibility Service harus diaktifkan manual oleh pengguna.
- Android/OEM dapat menghentikan atau membatasi service.
- Jika target harus diklaim ketika aplikasi lain tetap tampil di depan, Android tidak menyediakan cara umum yang aman untuk melakukan tap UI DANA yang tidak sedang aktif tanpa mengganggu aplikasi tersebut.
- Jangan membagikan Topic/Token.
