package id.varino.danareceiver;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * V6 SAFE BACKGROUND AUTO CLICK.
 *
 * Important design rule: never dispatch a tap while another app is in the
 * foreground. This prevents the receiver from stealing the user's screen.
 * The service may auto-click DANA UI only when the current accessible window
 * belongs to id.dana. A valid trigger is stored by NtfyService and consumed
 * when DANA is actually visible.
 */
public class DanaAutoClickAccessibilityService extends AccessibilityService {
    public static final String TAG = "DanaAutoClickV9";
    private static final String DANA_PACKAGE = "id.dana";
    private static final String BUTTON_TEXT = "BUKA DANA";
    private static final String TRIGGER_TEXT = "DANA Kaget terdeteksi";
    private static final long RETRY_WINDOW_MS = 15000L;
    private static final long CLAIM_CONFIRM_WINDOW_MS = 12000L;
    private static final int RESULT_NOTIFICATION_ID = 2002;
    private static final String RESULT_CHANNEL = "dana_result";
    private static final String[] SUCCESS_TEXTS = {
            "dana kaget berhasil",
            "berhasil diklaim",
            "berhasil menerima",
            "kamu mendapatkan",
            "uang berhasil diterima",
            "dana kaget masuk"
    };
    private static final String[] FAILURE_TEXTS = {
            "dana kaget sudah habis",
            "dana kaget telah habis",
            "sudah diambil",
            "sudah diklaim",
            "gagal",
            "tidak berhasil",
            "kuota habis",
            "coba lagi"
    };

    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean armed = false;
    private long armedAt = 0L;
    private boolean clickInProgress = false;
    private boolean awaitingClaimResult = false;
    private boolean danaUiNotified = false;
    private long clickedAt = 0L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                | AccessibilityEvent.TYPE_VIEW_CLICKED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 50;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.packageNames = null;
        setServiceInfo(info);
        armed = hasPendingClaim();
        clickInProgress = false;
        danaUiNotified = false;
        Log.i(TAG, "V6 Accessibility aktif. Non-disruptive background mode siap.");
        if (armed) scheduleRetries();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        String text = eventText(event);

        if (DANA_PACKAGE.equals(pkg) && hasPendingClaim() && !danaUiNotified) {
            danaUiNotified = true;
            showResultNotification("📱 UI DANA terdeteksi. Receiver siap memproses DANA Kaget.", false);
            Log.i(TAG, "UI DANA terdeteksi untuk pending claim.");
        }

        if (DANA_PACKAGE.equals(pkg) && awaitingClaimResult) {
            String normalized = text == null ? "" : text.toLowerCase();
            if (containsAny(normalized, SUCCESS_TEXTS)) {
                claimConfirmed(true, text);
                return;
            }
            if (containsAny(normalized, FAILURE_TEXTS)) {
                claimConfirmed(false, text);
                return;
            }
            checkDanaRootForClaimResult();
            if (awaitingClaimResult && clickedAt > 0L && System.currentTimeMillis() - clickedAt > CLAIM_CONFIRM_WINDOW_MS) {
                claimNotConfirmed();
                return;
            }
        }

        if (event.getEventType() == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                && getPackageName().equals(pkg)
                && (containsIgnoreCase(text, TRIGGER_TEXT) || containsIgnoreCase(text, BUTTON_TEXT))) {
            armed = hasPendingClaim();
            if (armed) {
                Log.i(TAG, "Trigger valid. Menunggu/menangani UI DANA tanpa mengganggu aplikasi lain.");
                scheduleRetries();
            }
            return;
        }

        if (hasPendingClaim()) armed = true;
        if (armed && DANA_PACKAGE.equals(pkg)) tryClickDanaButton();
    }

    private String eventText(AccessibilityEvent event) {
        StringBuilder sb = new StringBuilder();
        for (CharSequence t : event.getText()) if (t != null) sb.append(t).append(' ');
        if (event.getContentDescription() != null) sb.append(event.getContentDescription());
        return sb.toString();
    }

    private boolean containsIgnoreCase(String haystack, String needle) {
        return haystack != null && needle != null
                && haystack.toLowerCase().contains(needle.toLowerCase());
    }

    private boolean hasPendingClaim() {
        return getSharedPreferences("dana_receiver", MODE_PRIVATE)
                .getString("pending_dana_url", "").trim().length() > 0;
    }

    private void scheduleRetries() {
        handler.removeCallbacksAndMessages(null);
        long[] delays = {0, 100, 250, 500, 900, 1500, 2500, 4000, 6000, 8000, 10000, 12000, 15000};
        for (long delay : delays) handler.postDelayed(this::tryClickDanaButton, delay);
    }

    private void tryClickDanaButton() {
        if (!armed || clickInProgress || !hasPendingClaim()) return;
        if (System.currentTimeMillis() - armedAt > RETRY_WINDOW_MS && armedAt != 0L) {
            armed = false;
            Log.i(TAG, "Menunggu UI DANA selesai; tidak ada tap ke aplikasi lain.");
            return;
        }

        AccessibilityNodeInfo target = findButtonOnlyInDanaWindows();
        if (target == null) {
            // Deliberately do NOT open notification shade and do NOT launch DANA.
            // Doing either could take focus from the user's current application.
            if (armedAt == 0L) armedAt = System.currentTimeMillis();
            return;
        }

        clickInProgress = true;
        boolean clicked = clickNode(target);
        if (clicked) {
            try { target.recycle(); } catch (Exception ignored) {}
            markClickedAndWaitForClaimResult();
            return;
        }

        android.graphics.Rect bounds = new android.graphics.Rect();
        target.getBoundsInScreen(bounds);
        try { target.recycle(); } catch (Exception ignored) {}

        if (!bounds.isEmpty()) {
            tapCenter(bounds);
        } else {
            clickInProgress = false;
        }
    }

    private AccessibilityNodeInfo findButtonOnlyInDanaWindows() {
        List<AccessibilityNodeInfo> roots = new ArrayList<>();
        try {
            AccessibilityNodeInfo active = getRootInActiveWindow();
            if (active != null) roots.add(active);
        } catch (Exception ignored) {}

        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo w : windows) {
                    if (w == null) continue;
                    CharSequence title = w.getTitle();
                    // Window package is not exposed uniformly on all Android/OEM versions;
                    // node package checks below provide the actual safety gate.
                    try {
                        AccessibilityNodeInfo root = w.getRoot();
                        if (root != null) roots.add(root);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "getWindows gagal: " + e.getMessage());
        }

        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo root : roots) {
            if (root == null) continue;
            if (!isFromDana(root)) continue;
            found = findButton(root);
            if (found == null) found = findButtonRecursive(root);
            if (found != null) break;
        }

        for (AccessibilityNodeInfo root : roots) {
            if (root != null && root != found) {
                try { root.recycle(); } catch (Exception ignored) {}
            }
        }
        return found;
    }

    private boolean isFromDana(AccessibilityNodeInfo node) {
        CharSequence p = node.getPackageName();
        return p != null && DANA_PACKAGE.equals(p.toString());
    }

    private AccessibilityNodeInfo findButton(AccessibilityNodeInfo root) {
        try {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(BUTTON_TEXT);
            if (nodes != null) {
                for (AccessibilityNodeInfo n : nodes) {
                    if (n != null && isFromDana(n) && isUseful(n)) return n;
                    if (n != null) try { n.recycle(); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private AccessibilityNodeInfo findButtonRecursive(AccessibilityNodeInfo node) {
        if (node == null || !isFromDana(node)) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        String s = t != null ? t.toString() : (d != null ? d.toString() : "");
        if (containsIgnoreCase(s, BUTTON_TEXT) && isUseful(node)) return node;

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findButtonRecursive(child);
            if (found != null) return found;
            if (child != null) try { child.recycle(); } catch (Exception ignored) {}
        }
        return null;
    }

    private boolean isUseful(AccessibilityNodeInfo node) {
        if (node == null || !isFromDana(node)) return false;
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        String value = text != null ? text.toString() : (desc != null ? desc.toString() : "");
        return containsIgnoreCase(value, BUTTON_TEXT) || node.isClickable();
    }

    private boolean clickNode(AccessibilityNodeInfo node) {
        try {
            if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        } catch (Exception ignored) {}

        AccessibilityNodeInfo parent = null;
        try { parent = node.getParent(); } catch (Exception ignored) {}
        for (int i = 0; i < 8 && parent != null; i++) {
            try {
                if (isFromDana(parent) && parent.isClickable()
                        && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    parent.recycle();
                    return true;
                }
                AccessibilityNodeInfo next = parent.getParent();
                parent.recycle();
                parent = next;
            } catch (Exception e) {
                try { parent.recycle(); } catch (Exception ignored) {}
                break;
            }
        }
        return false;
    }

    private void tapCenter(android.graphics.Rect bounds) {
        float x = bounds.centerX();
        float y = bounds.centerY();
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 80);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                Log.i(TAG, "Gesture DANA selesai. Menunggu konfirmasi hasil claim.");
                markClickedAndWaitForClaimResult();
            }
            @Override public void onCancelled(GestureDescription g) {
                clickInProgress = false;
                Log.w(TAG, "Gesture DANA dibatalkan.");
            }
        }, handler);
        if (!dispatched) clickInProgress = false;
    }

    private void markClickedAndWaitForClaimResult() {
        clickInProgress = false;
        awaitingClaimResult = true;
        clickedAt = System.currentTimeMillis();
        showResultNotification("Tombol DANA tertekan. Menunggu konfirmasi claim...", false);
        Log.i(TAG, "Tombol DANA berhasil ditekan; menunggu UI konfirmasi claim.");
        pollClaimResult();
        handler.postDelayed(() -> {
            if (awaitingClaimResult && clickedAt == 0L) return;
            if (awaitingClaimResult && System.currentTimeMillis() - clickedAt >= CLAIM_CONFIRM_WINDOW_MS) {
                claimNotConfirmed();
            }
        }, CLAIM_CONFIRM_WINDOW_MS + 250L);
    }

    private void pollClaimResult() {
        if (!awaitingClaimResult) return;
        checkDanaRootForClaimResult();
        if (awaitingClaimResult && System.currentTimeMillis() - clickedAt < CLAIM_CONFIRM_WINDOW_MS) {
            handler.postDelayed(this::pollClaimResult, 500L);
        }
    }

    private void checkDanaRootForClaimResult() {
        if (!awaitingClaimResult) return;
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !isFromDana(root)) return;
            String allText = collectNodeText(root).toLowerCase();
            if (containsAny(allText, SUCCESS_TEXTS)) {
                claimConfirmed(true, allText);
            } else if (containsAny(allText, FAILURE_TEXTS)) {
                claimConfirmed(false, allText);
            }
            try { root.recycle(); } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    private String collectNodeText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null) sb.append(t).append(' ');
        if (d != null) sb.append(d).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = null;
            try { child = node.getChild(i); } catch (Exception ignored) {}
            if (child != null) {
                sb.append(collectNodeText(child)).append(' ');
                try { child.recycle(); } catch (Exception ignored) {}
            }
        }
        return sb.toString();
    }

    private void claimConfirmed(boolean success, String uiText) {
        String url = getSharedPreferences("dana_receiver", MODE_PRIVATE)
                .getString("pending_dana_url", "").trim();
        getSharedPreferences("dana_receiver", MODE_PRIVATE).edit()
                .remove("pending_dana_url")
                .apply();
        awaitingClaimResult = false;
        armed = false;
        clickInProgress = false;
        danaUiNotified = false;
        armedAt = 0L;
        clickedAt = 0L;
        handler.removeCallbacksAndMessages(null);

        if (success) {
            showResultNotification("✅ CLAIM DANA KAGET BERHASIL dikonfirmasi oleh UI DANA.", false);
            Log.i(TAG, "CLAIM DANA BERHASIL dikonfirmasi: " + uiText);
        } else {
            showResultNotification("❌ CLAIM DANA KAGET GAGAL / tidak dapat diambil.", false);
            Log.i(TAG, "CLAIM DANA gagal: " + uiText);
        }
    }

    private void claimNotConfirmed() {
        awaitingClaimResult = false;
        clickInProgress = false;
        armed = false;
        danaUiNotified = false;
        armedAt = 0L;
        clickedAt = 0L;
        handler.removeCallbacksAndMessages(null);
        showResultNotification("⚠️ Tombol sudah ditekan, tetapi hasil claim belum bisa dikonfirmasi dari UI DANA.", false);
        Log.w(TAG, "Claim belum terkonfirmasi dari UI DANA; pending URL dipertahankan untuk pemeriksaan manual.");
    }

    private boolean containsAny(String text, String[] candidates) {
        if (text == null) return false;
        for (String candidate : candidates) {
            if (text.contains(candidate)) return true;
        }
        return false;
    }

    private void showResultNotification(String text, boolean keepPending) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                NotificationChannel ch = new NotificationChannel(
                        RESULT_CHANNEL, "Hasil DANA Kaget", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }

            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 2002, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, RESULT_CHANNEL)
                    : new Notification.Builder(this);
            Notification n = b.setContentTitle("DANA Native Receiver")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_STATUS)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .build();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(RESULT_NOTIFICATION_ID, n);
        } catch (Exception e) {
            Log.e(TAG, "Gagal membuat notifikasi hasil claim", e);
        }
    }

    @Override public void onInterrupt() {
        armed = false;
        clickInProgress = false;
        awaitingClaimResult = false;
        clickedAt = 0L;
        Log.i(TAG, "Accessibility diinterupsi; menunggu reconnect sistem.");
    }

    public static boolean isEnabled(android.content.Context context) {
        String enabled = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        String target = context.getPackageName() + "/" + DanaAutoClickAccessibilityService.class.getName();
        for (String item : enabled.split(":")) if (target.equalsIgnoreCase(item)) return true;
        return false;
    }
}
