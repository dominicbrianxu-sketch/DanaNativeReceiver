# DANA Native Receiver — sinkron dengan notifier.py

## Arsitektur
Hosting menjalankan `notifier.py`.
HP menjalankan aplikasi Android ini.
Keduanya memakai format trigger yang sama:

- Server: `https://ntfy.sh` (atau server yang Anda set di hosting)
- Topic: `DANA_REMOTE_NTFY_TOPIC`
- Token: `DANA_REMOTE_TOKEN`
- Payload JSON: `{"token":"...","url":"https://link.dana.id/danakaget?c=..."}`

Konfigurasi yang sama di `notifier.py`:
`DANA_REMOTE_ENABLED`, `DANA_REMOTE_NTFY_SERVER`,
`DANA_REMOTE_NTFY_TOPIC`, `DANA_REMOTE_TOKEN`.

## HP
1. Build/install aplikasi ini.
2. Buka aplikasi.
3. Isi Server, Topic, dan Token **persis sama** dengan environment variable di hosting.
4. Tekan **Simpan & Aktifkan Receiver**.
5. Izinkan notifikasi.
6. Jangan paksa-stop aplikasi. Android dapat membatasi proses latar belakang; jika HP punya pengaturan battery optimization, izinkan aplikasi berjalan tanpa pembatasan.

## Catatan penting
Aplikasi ini tidak memakai Termux dan tidak login Telegram.
Saat trigger valid diterima, aplikasi mencoba:
`ACTION_VIEW` dengan package `id.dana`.

Android versi baru dapat membatasi pembukaan Activity secara otomatis dari proses latar belakang. Jika sistem Android menolak, receiver tetap menerima trigger dan menampilkan status/notifikasi, tetapi pembukaan DANA harus dilakukan melalui interaksi pengguna.

## Hosting
Tidak perlu mengubah format payload DANA yang sudah ada. `notifier.py` yang memakai:
`POST {server}/{topic}` dengan JSON `{token,url,ts}` sudah kompatibel dengan aplikasi ini.

Jangan masukkan token rahasia ke source code atau upload publik.
