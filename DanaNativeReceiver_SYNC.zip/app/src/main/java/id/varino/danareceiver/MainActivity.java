package id.varino.danareceiver;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREFS = "dana_receiver";
    private EditText server, topic, token;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("DANA Native Receiver");
        title.setTextSize(24);
        box.addView(title);

        TextView info = new TextView(this);
        info.setText("\nSinkron dengan notifier.py di hosting.\n" +
                "Receiver ini tidak memakai Termux. Biarkan layanan aktif agar trigger ntfy dapat diterima.\n");
        box.addView(info);

        server = field("Server ntfy", p.getString("server", "https://ntfy.sh"));
        topic = field("Topic", p.getString("topic", ""));
        token = field("Token", p.getString("token", ""));
        token.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        box.addView(server);
        box.addView(topic);
        box.addView(token);

        Button saveStart = new Button(this);
        saveStart.setText("Simpan & Aktifkan Receiver");
        box.addView(saveStart);

        Button stop = new Button(this);
        stop.setText("Matikan Receiver");
        box.addView(stop);

        Button testDana = new Button(this);
        testDana.setText("Tes Buka Aplikasi DANA");
        box.addView(testDana);

        status = new TextView(this);
        status.setText("\nStatus: belum aktif");
        box.addView(status);

        saveStart.setOnClickListener(v -> {
            String s = server.getText().toString().trim();
            String t = topic.getText().toString().trim();
            String k = token.getText().toString().trim();

            p.edit().putString("server", s).putString("topic", t).putString("token", k).apply();

            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
            }

            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            status.setText("\nStatus: receiver diaktifkan.");
        });

        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_STOP);
            startService(i);
            status.setText("\nStatus: receiver dimatikan.");
        });

        testDana.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://link.dana.id/danakaget?c=TEST"));
            i.setPackage("id.dana");
            try {
                startActivity(i);
                status.setText("\nStatus: perintah membuka aplikasi DANA dikirim.");
            } catch (Exception e) {
                status.setText("\nStatus: aplikasi DANA tidak ditemukan/Android menolak pembukaan.");
            }
        });

        setContentView(box);
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }
}
