package id.varino.danareceiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

public class NtfyService extends Service {
    public static final String ACTION_START = "id.varino.danareceiver.START";
    public static final String ACTION_STOP = "id.varino.danareceiver.STOP";

    private static final String PREFS = "dana_receiver";
    private static final String CHANNEL = "dana_receiver";
    private static final int NOTIF_ID = 1001;
    private static final Pattern DANA =
            Pattern.compile("^https://link\\.dana\\.id/danakaget\\?c=[^\\s]+$");

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean running = false;
    private final Set<String> handled = new HashSet<>();

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            running = false;
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIF_ID, notification("Mendengarkan trigger DANA..."));
        if (!running) {
            running = true;
            executor.execute(this::listenLoop);
        }
        return START_STICKY;
    }

    private void listenLoop() {
        long backoff = 2000;
        while (running) {
            HttpURLConnection c = null;
            try {
                SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
                String server = p.getString("server", "https://ntfy.sh").trim().replaceAll("/+$", "");
                String topic = p.getString("topic", "").trim();

                if (topic.isEmpty()) {
                    updateNotification("Topic belum diisi.");
                    Thread.sleep(5000);
                    continue;
                }

                String url = server + "/" + Uri.encode(topic) + "/json";
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(90000);
                c.setRequestProperty("Accept", "application/json");
                c.connect();

                if (c.getResponseCode() != 200) {
                    throw new Exception("HTTP " + c.getResponseCode());
                }

                backoff = 2000;
                updateNotification("Terhubung ke ntfy: " + topic);

                InputStream in = c.getInputStream();
                BufferedReader r = new BufferedReader(
                        new InputStreamReader(in, StandardCharsets.UTF_8));

                String line;
                while (running && (line = r.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    handleEvent(line);
                }
            } catch (Exception e) {
                if (running) {
                    updateNotification("Koneksi putus, mencoba lagi...");
                    try { Thread.sleep(backoff); } catch (InterruptedException ignored) {}
                    backoff = Math.min(backoff * 2, 60000);
                }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private void handleEvent(String line) {
        try {
            JSONObject evt = new JSONObject(line);
            if (!"message".equals(evt.optString("event"))) return;

            String raw = evt.optString("message", "");
            JSONObject data;
            try {
                data = new JSONObject(raw);
            } catch (Exception e) {
                return;
            }

            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            String expected = p.getString("token", "");
            String got = data.optString("token", "");
            String url = data.optString("url", "");

            if (!expected.isEmpty() && !expected.equals(got)) {
                updateNotification("Trigger ditolak: token tidak cocok.");
                return;
            }
            if (expected.isEmpty()) {
                updateNotification("PERINGATAN: token kosong.");
            }

            if (!DANA.matcher(url).matches()) {
                updateNotification("Trigger ditolak: URL bukan DANA Kaget.");
                return;
            }

            String dedup = evt.optString("id", "") + "|" + url;
            synchronized (handled) {
                if (handled.contains(dedup)) return;
                handled.add(dedup);
                if (handled.size() > 200) handled.clear();
            }

            updateNotification("Trigger DANA diterima. Membuka aplikasi...");
            openDana(url);
        } catch (Exception ignored) {
        }
    }

    private void openDana(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setPackage("id.dana");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            showResultNotification("Trigger DANA diterima — perintah buka DANA dikirim.");
        } catch (Exception e) {
            showResultNotification("Gagal membuka aplikasi DANA. Pastikan DANA terpasang.");
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setContentTitle("DANA Native Receiver")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void showResultNotification(String text) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(1002, notification(text));
    }

    private void updateNotification(String text) {
        if (!running) return;
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, notification(text));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "DANA Receiver", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        running = false;
        executor.shutdownNow();
        super.onDestroy();
    }
}
