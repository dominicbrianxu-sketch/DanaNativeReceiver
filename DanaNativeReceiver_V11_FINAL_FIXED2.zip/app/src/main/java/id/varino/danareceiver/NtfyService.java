package id.varino.danareceiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

public class NtfyService extends Service {
    public static final String ACTION_START = "id.varino.danareceiver.START";
    public static final String ACTION_STOP = "id.varino.danareceiver.STOP";

    private static final String TAG = "DanaReceiver";
    private static final String PREFS = "dana_receiver";
    private static final String CHANNEL = "dana_receiver";
    private static final String DANA_CHANNEL = "dana_trigger";
    private static final int NOTIF_ID = 1001;
    private static final int RESULT_ID = 1002;
    private static final long URL_DEDUP_MS = 20_000L;
    private static final Pattern DANA =
            Pattern.compile("^https://link\\.dana\\.id/danakaget\\?c=[^\\s]+$");

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean running = false;
    private final Set<String> handledEvents = new HashSet<>();
    private final Map<String, Long> handledUrls = new HashMap<>();

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        Log.i(TAG, "Service dibuat");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            running = false;
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("enabled", false);
        if (!enabled) {
            Log.i(TAG, "Service dipanggil tetapi receiver belum diaktifkan.");
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            Notification n = notification("Mendengarkan trigger DANA...");
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal startForeground", e);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!running) {
            running = true;
            executor.execute(this::listenLoop);
        }
        return START_STICKY;
    }

    private void listenLoop() {
        long backoff = 2000;
        while (running) {
            HttpURLConnection c = null;
            try {
                SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
                if (!p.getBoolean("enabled", false)) {
                    Log.i(TAG, "Receiver dinonaktifkan; menghentikan listen loop.");
                    running = false;
                    stopForeground(true);
                    stopSelf();
                    return;
                }
                String server = p.getString("server", "https://ntfy.sh").trim().replaceAll("/+$", "");
                String topic = p.getString("topic", "").trim();

                if (topic.isEmpty()) {
                    updateNotification("Topic belum diisi.");
                    Thread.sleep(5000);
                    continue;
                }

                String url = server + "/" + Uri.encode(topic) + "/json";
                Log.i(TAG, "Menghubungkan ke ntfy: " + server + "/" + topic + "/json");
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(90000);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("Cache-Control", "no-cache");
                c.setRequestProperty("Connection", "keep-alive");
                c.connect();

                int code = c.getResponseCode();
                if (code != 200) {
                    throw new Exception("HTTP " + code);
                }

                backoff = 2000;
                updateNotification("Terhubung ke ntfy: " + topic);

                InputStream in = c.getInputStream();
                BufferedReader r = new BufferedReader(
                        new InputStreamReader(in, StandardCharsets.UTF_8));

                String line;
                while (running && (line = r.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    handleEvent(line);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Koneksi ntfy gagal", e);
                if (running) {
                    updateNotification("Koneksi ntfy putus. Auto-reconnect aktif...");
                    try { Thread.sleep(backoff); } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                    backoff = Math.min(backoff * 2, 60000);
                }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private void handleEvent(String line) {
        try {
            JSONObject evt = new JSONObject(line);
            String event = evt.optString("event", "");
            if (!"message".equals(event)) return;

            String raw = evt.optString("message", "");
            JSONObject data;
            try {
                data = new JSONObject(raw);
            } catch (Exception e) {
                Log.w(TAG, "Pesan ntfy bukan JSON payload DANA: " + raw);
                updateNotification("Trigger ditolak: format payload tidak valid.");
                return;
            }

            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            String expected = p.getString("token", "").trim();
            String got = data.optString("token", "").trim();
            String url = data.optString("url", "").trim();

            // Token wajib cocok. Jangan menerima trigger tanpa token.
            if (expected.isEmpty()) {
                Log.e(TAG, "Token receiver kosong; trigger ditolak demi keamanan.");
                updateNotification("Trigger ditolak: token receiver kosong.");
                return;
            }
            if (!expected.equals(got)) {
                Log.w(TAG, "Trigger ditolak: token tidak cocok.");
                updateNotification("Trigger ditolak: token tidak cocok.");
                return;
            }

            if (!DANA.matcher(url).matches()) {
                Log.w(TAG, "Trigger ditolak: URL bukan DANA Kaget: " + url);
                updateNotification("Trigger ditolak: URL bukan DANA Kaget.");
                return;
            }

            String eventId = evt.optString("id", "");
            String dedup = eventId + "|" + url;
            long now = System.currentTimeMillis();
            synchronized (handledEvents) {
                Long lastUrl = handledUrls.get(url);
                if ((lastUrl != null && now - lastUrl < URL_DEDUP_MS) || handledEvents.contains(dedup)) {
                    Log.i(TAG, "Trigger duplikat diabaikan: " + url);
                    return;
                }
                handledEvents.add(dedup);
                handledUrls.put(url, now);
                if (handledEvents.size() > 500) handledEvents.clear();
                if (handledUrls.size() > 200) handledUrls.clear();
            }

            Log.i(TAG, "Trigger DANA valid diterima: " + url);
            updateNotification("Trigger DANA diterima. Mencoba membuka UI DANA...");
            openDana(url);
        } catch (Exception e) {
            Log.e(TAG, "Error memproses event ntfy", e);
            updateNotification("Error memproses trigger. Cek receiver.");
        }
    }

    private void openDana(String url) {
        // V7: simpan pending claim lebih dulu agar AccessibilityService sudah
        // armed ketika UI DANA muncul. Setelah itu coba buka DANA secara langsung.
        // Android versi baru dapat menolak pembukaan Activity dari background;
        // jika ditolak, notifikasi fallback tetap menyediakan tombol BUKA DANA.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("pending_dana_url", url)
                .apply();

        Intent openDana = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        openDana.setPackage("id.dana");
        openDana.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        try {
            startActivity(openDana);
            updateNotification("Perintah buka DANA dikirim. Menunggu konfirmasi UI DANA...");
            Log.i(TAG, "V9 berhasil mengirim Intent pembukaan DANA; menunggu konfirmasi UI Accessibility: " + url);
        } catch (Exception e) {
            updateNotification("Android menolak pembukaan DANA dari background. Tekan BUKA DANA pada notifikasi.");
            Log.e(TAG, "V7 gagal membuka DANA dari background; fallback notification tersedia.", e);
        }

        // Selalu tampilkan fallback agar URL tetap dapat dibuka jika Android/OEM
        // memblokir startActivity dari service yang berjalan di background.
        showDanaFallbackNotification(url, "DANA Kaget diterima. Jika DANA belum terbuka otomatis, tekan BUKA DANA.");
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setContentTitle("DANA Native Receiver")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void showResultNotification(String text, String url) {
        showDanaFallbackNotification(url, text);
    }

    private void showDanaFallbackNotification(String url, String text) {
        try {
            Intent openDana = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            openDana.setPackage("id.dana");
            openDana.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(
                    this,
                    Math.abs(url.hashCode()),
                    openDana,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, DANA_CHANNEL)
                    : new Notification.Builder(this);
            Notification n = b.setContentTitle("DANA Kaget terdeteksi")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .addAction(new Notification.Action.Builder(
                            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_view),
                            "BUKA DANA", pi).build())
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .build();
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(RESULT_ID, n);
        } catch (Exception e) {
            Log.e(TAG, "Gagal membuat fallback notification", e);
        }
    }

    private void updateNotification(String text) {
        if (!running) return;
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, notification(text));
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "DANA Receiver", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);

            NotificationChannel dana = new NotificationChannel(
                    DANA_CHANNEL, "DANA Trigger", NotificationManager.IMPORTANCE_HIGH);
            dana.setDescription("Notifikasi fallback ketika Android tidak mengizinkan pembukaan DANA dari background.");
            nm.createNotificationChannel(dana);
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        running = false;
        executor.shutdownNow();
        Log.i(TAG, "Service dihentikan");
        super.onDestroy();
    }
}
