package id.varino.danareceiver;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.os.Build;
import android.hardware.HardwareBuffer;
import android.view.Display;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * V6 SAFE BACKGROUND AUTO CLICK.
 *
 * Important design rule: never dispatch a tap while another app is in the
 * foreground. This prevents the receiver from stealing the user's screen.
 * The service may auto-click DANA UI only when the current accessible window
 * belongs to id.dana. A valid trigger is stored by NtfyService and consumed
 * when DANA is actually visible.
 */
public class DanaAutoClickAccessibilityService extends AccessibilityService {
    public static final String TAG = "DanaAutoClickV13";
    private static final String DANA_PACKAGE = "id.dana";
    private static final String TELEGRAM_PACKAGE = "org.telegram.messenger";
    private static final String TELEGRAM_BETA_PACKAGE = "org.telegram.messenger.beta";
    private static final long QR_SCAN_INTERVAL_MS = 1500L;
    private static final long QR_DEDUP_MS = 30000L;
    private static final String BUTTON_TEXT = "BUKA DANA";
    // DANA Kaget can render the envelope as a custom view with no clickable
    // Accessibility node. In that case we use a guarded coordinate fallback
    // only after the DANA screen itself is positively detected.
    private static final String ENVELOPE_HINT = "tap amplop";
    private static final String ENVELOPE_HINT_2 = "lihat dana kaget";
    private static final float ENVELOPE_TAP_X = 0.50f;
    private static final float ENVELOPE_TAP_Y = 0.49f;
    private static final long ENVELOPE_RETRY_WINDOW_MS = 7000L;
    private static final long ENVELOPE_RETRY_INTERVAL_MS = 900L;
    private static final long DIRECT_TAP_START_DELAY_MS = 650L;
    private static final int DIRECT_TAP_MAX_ATTEMPTS = 3;
    private static final long DIRECT_TAP_ATTEMPT_GAP_MS = 1800L;
    private static final String TRIGGER_TEXT = "DANA Kaget terdeteksi";
    private static final long RETRY_WINDOW_MS = 15000L;
    private static final long CLAIM_CONFIRM_WINDOW_MS = 12000L;
    private static final int RESULT_NOTIFICATION_ID = 2002;
    private static final String RESULT_CHANNEL = "dana_result";
    private static final String[] SUCCESS_TEXTS = {
            "dana kaget berhasil",
            "berhasil diklaim",
            "berhasil menerima",
            "kamu mendapatkan",
            "uang berhasil diterima",
            "dana kaget masuk"
    };
    private static final String[] FAILURE_TEXTS = {
            "dana kaget sudah habis",
            "dana kaget telah habis",
            "sudah diambil",
            "sudah diklaim",
            "gagal",
            "tidak berhasil",
            "kuota habis",
            "coba lagi"
    };

    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean armed = false;
    private long armedAt = 0L;
    private boolean clickInProgress = false;
    private boolean awaitingClaimResult = false;
    private boolean danaUiNotified = false;
    private long clickedAt = 0L;
    private long envelopeFirstSeenAt = 0L;
    private boolean danaVisualCheckInProgress = false;
    private long lastDanaVisualCheckAt = 0L;
    private int directTapAttempts = 0;
    private long directTapStartedAt = 0L;
    private boolean directTapScheduled = false;
    private String lastEventPackage = "";

    // V11: QR scanner for DANA Kaget images displayed in Telegram.
    // The scanner only accepts the official DANA Kaget URL format; other
    // QR codes (QRIS, Wi-Fi, contacts, etc.) are ignored.
    private final ExecutorService qrExecutor = Executors.newSingleThreadExecutor();
    private final BarcodeScanner qrScanner = BarcodeScanning.getClient(
            new BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build()
    );
    private volatile boolean qrScanInProgress = false;
    private long lastQrScanAt = 0L;
    private String lastQrUrl = "";
    private long lastQrDetectedAt = 0L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                | AccessibilityEvent.TYPE_VIEW_CLICKED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 50;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.packageNames = null;
        setServiceInfo(info);
        armed = hasPendingClaim();
        clickInProgress = false;
        envelopeFirstSeenAt = 0L;
        directTapAttempts = 0;
        directTapStartedAt = 0L;
        directTapScheduled = false;
        danaUiNotified = false;
        Log.i(TAG, "V13 Accessibility aktif. Direct tap DANA Kaget mode siap.");
        if (armed) scheduleRetries();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        lastEventPackage = pkg;
        String text = eventText(event);

        // V11: when a Telegram screen changes, inspect the visible screen for
        // a QR code. This is screenshot-only; nothing is tapped in Telegram.
        // Only a QR whose decoded value is an official DANA Kaget URL can
        // trigger the DANA claim flow.
        if (isTelegramPackage(pkg)
                && event.getEventType() != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            scheduleQrScreenScan();
        }

        if (DANA_PACKAGE.equals(pkg) && hasPendingClaim() && !danaUiNotified) {
            danaUiNotified = true;
            showResultNotification("📱 UI DANA terdeteksi. Receiver siap memproses DANA Kaget.", false);
            Log.i(TAG, "UI DANA terdeteksi untuk pending claim.");
        }

        if (DANA_PACKAGE.equals(pkg) && awaitingClaimResult) {
            String normalized = text == null ? "" : text.toLowerCase();
            if (containsAny(normalized, SUCCESS_TEXTS)) {
                claimConfirmed(true, text);
                return;
            }
            if (containsAny(normalized, FAILURE_TEXTS)) {
                claimConfirmed(false, text);
                return;
            }
            checkDanaRootForClaimResult();
            if (awaitingClaimResult && clickedAt > 0L && System.currentTimeMillis() - clickedAt > CLAIM_CONFIRM_WINDOW_MS) {
                claimNotConfirmed();
                return;
            }
        }

        if (event.getEventType() == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                && getPackageName().equals(pkg)
                && (containsIgnoreCase(text, TRIGGER_TEXT) || containsIgnoreCase(text, BUTTON_TEXT))) {
            armed = hasPendingClaim();
            if (armed) {
                Log.i(TAG, "Trigger valid. Menunggu/menangani UI DANA tanpa mengganggu aplikasi lain.");
                scheduleRetries();
            }
            return;
        }

        if (hasPendingClaim()) armed = true;
        if (armed && DANA_PACKAGE.equals(pkg)) {
            tryClickDanaButton();
        }
    }

    private boolean isTelegramPackage(String pkg) {
        return TELEGRAM_PACKAGE.equals(pkg) || TELEGRAM_BETA_PACKAGE.equals(pkg);
    }

    private void scheduleQrScreenScan() {
        if (Build.VERSION.SDK_INT < 30 || qrScanInProgress) return;

        long now = System.currentTimeMillis();
        if (now - lastQrScanAt < QR_SCAN_INTERVAL_MS) return;
        lastQrScanAt = now;

        handler.postDelayed(this::scanCurrentTelegramScreenForDanaQr, 250L);
    }

    private void scanCurrentTelegramScreenForDanaQr() {
        if (Build.VERSION.SDK_INT < 30 || qrScanInProgress) return;

        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root == null) return;
            CharSequence p = root.getPackageName();
            if (p == null || !isTelegramPackage(p.toString())) return;
        } catch (Exception e) {
            return;
        } finally {
            if (root != null) {
                try { root.recycle(); } catch (Exception ignored) {}
            }
        }

        qrScanInProgress = true;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(),
                    new TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(ScreenshotResult screenshot) {
                            try {
                                HardwareBuffer hb = screenshot.getHardwareBuffer();
                                if (hb == null) {
                                    qrScanInProgress = false;
                                    return;
                                }

                                ColorSpace cs = screenshot.getColorSpace();
                                Bitmap hardware = Bitmap.wrapHardwareBuffer(hb, cs);

                                if (hardware == null) {
                                    hb.close();
                                    qrScanInProgress = false;
                                    return;
                                }

                                Bitmap bitmap = hardware.copy(Bitmap.Config.ARGB_8888, false);
                                hardware.recycle();
                                hb.close();
                                if (bitmap == null) {
                                    qrScanInProgress = false;
                                    return;
                                }

                                qrExecutor.execute(() -> decodeDanaQr(bitmap));
                            } catch (Exception e) {
                                qrScanInProgress = false;
                                Log.w(TAG, "QR screenshot decode setup gagal: " + e.getMessage());
                            }
                        }

                        @Override
                        public void onFailure(int errorCode) {
                            qrScanInProgress = false;
                            Log.w(TAG, "QR screenshot gagal. code=" + errorCode);
                        }
                    });
        } catch (Exception e) {
            qrScanInProgress = false;
            Log.w(TAG, "takeScreenshot gagal: " + e.getMessage());
        }
    }

    private void decodeDanaQr(Bitmap bitmap) {
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            qrScanner.process(image)
                    .addOnSuccessListener(qrExecutor, barcodes -> {
                        try {
                            for (Barcode barcode : barcodes) {
                                String raw = barcode.getRawValue();
                                if (isOfficialDanaKagetUrl(raw)) {
                                    handleDanaQrUrl(raw.trim());
                                    break;
                                }
                            }
                        } finally {
                            bitmap.recycle();
                            qrScanInProgress = false;
                        }
                    })
                    .addOnFailureListener(qrExecutor, e -> {
                        try { bitmap.recycle(); } catch (Exception ignored) {}
                        qrScanInProgress = false;
                        Log.w(TAG, "ML Kit gagal membaca QR: " + e.getMessage());
                    });
        } catch (Exception e) {
            try { bitmap.recycle(); } catch (Exception ignored) {}
            qrScanInProgress = false;
            Log.w(TAG, "InputImage/QR decode gagal: " + e.getMessage());
        }
    }

    private boolean isOfficialDanaKagetUrl(String raw) {
        if (raw == null) return false;
        String value = raw.trim();
        if (value.isEmpty()) return false;

        try {
            Uri u = Uri.parse(value);
            String scheme = u.getScheme();
            String host = u.getHost();
            String path = u.getPath();
            String c = u.getQueryParameter("c");

            return "https".equalsIgnoreCase(scheme)
                    && "link.dana.id".equalsIgnoreCase(host)
                    && "/danakaget".equals(path)
                    && c != null
                    && !c.trim().isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private void handleDanaQrUrl(String rawUrl) {
        final String url = rawUrl.trim();
        if (!isOfficialDanaKagetUrl(url)) return;

        long now = System.currentTimeMillis();
        if (url.equals(lastQrUrl) && now - lastQrDetectedAt < QR_DEDUP_MS) {
            Log.i(TAG, "QR DANA Kaget duplikat diabaikan.");
            return;
        }
        lastQrUrl = url;
        lastQrDetectedAt = now;

        Log.i(TAG, "QR DANA Kaget terdeteksi: " + url);
        getSharedPreferences("dana_receiver", MODE_PRIVATE).edit()
                .putString("pending_dana_url", url)
                .apply();

        armed = true;
        armedAt = now;
        danaUiNotified = false;
        envelopeFirstSeenAt = 0L;
        directTapAttempts = 0;
        directTapStartedAt = 0L;
        directTapScheduled = false;

        handler.post(() -> openDanaFromQr(url));
    }

    private void openDanaFromQr(String url) {
        Intent openDana = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        openDana.setPackage(DANA_PACKAGE);
        openDana.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        try {
            startActivity(openDana);
            showResultNotification("📷 QR DANA Kaget terdeteksi. Membuka DANA untuk klaim...", false);
            Log.i(TAG, "QR DANA Kaget dibuka otomatis di DANA.");
            scheduleRetries();
        } catch (Exception e) {
            Log.e(TAG, "Gagal membuka DANA dari QR.", e);
            showDanaQrFallbackNotification(url);
        }
    }

    private void showDanaQrFallbackNotification(String url) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                NotificationChannel ch = new NotificationChannel(
                        RESULT_CHANNEL, "Hasil DANA Kaget", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }

            Intent openDana = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            openDana.setPackage(DANA_PACKAGE);
            openDana.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(
                    this, Math.abs(url.hashCode()), openDana,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, RESULT_CHANNEL)
                    : new Notification.Builder(this);
            Notification n = b.setContentTitle("DANA Kaget QR terdeteksi")
                    .setContentText("Tekan BUKA DANA untuk melanjutkan klaim.")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .addAction(new Notification.Action.Builder(
                            android.graphics.drawable.Icon.createWithResource(
                                    this, android.R.drawable.ic_menu_view),
                            "BUKA DANA", pi).build())
                    .setAutoCancel(true)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .build();

            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(RESULT_NOTIFICATION_ID, n);
        } catch (Exception e) {
            Log.e(TAG, "Gagal membuat fallback QR notification.", e);
        }
    }

    private String eventText(AccessibilityEvent event) {
        StringBuilder sb = new StringBuilder();
        for (CharSequence t : event.getText()) if (t != null) sb.append(t).append(' ');
        if (event.getContentDescription() != null) sb.append(event.getContentDescription());
        return sb.toString();
    }

    private boolean containsIgnoreCase(String haystack, String needle) {
        return haystack != null && needle != null
                && haystack.toLowerCase().contains(needle.toLowerCase());
    }

    private boolean hasPendingClaim() {
        return getSharedPreferences("dana_receiver", MODE_PRIVATE)
                .getString("pending_dana_url", "").trim().length() > 0;
    }

    private void scheduleRetries() {
        handler.removeCallbacksAndMessages(null);
        long[] delays = {0, 100, 250, 500, 900, 1500, 2500, 4000, 6000, 8000, 10000, 12000, 15000};
        for (long delay : delays) handler.postDelayed(this::tryClickDanaButton, delay);
    }

    private void tryClickDanaButton() {
        if (!armed || clickInProgress || awaitingClaimResult || !hasPendingClaim()) return;

        long now = System.currentTimeMillis();
        if (armedAt == 0L) armedAt = now;
        if (now - armedAt > RETRY_WINDOW_MS) {
            armed = false;
            Log.i(TAG, "Menunggu UI DANA selesai; tidak ada tap ke aplikasi lain.");
            return;
        }

        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root != null && isFromDana(root)) {
                // V10: the envelope screen is a custom-rendered UI. It may expose
                // only the instruction text, not a clickable node for the envelope.
                String uiText = collectNodeText(root).toLowerCase();
                if (isEnvelopeScreen(uiText)) {
                    tapDanaEnvelopeWithGuard(root);
                    return;
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Gagal membaca root DANA untuk envelope: " + e.getMessage());
        } finally {
            if (root != null) {
                try { root.recycle(); } catch (Exception ignored) {}
            }
        }

        // Original accessible-button flow remains intact.
        AccessibilityNodeInfo target = findButtonOnlyInDanaWindows();
        if (target == null) {
            // V13: do not depend on DANA's screenshot/visual detector for the
            // envelope. When DANA is definitely foreground and a valid pending
            // DANA Kaget URL exists, send a direct screen-coordinate tap.
            if (DANA_PACKAGE.equals(getActivePackageSafely())) {
                scheduleDirectEnvelopeTap();
            }
            return;
        }

        clickInProgress = true;
        boolean clicked = clickNode(target);
        if (clicked) {
            try { target.recycle(); } catch (Exception ignored) {}
            markClickedAndWaitForClaimResult();
            return;
        }

        android.graphics.Rect bounds = new android.graphics.Rect();
        target.getBoundsInScreen(bounds);
        try { target.recycle(); } catch (Exception ignored) {}

        if (!bounds.isEmpty()) {
            tapCenter(bounds);
        } else {
            clickInProgress = false;
        }
    }

    /**
     * V13 direct-tap path. This deliberately bypasses takeScreenshot() for the
     * DANA envelope. The only safety gates are: pending DANA Kaget URL, DANA
     * is the active package, and no claim click is already in progress.
     */
    private void scheduleDirectEnvelopeTap() {
        if (!armed || clickInProgress || awaitingClaimResult || !hasPendingClaim()) return;
        if (!DANA_PACKAGE.equals(getActivePackageSafely())) return;

        long now = System.currentTimeMillis();
        if (directTapStartedAt == 0L) {
            directTapStartedAt = now;
            directTapAttempts = 0;
        }

        if (directTapScheduled) return;

        if (now - directTapStartedAt > RETRY_WINDOW_MS) {
            Log.w(TAG, "V13: direct tap window habis tanpa konfirmasi.");
            return;
        }

        if (directTapAttempts >= DIRECT_TAP_MAX_ATTEMPTS) {
            Log.w(TAG, "V13: maksimum direct tap tercapai.");
            return;
        }

        long delay = directTapAttempts == 0 ? DIRECT_TAP_START_DELAY_MS : DIRECT_TAP_ATTEMPT_GAP_MS;
        directTapScheduled = true;
        handler.postDelayed(() -> {
            directTapScheduled = false;
            performDirectEnvelopeTap();
        }, delay);
    }

    private void performDirectEnvelopeTap() {
        if (!armed || clickInProgress || awaitingClaimResult || !hasPendingClaim()) return;
        if (!DANA_PACKAGE.equals(getActivePackageSafely())) return;
        if (directTapAttempts >= DIRECT_TAP_MAX_ATTEMPTS) return;

        directTapAttempts++;
        clickInProgress = true;

        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        try {
            android.view.WindowManager wm =
                    (android.view.WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null && Build.VERSION.SDK_INT >= 17) {
                wm.getDefaultDisplay().getRealMetrics(dm);
            } else {
                dm = getResources().getDisplayMetrics();
            }
        } catch (Exception e) {
            dm = getResources().getDisplayMetrics();
        }

        float x = dm.widthPixels * ENVELOPE_TAP_X;
        float y = dm.heightPixels * ENVELOPE_TAP_Y;

        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 140))
                .build();

        final int attempt = directTapAttempts;
        Log.i(TAG, "V13: mengirim DIRECT TAP ke DANA. attempt=" + attempt
                + ", screen=" + dm.widthPixels + "x" + dm.heightPixels
                + ", point=(" + x + "," + y + ")");

        boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                clickInProgress = false;
                Log.i(TAG, "V13: dispatchGesture COMPLETED. attempt=" + attempt);

                // Give DANA a moment to react, then use the normal claim-result
                // polling. This records exactly whether Android accepted the tap.
                markClickedAndWaitForClaimResult();
            }

            @Override public void onCancelled(GestureDescription g) {
                clickInProgress = false;
                Log.w(TAG, "V13: dispatchGesture CANCELLED. attempt=" + attempt);
                if (attempt < DIRECT_TAP_MAX_ATTEMPTS) {
                    scheduleDirectEnvelopeTap();
                }
            }
        }, handler);

        if (!dispatched) {
            clickInProgress = false;
            Log.w(TAG, "V13: dispatchGesture RETURNED FALSE. attempt=" + attempt);
            if (attempt < DIRECT_TAP_MAX_ATTEMPTS) {
                scheduleDirectEnvelopeTap();
            }
        }
    }

    private boolean isEnvelopeScreen(String uiText) {
        if (uiText == null) return false;
        return uiText.contains(ENVELOPE_HINT)
                || uiText.contains(ENVELOPE_HINT_2);
    }

    /**
     * Tap the DANA Kaget envelope when DANA renders it without a clickable
     * Accessibility node. The safety gate is strict: the active root must
     * belong to id.dana and its UI text must contain the envelope instruction.
     */
    private void tapDanaEnvelopeWithGuard(AccessibilityNodeInfo danaRoot) {
        if (!isFromDana(danaRoot) || clickInProgress || awaitingClaimResult) return;

        long now = System.currentTimeMillis();
        if (envelopeFirstSeenAt == 0L) envelopeFirstSeenAt = now;
        if (now - envelopeFirstSeenAt > ENVELOPE_RETRY_WINDOW_MS) {
            Log.w(TAG, "Envelope DANA terdeteksi tetapi retry window habis.");
            return;
        }

        clickInProgress = true;

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * ENVELOPE_TAP_X;
        float y = dm.heightPixels * ENVELOPE_TAP_Y;

        Path path = new Path();
        path.moveTo(x, y);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 90))
                .build();

        boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                Log.i(TAG, "V13: envelope DANA ditap otomatis pada (" + x + "," + y + ").");
                envelopeFirstSeenAt = 0L;
                markClickedAndWaitForClaimResult();
            }

            @Override public void onCancelled(GestureDescription g) {
                clickInProgress = false;
                Log.w(TAG, "V13: gesture envelope DANA dibatalkan.");
                scheduleEnvelopeRetry();
            }
        }, handler);

        if (!dispatched) {
            clickInProgress = false;
            Log.w(TAG, "V13: dispatchGesture envelope gagal.");
            scheduleEnvelopeRetry();
        }
    }

    private void scheduleEnvelopeRetry() {
        if (!armed || awaitingClaimResult || !hasPendingClaim()) return;
        handler.postDelayed(this::tryClickDanaButton, ENVELOPE_RETRY_INTERVAL_MS);
    }

    private String getActivePackageSafely() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                CharSequence p = root.getPackageName();
                String value = p == null ? "" : p.toString();
                try { root.recycle(); } catch (Exception ignored) {}
                if (!value.isEmpty()) return value;
            }
        } catch (Exception ignored) {}

        // Some OEM/custom-rendered screens expose an empty root package even
        // though the Accessibility event itself clearly came from DANA. Use
        // the latest event package only as a fallback.
        return lastEventPackage == null ? "" : lastEventPackage;
    }

    private void scheduleDanaEnvelopeVisualCheck() {
        if (Build.VERSION.SDK_INT < 30 || !armed || awaitingClaimResult
                || !hasPendingClaim() || danaVisualCheckInProgress) return;

        long now = System.currentTimeMillis();
        if (now - lastDanaVisualCheckAt < 650L) return;
        lastDanaVisualCheckAt = now;
        handler.postDelayed(this::captureDanaEnvelopeForTap, 120L);
    }

    /**
     * V12: Accessibility text is not reliable on DANA's custom envelope view.
     * Use the screenshot capability only while DANA is the active package and a
     * pending DANA Kaget URL exists. A simple visual gate looks for the large
     * white envelope on DANA's blue Kaget screen before sending the tap.
     */
    private void captureDanaEnvelopeForTap() {
        if (Build.VERSION.SDK_INT < 30 || !armed || awaitingClaimResult
                || !hasPendingClaim() || danaVisualCheckInProgress) return;

        if (!DANA_PACKAGE.equals(getActivePackageSafely())) return;

        danaVisualCheckInProgress = true;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(),
                    new TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(ScreenshotResult screenshot) {
                            Bitmap bitmap = null;
                            HardwareBuffer hb = null;
                            try {
                                hb = screenshot.getHardwareBuffer();
                                if (hb == null) return;

                                bitmap = Bitmap.wrapHardwareBuffer(hb, screenshot.getColorSpace());
                                if (bitmap == null) return;

                                Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
                                if (copy == null) return;

                                if (looksLikeDanaKagetEnvelope(copy)) {
                                    Log.i(TAG, "V12: visual envelope DANA terdeteksi. Mengirim tap otomatis.");
                                    tapDanaEnvelopeByScreenCoordinate();
                                } else {
                                    Log.d(TAG, "V12: layar DANA belum cocok dengan envelope; retry.");
                                    scheduleEnvelopeRetry();
                                }
                                copy.recycle();
                            } catch (Exception e) {
                                Log.w(TAG, "V12: visual envelope check gagal: " + e.getMessage());
                                scheduleEnvelopeRetry();
                            } finally {
                                try { if (bitmap != null) bitmap.recycle(); } catch (Exception ignored) {}
                                try { if (hb != null) hb.close(); } catch (Exception ignored) {}
                                danaVisualCheckInProgress = false;
                            }
                        }

                        @Override
                        public void onFailure(int errorCode) {
                            danaVisualCheckInProgress = false;
                            Log.w(TAG, "V12: screenshot DANA gagal. code=" + errorCode);
                            scheduleEnvelopeRetry();
                        }
                    });
        } catch (Exception e) {
            danaVisualCheckInProgress = false;
            Log.w(TAG, "V12: takeScreenshot DANA gagal: " + e.getMessage());
            scheduleEnvelopeRetry();
        }
    }

    private boolean looksLikeDanaKagetEnvelope(Bitmap source) {
        if (source == null || source.getWidth() < 100 || source.getHeight() < 100) return false;

        final int w = source.getWidth();
        final int h = source.getHeight();
        int white = 0;
        int blue = 0;
        int whiteSamples = 0;
        int blueSamples = 0;

        // The photographed DANA Kaget screen has a large white envelope in the
        // central area over a predominantly blue background. Use a coarse sample
        // so this remains fast on high-resolution phones.
        for (int gy = 0; gy < 40; gy++) {
            float fy = (gy + 0.5f) / 40f;
            for (int gx = 0; gx < 40; gx++) {
                float fx = (gx + 0.5f) / 40f;
                int x = Math.min(w - 1, (int) (fx * w));
                int y = Math.min(h - 1, (int) (fy * h));
                int c = source.getPixel(x, y);
                int r = android.graphics.Color.red(c);
                int g = android.graphics.Color.green(c);
                int b = android.graphics.Color.blue(c);

                if (fx >= 0.25f && fx <= 0.75f && fy >= 0.25f && fy <= 0.75f) {
                    whiteSamples++;
                    int gray = (r + g + b) / 3;
                    if (gray > 150
                            && Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) < 90) {
                        white++;
                    }
                }

                if (fy >= 0.08f && fy <= 0.82f
                        && !(fx >= 0.22f && fx <= 0.78f && fy >= 0.23f && fy <= 0.76f)) {
                    blueSamples++;
                    if (b > 145 && b > r * 1.18f && b > g * 1.02f) {
                        blue++;
                    }
                }
            }
        }

        float whiteRatio = whiteSamples == 0 ? 0f : (float) white / whiteSamples;
        float blueRatio = blueSamples == 0 ? 0f : (float) blue / blueSamples;
        return whiteRatio >= 0.10f && blueRatio >= 0.12f;
    }

    private void tapDanaEnvelopeByScreenCoordinate() {
        if (!armed || clickInProgress || awaitingClaimResult || !hasPendingClaim()) return;
        if (!DANA_PACKAGE.equals(getActivePackageSafely())) return;

        long now = System.currentTimeMillis();
        if (envelopeFirstSeenAt == 0L) envelopeFirstSeenAt = now;
        if (now - envelopeFirstSeenAt > ENVELOPE_RETRY_WINDOW_MS) {
            Log.w(TAG, "V12: envelope retry window habis.");
            return;
        }

        clickInProgress = true;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * ENVELOPE_TAP_X;
        float y = dm.heightPixels * ENVELOPE_TAP_Y;

        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 120))
                .build();

        boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                Log.i(TAG, "V12: tap envelope DANA selesai pada (" + x + "," + y + ").");
                envelopeFirstSeenAt = 0L;
                markClickedAndWaitForClaimResult();
            }

            @Override public void onCancelled(GestureDescription g) {
                clickInProgress = false;
                Log.w(TAG, "V12: tap envelope DANA dibatalkan.");
                scheduleEnvelopeRetry();
            }
        }, handler);

        if (!dispatched) {
            clickInProgress = false;
            Log.w(TAG, "V13: dispatchGesture envelope gagal.");
            scheduleEnvelopeRetry();
        }
    }

    private AccessibilityNodeInfo findButtonOnlyInDanaWindows() {
        List<AccessibilityNodeInfo> roots = new ArrayList<>();
        try {
            AccessibilityNodeInfo active = getRootInActiveWindow();
            if (active != null) roots.add(active);
        } catch (Exception ignored) {}

        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo w : windows) {
                    if (w == null) continue;
                    CharSequence title = w.getTitle();
                    // Window package is not exposed uniformly on all Android/OEM versions;
                    // node package checks below provide the actual safety gate.
                    try {
                        AccessibilityNodeInfo root = w.getRoot();
                        if (root != null) roots.add(root);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "getWindows gagal: " + e.getMessage());
        }

        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo root : roots) {
            if (root == null) continue;
            if (!isFromDana(root)) continue;
            found = findButton(root);
            if (found == null) found = findButtonRecursive(root);
            if (found != null) break;
        }

        for (AccessibilityNodeInfo root : roots) {
            if (root != null && root != found) {
                try { root.recycle(); } catch (Exception ignored) {}
            }
        }
        return found;
    }

    private boolean isFromDana(AccessibilityNodeInfo node) {
        CharSequence p = node.getPackageName();
        return p != null && DANA_PACKAGE.equals(p.toString());
    }

    private AccessibilityNodeInfo findButton(AccessibilityNodeInfo root) {
        try {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(BUTTON_TEXT);
            if (nodes != null) {
                for (AccessibilityNodeInfo n : nodes) {
                    if (n != null && isFromDana(n) && isUseful(n)) return n;
                    if (n != null) try { n.recycle(); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private AccessibilityNodeInfo findButtonRecursive(AccessibilityNodeInfo node) {
        if (node == null || !isFromDana(node)) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        String s = t != null ? t.toString() : (d != null ? d.toString() : "");
        if (containsIgnoreCase(s, BUTTON_TEXT) && isUseful(node)) return node;

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findButtonRecursive(child);
            if (found != null) return found;
            if (child != null) try { child.recycle(); } catch (Exception ignored) {}
        }
        return null;
    }

    private boolean isUseful(AccessibilityNodeInfo node) {
        if (node == null || !isFromDana(node)) return false;
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        String value = text != null ? text.toString() : (desc != null ? desc.toString() : "");
        return containsIgnoreCase(value, BUTTON_TEXT) || node.isClickable();
    }

    private boolean clickNode(AccessibilityNodeInfo node) {
        try {
            if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        } catch (Exception ignored) {}

        AccessibilityNodeInfo parent = null;
        try { parent = node.getParent(); } catch (Exception ignored) {}
        for (int i = 0; i < 8 && parent != null; i++) {
            try {
                if (isFromDana(parent) && parent.isClickable()
                        && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    parent.recycle();
                    return true;
                }
                AccessibilityNodeInfo next = parent.getParent();
                parent.recycle();
                parent = next;
            } catch (Exception e) {
                try { parent.recycle(); } catch (Exception ignored) {}
                break;
            }
        }
        return false;
    }

    private void tapCenter(android.graphics.Rect bounds) {
        float x = bounds.centerX();
        float y = bounds.centerY();
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 80);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        boolean dispatched = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                Log.i(TAG, "Gesture DANA selesai. Menunggu konfirmasi hasil claim.");
                markClickedAndWaitForClaimResult();
            }
            @Override public void onCancelled(GestureDescription g) {
                clickInProgress = false;
                Log.w(TAG, "Gesture DANA dibatalkan.");
            }
        }, handler);
        if (!dispatched) clickInProgress = false;
    }

    private void markClickedAndWaitForClaimResult() {
        clickInProgress = false;
        awaitingClaimResult = true;
        clickedAt = System.currentTimeMillis();
        showResultNotification("Tombol DANA tertekan. Menunggu konfirmasi claim...", false);
        Log.i(TAG, "Tombol DANA berhasil ditekan; menunggu UI konfirmasi claim.");
        pollClaimResult();
        handler.postDelayed(() -> {
            if (awaitingClaimResult && clickedAt == 0L) return;
            if (awaitingClaimResult && System.currentTimeMillis() - clickedAt >= CLAIM_CONFIRM_WINDOW_MS) {
                claimNotConfirmed();
            }
        }, CLAIM_CONFIRM_WINDOW_MS + 250L);
    }

    private void pollClaimResult() {
        if (!awaitingClaimResult) return;
        checkDanaRootForClaimResult();
        if (awaitingClaimResult && System.currentTimeMillis() - clickedAt < CLAIM_CONFIRM_WINDOW_MS) {
            handler.postDelayed(this::pollClaimResult, 500L);
        }
    }

    private void checkDanaRootForClaimResult() {
        if (!awaitingClaimResult) return;
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !isFromDana(root)) return;
            String allText = collectNodeText(root).toLowerCase();
            if (containsAny(allText, SUCCESS_TEXTS)) {
                claimConfirmed(true, allText);
            } else if (containsAny(allText, FAILURE_TEXTS)) {
                claimConfirmed(false, allText);
            }
            try { root.recycle(); } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    private String collectNodeText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null) sb.append(t).append(' ');
        if (d != null) sb.append(d).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = null;
            try { child = node.getChild(i); } catch (Exception ignored) {}
            if (child != null) {
                sb.append(collectNodeText(child)).append(' ');
                try { child.recycle(); } catch (Exception ignored) {}
            }
        }
        return sb.toString();
    }

    private void claimConfirmed(boolean success, String uiText) {
        String url = getSharedPreferences("dana_receiver", MODE_PRIVATE)
                .getString("pending_dana_url", "").trim();
        getSharedPreferences("dana_receiver", MODE_PRIVATE).edit()
                .remove("pending_dana_url")
                .apply();
        awaitingClaimResult = false;
        armed = false;
        clickInProgress = false;
        danaUiNotified = false;
        armedAt = 0L;
        clickedAt = 0L;
        envelopeFirstSeenAt = 0L;
        directTapAttempts = 0;
        directTapStartedAt = 0L;
        directTapScheduled = false;
        danaVisualCheckInProgress = false;
        lastDanaVisualCheckAt = 0L;
        handler.removeCallbacksAndMessages(null);

        if (success) {
            showResultNotification("✅ CLAIM DANA KAGET BERHASIL dikonfirmasi oleh UI DANA.", false);
            Log.i(TAG, "CLAIM DANA BERHASIL dikonfirmasi: " + uiText);
        } else {
            showResultNotification("❌ CLAIM DANA KAGET GAGAL / tidak dapat diambil.", false);
            Log.i(TAG, "CLAIM DANA gagal: " + uiText);
        }
    }

    private void claimNotConfirmed() {
        awaitingClaimResult = false;
        clickInProgress = false;
        armed = false;
        danaUiNotified = false;
        armedAt = 0L;
        clickedAt = 0L;
        envelopeFirstSeenAt = 0L;
        directTapAttempts = 0;
        directTapStartedAt = 0L;
        directTapScheduled = false;
        danaVisualCheckInProgress = false;
        lastDanaVisualCheckAt = 0L;
        handler.removeCallbacksAndMessages(null);
        showResultNotification("⚠️ Tombol sudah ditekan, tetapi hasil claim belum bisa dikonfirmasi dari UI DANA.", false);
        Log.w(TAG, "Claim belum terkonfirmasi dari UI DANA; pending URL dipertahankan untuk pemeriksaan manual.");
    }

    private boolean containsAny(String text, String[] candidates) {
        if (text == null) return false;
        for (String candidate : candidates) {
            if (text.contains(candidate)) return true;
        }
        return false;
    }

    private void showResultNotification(String text, boolean keepPending) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                NotificationChannel ch = new NotificationChannel(
                        RESULT_CHANNEL, "Hasil DANA Kaget", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }

            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 2002, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, RESULT_CHANNEL)
                    : new Notification.Builder(this);
            Notification n = b.setContentTitle("DANA Native Receiver")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_STATUS)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .build();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(RESULT_NOTIFICATION_ID, n);
        } catch (Exception e) {
            Log.e(TAG, "Gagal membuat notifikasi hasil claim", e);
        }
    }

    @Override public void onDestroy() {
        try { qrScanner.close(); } catch (Exception ignored) {}
        qrExecutor.shutdownNow();
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public void onInterrupt() {
        armed = false;
        clickInProgress = false;
        awaitingClaimResult = false;
        clickedAt = 0L;
        envelopeFirstSeenAt = 0L;
        directTapAttempts = 0;
        directTapStartedAt = 0L;
        directTapScheduled = false;
        danaVisualCheckInProgress = false;
        lastDanaVisualCheckAt = 0L;
        Log.i(TAG, "Accessibility diinterupsi; menunggu reconnect sistem.");
    }

    public static boolean isEnabled(android.content.Context context) {
        String enabled = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        String target = context.getPackageName() + "/" + DanaAutoClickAccessibilityService.class.getName();
        for (String item : enabled.split(":")) if (target.equalsIgnoreCase(item)) return true;
        return false;
    }
}
