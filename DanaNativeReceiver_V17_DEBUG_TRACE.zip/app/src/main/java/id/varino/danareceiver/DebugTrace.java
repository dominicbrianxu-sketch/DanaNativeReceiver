package id.varino.danareceiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/**
 * Detailed process trace for troubleshooting. It writes to Logcat and keeps a
 * compact rolling timeline in an Android notification. Sensitive URLs/tokens
 * are never included; DANA URLs are masked before logging.
 */
public final class DebugTrace {
    private static final String TAG = "DanaDebugTrace";
    private static final String CHANNEL = "dana_debug_trace";
    private static final int NOTIF_ID = 3001;
    private static final int MAX_LINES = 28;
    private static final Object LOCK = new Object();
    private static final ArrayDeque<String> LINES = new ArrayDeque<>();
    private static long startedAt = 0L;
    private static int seq = 0;
    private static boolean active = false;

    private DebugTrace() {}

    public static void start(Context context, String title) {
        synchronized (LOCK) {
            startedAt = System.currentTimeMillis();
            seq = 0;
            active = true;
            LINES.clear();
        }
        step(context, title == null ? "Proses dimulai" : title);
    }

    public static void step(Context context, String message) {
        add(context, "INFO", "🟢", message);
    }

    public static void wait(Context context, String message) {
        add(context, "WAIT", "🟡", message);
    }

    public static void success(Context context, String message) {
        add(context, "SUCCESS", "🟢", message);
    }

    public static void fail(Context context, String message) {
        add(context, "FAIL", "🔴", message);
    }

    public static void warn(Context context, String message) {
        add(context, "WARN", "🟠", message);
    }

    public static void finish(Context context, String message) {
        add(context, "DONE", "🔵", message);
        synchronized (LOCK) { active = false; }
    }

    public static String maskUrl(String url) {
        if (url == null || url.isEmpty()) return "(kosong)";
        int q = url.indexOf("?c=");
        if (q >= 0) return url.substring(0, q) + "?c=****";
        return url.length() > 70 ? url.substring(0, 67) + "..." : url;
    }

    public static String snapshot() {
        synchronized (LOCK) {
            StringBuilder sb = new StringBuilder();
            for (String line : LINES) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(line);
            }
            return sb.toString();
        }
    }

    private static void add(Context context, String level, String icon, String message) {
        long now = System.currentTimeMillis();
        String time = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date(now));
        long elapsed;
        int n;
        synchronized (LOCK) {
            if (!active && LINES.isEmpty()) {
                startedAt = now;
                active = true;
            }
            elapsed = Math.max(0L, now - startedAt);
            n = ++seq;
            String safe = sanitize(message);
            String line = String.format(Locale.US, "%s +%6dms %s [%02d] %s %s",
                    time, elapsed, level, n, icon, safe);
            while (LINES.size() >= MAX_LINES) LINES.removeFirst();
            LINES.addLast(line);
            Log.i(TAG, line);
        }
        if (context != null) postNotification(context.getApplicationContext());
    }

    private static String sanitize(String message) {
        if (message == null) return "(null)";
        String s = message.replace('\n', ' ').replace('\r', ' ');
        // Mask common credential-bearing fields if accidentally passed in.
        s = s.replaceAll("(?i)(token\\s*[=:]\\s*)[^\\s,}]+", "$1****");
        s = s.replaceAll("(?i)(authorization\\s*[=:]\\s*)[^\\s,}]+", "$1****");
        s = s.replaceAll("https://link\\.dana\\.id/danakaget\\?c=[^\\s]+", "https://link.dana.id/danakaget?c=****");
        return s;
    }

    private static void postNotification(Context context) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL, "DANA Debug Process", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Timeline detail proses DANA Native Receiver");
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(context, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(context, NOTIF_ID, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            String body = snapshot();
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(context, CHANNEL)
                    : new Notification.Builder(context);
            Notification n = b.setContentTitle("DANA Receiver • DEBUG PROCESS")
                    .setContentText(lastLine(body))
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .setOnlyAlertOnce(true)
                    .setOngoing(true)
                    .setCategory(Notification.CATEGORY_STATUS)
                    .build();
            nm.notify(NOTIF_ID, n);
        } catch (Exception e) {
            Log.e(TAG, "Gagal update debug notification", e);
        }
    }

    private static String lastLine(String body) {
        if (body == null || body.isEmpty()) return "Belum ada log";
        int p = body.lastIndexOf('\n');
        String s = p >= 0 ? body.substring(p + 1) : body;
        return s.length() > 180 ? s.substring(0, 177) + "..." : s;
    }
}
