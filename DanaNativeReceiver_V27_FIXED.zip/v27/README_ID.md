# DanaNativeReceiver V27

V27 menambahkan deteksi sukses nominal Rp pada setiap event UI DANA dan post-tap success watch. Jika layar hasil menampilkan `Yay! Kamu dapet Rp...`, tap langsung dihentikan, pending claim dibersihkan, DANA ditutup, lalu receiver kembali standby. Watchdog tetap menutup DANA setelah maksimum 2 menit bila hasil tidak terkonfirmasi.
