package id.varino.danareceiver;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;

public class MainActivity extends Activity {
    private static final String PREFS = "dana_receiver";
    private EditText server, topic, token, botToken, botChatId, botReportChatId, botDeviceId;
    private TextView status;
    private TextView autoClickStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);

        // Full-screen vertical ScrollView. This is intentionally the ROOT view so
        // the complete settings page can always be scrolled on small screens.
        // Extra system-bar insets keep the bottom controls above Android navigation.
        // V28.1: root = LinearLayout vertikal, ScrollView di dalamnya diberi tinggi
        // tetap (0dp + weight 1). Dengan begitu tinggi ScrollView SELALU sama dengan
        // area layar yang terlihat, sehingga isi yang lebih panjang pasti bisa di-scroll.
        LinearLayout pageRoot = new LinearLayout(this);
        pageRoot.setOrientation(LinearLayout.VERTICAL);
        pageRoot.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        ScrollView scrollRoot = new ScrollView(this);
        scrollRoot.setFillViewport(false);
        scrollRoot.setVerticalScrollBarEnabled(true);
        scrollRoot.setScrollbarFadingEnabled(false);
        scrollRoot.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        scrollRoot.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        scrollRoot.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 32, 32, 96);
        box.setLayoutParams(new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // Inset status bar / navigation bar dipasang di root (bukan di isi ScrollView).
        pageRoot.setOnApplyWindowInsetsListener((v, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, top, 0, bottom);
            return insets;
        });

        TextView title = new TextView(this);
        title.setText("DANA Native Receiver V28.1 • FULL DEBUG TRACE");
        title.setTextSize(24);
        box.addView(title);

        TextView info = new TextView(this);
        info.setText("\nSinkron dengan notifier.py → ntfy → HP.\n" +
                "Receiver memakai Foreground Service dan auto-reconnect.\n" +
                "V28: link DANA Kaget yang muncul langsung di notifikasi Telegram/Nicegram/Telegram Plus diekstrak otomatis lalu membuka DANA; QR DANA Kaget tetap dipindai dari layar Telegram. V15: trigger/QR DANA Kaget menyimpan URL lalu mencoba membuka UI DANA dan menampilkan status berdasarkan konfirmasi Accessibility. Jika Android memblokir pembukaan dari background, gunakan tombol BUKA DANA pada notifikasi. Auto-click bekerja ketika UI DANA terlihat dan Accessibility aktif. QR DANA Kaget yang tampil di Telegram juga dipindai otomatis; QR selain link.dana.id/danakaget diabaikan.\n");
        box.addView(info);

        server = field("Server ntfy", p.getString("server", "https://ntfy.sh"));
        topic = field("Topic", p.getString("topic", ""));
        token = field("Token", p.getString("token", ""));
        token.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        botToken = field("Telegram Bot Token", p.getString("telegram_bot_token", ""));
        botToken.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        botChatId = field("Telegram Command Chat ID (Danabot)", p.getString("telegram_command_chat_id", p.getString("telegram_chat_id", "5837001530")));
        botReportChatId = field("Telegram Report Chat ID (Dana Report)", p.getString("telegram_report_chat_id", p.getString("telegram_chat_id", "5353300549")));
        botDeviceId = field("Telegram Device ID", p.getString("telegram_device_id", ""));

        box.addView(server);
        box.addView(topic);
        box.addView(token);
        box.addView(botToken);
        box.addView(botChatId);
        box.addView(botReportChatId);
        box.addView(botDeviceId);

        Button saveStart = new Button(this);
        saveStart.setText("Simpan & Aktifkan Receiver");
        box.addView(saveStart);

        Button accessibility = new Button(this);
        accessibility.setText("Aktifkan Auto Klik DANA");
        box.addView(accessibility);

        autoClickStatus = new TextView(this);
        box.addView(autoClickStatus);

        Button stop = new Button(this);
        stop.setText("Matikan Receiver");
        box.addView(stop);

        Button testDana = new Button(this);
        testDana.setText("Tes Buka Aplikasi DANA");
        box.addView(testDana);

        Button testTelegram = new Button(this);
        testTelegram.setText("TES KONEKSI TELEGRAM");
        box.addView(testTelegram);

        Button debug = new Button(this);
        debug.setText("LIHAT DEBUG LENGKAP");
        box.addView(debug);

        testTelegram.setOnClickListener(v -> {
            SharedPreferences tp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String bt = tp.getString("telegram_bot_token", "").trim();
            String bc = tp.getString("telegram_report_chat_id", tp.getString("telegram_chat_id", "")).trim();
            if (bt.isEmpty() || bc.isEmpty()) {
                status.setText("\nStatus: isi Telegram Bot Token dan Chat ID terlebih dahulu.");
                return;
            }
            TelegramBotController.sendReport(this,
                    "🧪 TEST TELEGRAM BERHASIL\n📱 Device: " +
                    TelegramBotController.get(this).deviceId() +
                    "\n💬 Chat ID: " + bc +
                    "\nJika pesan ini masuk, koneksi Bot API → Telegram sudah OK.");
            status.setText("\nStatus: pesan test Telegram dikirim. Cek chat ID yang diisi.");
        });

        debug.setOnClickListener(v -> showDebugDialog());

        status = new TextView(this);
        box.addView(status);

        saveStart.setOnClickListener(v -> {
            String s = server.getText().toString().trim();
            String t = topic.getText().toString().trim();
            String k = token.getText().toString().trim();
            String bt = botToken.getText().toString().trim();
            String bc = botChatId.getText().toString().trim();
            String br = botReportChatId.getText().toString().trim();
            String bd = botDeviceId.getText().toString().trim();

            p.edit().putString("server", s).putString("topic", t).putString("token", k)
                    .putString("telegram_bot_token", bt)
                    .putString("telegram_chat_id", bc)
                    .putString("telegram_command_chat_id", bc)
                    .putString("telegram_report_chat_id", br)
                    .putString("telegram_device_id", bd)
                    .putBoolean("telegram_bot_enabled", !bt.isEmpty() && !bc.isEmpty())
                    .putBoolean("enabled", true).apply();

            if (bt.isEmpty() || bc.isEmpty() || br.isEmpty()) {
                status.setText("\nStatus: receiver aktif, tetapi Telegram command/report belum lengkap.");
            }

            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
            }

            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            startTelegramBotService();
            status.setText("\nStatus: receiver AKTIF dan akan otomatis hidup lagi setelah HP restart.");
            refreshAccessibilityStatus();
        });

        accessibility.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });

        stop.setOnClickListener(v -> {
            p.edit().putBoolean("enabled", false).apply();
            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_STOP);
            startService(i);
            status.setText("\nStatus: receiver dimatikan dan tidak akan otomatis hidup setelah restart.");
        });

        testDana.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://link.dana.id/danakaget?c=TEST"));
            i.setPackage("id.dana");
            try {
                startActivity(i);
                status.setText("\nStatus: perintah membuka aplikasi DANA dikirim.");
            } catch (Exception e) {
                status.setText("\nStatus: aplikasi DANA tidak ditemukan/Android menolak pembukaan.");
            }
        });

        boolean enabled = p.getBoolean("enabled", false);
        if (enabled && !topic.getText().toString().trim().isEmpty() && !token.getText().toString().trim().isEmpty()) {
            Intent auto = new Intent(this, NtfyService.class);
            auto.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(auto);
            else startService(auto);
            startTelegramBotService();
            status.setText("\nStatus: receiver AKTIF (otomatis).");
        } else {
            status.setText("\nStatus: receiver belum aktif.");
        }

        scrollRoot.addView(box);
        pageRoot.addView(scrollRoot);
        setContentView(pageRoot);
        pageRoot.requestApplyInsets();
        startTelegramBotService();
        refreshAccessibilityStatus();

        if (getIntent().getBooleanExtra("show_debug", false)) {
            box.postDelayed(this::showDebugDialog, 250L);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (autoClickStatus != null) refreshAccessibilityStatus();
    }

    private void startTelegramBotService() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("telegram_bot_enabled", false)) return;
        Intent i = new Intent(this, TelegramBotService.class);
        i.setAction(TelegramBotService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void refreshAccessibilityStatus() {
        boolean enabled = DanaAutoClickAccessibilityService.isEnabled(this);
        autoClickStatus.setText("Auto Klik: " + (enabled ? "AKTIF ✓" : "BELUM AKTIF — aktifkan di Pengaturan Aksesibilitas"));
    }

    private void showDebugDialog() {
        final String trace = DebugTrace.fullSnapshot(this);
        ScrollView scroll = new ScrollView(this);
        TextView view = new TextView(this);
        view.setText(trace.isEmpty() ? "Belum ada debug trace." : trace);
        view.setTextIsSelectable(true);
        view.setTextSize(11);
        view.setPadding(24, 24, 24, 24);
        scroll.addView(view);
        new android.app.AlertDialog.Builder(this)
                .setTitle("DANA • DEBUG LENGKAP")
                .setView(scroll)
                .setPositiveButton("Tutup", null)
                .setNeutralButton("Hapus Log", (d, w) -> {
                    DebugTrace.clearPersisted(this);
                })
                .show();
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }
}
