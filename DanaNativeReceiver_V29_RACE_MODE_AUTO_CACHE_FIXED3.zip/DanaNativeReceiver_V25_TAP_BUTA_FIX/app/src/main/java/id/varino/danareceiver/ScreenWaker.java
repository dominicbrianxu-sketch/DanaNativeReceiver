package id.varino.danareceiver;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.PowerManager;
import android.util.Log;

/**
 * V27: memastikan layar menyala saat trigger DANA Kaget masuk walau HP
 * sedang layar mati, supaya proses tap Accessibility punya window aktif
 * untuk ditapping.
 *
 * KENAPA INI DIPERLUKAN:
 * Gesture yang dikirim AccessibilityService ke layar yang BENAR-BENAR mati
 * tidak pernah terdaftar oleh sistem input Android -- compositor tidak
 * memproses apa pun saat display mati. Ini batasan platform, bukan bug di
 * app ini, dan tidak bisa diakali murni dari kode tap. Solusinya: nyalakan
 * layar lebih dulu begitu link DANA Kaget diterima.
 *
 * CATATAN PENTING SOAL KEAMANAN:
 * Kalau HP dikunci dengan PIN/pola/password/biometrik (secure lock),
 * ScreenWaker HANYA menyalakan layar -- ia TIDAK melewati lock screen
 * tersebut. disableKeyguard() di bawah ini cuma berlaku untuk kunci
 * "Swipe"/tanpa kunci (non-secure); kalau secure lock aktif, layar akan
 * menyala tapi menampilkan lock screen, dan tap otomatis TIDAK akan
 * mengenai DANA sampai user membuka kunci secara manual. Ini SENGAJA --
 * melewati lock screen aman secara otomatis adalah proteksi keamanan
 * Android yang memang tidak boleh dilewati oleh aplikasi pihak ketiga.
 */
final class ScreenWaker {
    private static final String TAG = "DanaReceiver";
    private static final String WAKE_TAG = "DanaReceiver:ScreenWake";

    // Sedikit lebih lama dari watchdog 2 menit di AccessibilityService, supaya
    // wake lock ini tidak pernah "nyangkut" menyala kalau release() gagal
    // terpanggil karena alasan tak terduga.
    private static final long MAX_WAKE_LOCK_MS = 130_000L;

    private static PowerManager.WakeLock wakeLock;
    private static KeyguardManager.KeyguardLock keyguardLock;

    private ScreenWaker() {}

    static synchronized void wake(Context ctx) {
        try {
            Context app = ctx.getApplicationContext();
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;

            if (wakeLock == null || !wakeLock.isHeld()) {
                @SuppressWarnings("deprecation")
                PowerManager.WakeLock wl = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                                | PowerManager.ACQUIRE_CAUSES_WAKEUP
                                | PowerManager.ON_AFTER_RELEASE,
                        WAKE_TAG);
                wl.setReferenceCounted(false);
                wl.acquire(MAX_WAKE_LOCK_MS);
                wakeLock = wl;
                Log.i(TAG, "ScreenWaker: layar dinyalakan untuk proses klaim DANA Kaget");
            } else {
                // Sudah menyala dari trigger sebelumnya di sesi yang sama;
                // perpanjang saja durasinya.
                wakeLock.acquire(MAX_WAKE_LOCK_MS);
            }

            if (keyguardLock == null) {
                @SuppressWarnings("deprecation")
                KeyguardManager km = (KeyguardManager) app.getSystemService(Context.KEYGUARD_SERVICE);
                if (km != null) {
                    try {
                        @SuppressWarnings("deprecation")
                        KeyguardManager.KeyguardLock kl = km.newKeyguardLock(WAKE_TAG);
                        kl.disableKeyguard();
                        keyguardLock = kl;
                    } catch (Exception e) {
                        Log.w(TAG, "ScreenWaker: disableKeyguard gagal (lock screen mungkin aman/PIN): " + e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "ScreenWaker: gagal menyalakan layar: " + e.getMessage());
        }
    }

    static synchronized void release() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
                Log.i(TAG, "ScreenWaker: wake lock dilepas");
            }
        } catch (Exception ignored) {
        } finally {
            wakeLock = null;
        }
        try {
            if (keyguardLock != null) {
                keyguardLock.reenableKeyguard();
            }
        } catch (Exception ignored) {
        } finally {
            keyguardLock = null;
        }
    }
}
