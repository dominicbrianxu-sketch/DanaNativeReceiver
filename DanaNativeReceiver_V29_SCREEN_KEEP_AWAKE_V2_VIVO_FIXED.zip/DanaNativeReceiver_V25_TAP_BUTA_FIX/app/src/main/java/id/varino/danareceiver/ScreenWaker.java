package id.varino.danareceiver;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;

/**
 * Keeps the display awake only during an active DANA claim session.
 *
 * Vivo/Funtouch OS can still dim the display on some older devices even when a
 * normal timed SCREEN_BRIGHT_WAKE_LOCK is used.  For that reason this class
 * combines a bright wake lock with a lightweight periodic wakeUp() refresh.
 * The refresh stops immediately when the claim session ends or the watchdog
 * expires.
 */
final class ScreenWaker {
    private static final String TAG = "DanaReceiver";
    private static final String WAKE_TAG = "DanaReceiver:ScreenWake";

    // Hard safety ceiling for one lock acquisition. The lock is renewed while
    // the claim session is active, so this is NOT the total claim duration.
    private static final long LOCK_WINDOW_MS = 60_000L;

    // More aggressive than the previous 20s interval for old Vivo/Funtouch OS.
    private static final long KEEP_ALIVE_MS = 5_000L;

    private static final Handler HANDLER =
            new Handler(Looper.getMainLooper());

    private static PowerManager.WakeLock wakeLock;
    private static KeyguardManager.KeyguardLock keyguardLock;
    private static Context appContext;
    private static boolean active = false;
    private static long lastLogAt = 0L;

    private ScreenWaker() {}

    static synchronized void wake(Context ctx) {
        try {
            appContext = ctx.getApplicationContext();
            PowerManager pm = (PowerManager) appContext.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;

            active = true;
            ensureWakeLock(pm);

            // Immediately wake the panel if it has already gone dark.
            forceInteractive(pm);

            // Keep the display bright for the active claim session.
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire(LOCK_WINDOW_MS);
            } else if (wakeLock != null) {
                // Re-acquire to reset the timed window without reference-counting.
                wakeLock.acquire(LOCK_WINDOW_MS);
            }

            ensureNonSecureKeyguardDismissal(appContext);
            scheduleKeepAlive();
            logThrottled("ScreenWaker: DANA claim -> layar dipaksa tetap ON");
        } catch (Exception e) {
            Log.w(TAG, "ScreenWaker: wake gagal: " + e.getMessage());
        }
    }

    private static void ensureWakeLock(PowerManager pm) {
        if (wakeLock != null) return;
        @SuppressWarnings("deprecation")
        PowerManager.WakeLock wl = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                        | PowerManager.ACQUIRE_CAUSES_WAKEUP
                        | PowerManager.ON_AFTER_RELEASE,
                WAKE_TAG);
        wl.setReferenceCounted(false);
        wakeLock = wl;
    }

    private static void forceInteractive(PowerManager pm) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 20 && !pm.isInteractive()) {
                pm.wakeUp(SystemClock.uptimeMillis());
            }
        } catch (Throwable e) {
            Log.d(TAG, "ScreenWaker: wakeUp unavailable: " + e.getMessage());
        }
    }

    private static synchronized void ensureNonSecureKeyguardDismissal(Context app) {
        if (keyguardLock != null) return;
        try {
            @SuppressWarnings("deprecation")
            KeyguardManager km =
                    (KeyguardManager) app.getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null) {
                @SuppressWarnings("deprecation")
                KeyguardManager.KeyguardLock kl = km.newKeyguardLock(WAKE_TAG);
                kl.disableKeyguard();
                keyguardLock = kl;
            }
        } catch (Exception e) {
            // Secure PIN/pattern/biometric lock is intentionally not bypassed.
            Log.d(TAG, "ScreenWaker: secure lock remains active");
        }
    }

    private static synchronized void scheduleKeepAlive() {
        HANDLER.removeCallbacks(KEEP_ALIVE);
        HANDLER.postDelayed(KEEP_ALIVE, KEEP_ALIVE_MS);
    }

    private static final Runnable KEEP_ALIVE = new Runnable() {
        @Override public void run() {
            synchronized (ScreenWaker.class) {
                if (!active || appContext == null) return;
                try {
                    PowerManager pm = (PowerManager)
                            appContext.getSystemService(Context.POWER_SERVICE);
                    if (pm != null) {
                        // If Funtouch dimmed/turned the display off despite the
                        // wake lock, explicitly wake it again.
                        forceInteractive(pm);
                        ensureWakeLock(pm);
                        if (wakeLock != null) {
                            if (wakeLock.isHeld()) wakeLock.release();
                            wakeLock.acquire(LOCK_WINDOW_MS);
                        }
                    }
                    logThrottled("ScreenWaker: keep-awake refresh");
                } catch (Exception e) {
                    Log.w(TAG, "ScreenWaker: refresh gagal: " + e.getMessage());
                }
                if (active) HANDLER.postDelayed(this, KEEP_ALIVE_MS);
            }
        }
    };

    private static void logThrottled(String message) {
        long now = System.currentTimeMillis();
        if (now - lastLogAt >= 30_000L) {
            lastLogAt = now;
            Log.i(TAG, message);
        }
    }

    static synchronized void release() {
        active = false;
        HANDLER.removeCallbacks(KEEP_ALIVE);
        appContext = null;

        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
        } finally {
            wakeLock = null;
        }

        try {
            if (keyguardLock != null) {
                keyguardLock.reenableKeyguard();
            }
        } catch (Exception ignored) {
        } finally {
            keyguardLock = null;
        }

        Log.i(TAG, "ScreenWaker: claim selesai -> layar kembali normal");
    }
}
