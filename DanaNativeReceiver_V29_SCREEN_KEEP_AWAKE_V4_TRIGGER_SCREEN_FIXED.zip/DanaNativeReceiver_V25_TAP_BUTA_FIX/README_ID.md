# DanaNativeReceiver V25

V25 menggunakan 10 titik kandidat tap di area amplop DANA Kaget. Setiap percobaan menggunakan titik berbeda. Jika hasil klaim berhasil dikonfirmasi oleh UI DANA, koordinat normalisasi tepat yang berhasil disimpan secara persisten di SharedPreferences dan diprioritaskan pada klaim berikutnya. Jika titik tersimpan gagal, sistem tetap melakukan scan kandidat lain. Gesture COMPLETED tidak dianggap sebagai bukti sukses.

VersionCode: 25
VersionName: 1.24-10point-learning-envelope-tap
