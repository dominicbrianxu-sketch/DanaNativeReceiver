package id.varino.danareceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "DanaReceiver";
    private static final String PREFS = "dana_receiver";

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : "";
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            return;
        }

        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        boolean enabled = p.getBoolean("enabled", false);
        if (!enabled) {
            Log.i(TAG, "Receiver belum diaktifkan; boot/update tidak memulai service.");
            return;
        }

        try {
            Intent service = new Intent(context, NtfyService.class);
            service.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
            Log.i(TAG, "Receiver dimulai otomatis setelah boot/update aplikasi.");
        } catch (Exception e) {
            Log.e(TAG, "Gagal memulai receiver setelah boot/update", e);
        }
    }
}
