package id.varino.danareceiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/**
 * Full diagnostic trace for DANA Native Receiver.
 *
 * Writes every diagnostic line to Logcat, keeps a rolling timeline for the
 * notification, and persists the full current-session trace to internal app
 * storage so it can be viewed from MainActivity without adb/logcat.
 * Sensitive tokens and DANA claim codes are masked before persistence.
 */
public final class DebugTrace {
    private static final String TAG = "DanaDebugTrace";
    private static final String CHANNEL = "dana_debug_trace";
    private static final int NOTIF_ID = 3001;
    private static final int MAX_NOTIFICATION_LINES = 55;
    private static final int MAX_PERSISTED_LINES = 600;
    private static final Object LOCK = new Object();
    private static final ArrayDeque<String> LINES = new ArrayDeque<>();
    private static long startedAt = 0L;
    private static int seq = 0;
    private static boolean active = false;
    private static String lastWaitMessage = "";
    private static long lastWaitAt = 0L;

    private DebugTrace() {}

    public static void start(Context context, String title) {
        synchronized (LOCK) {
            startedAt = System.currentTimeMillis();
            seq = 0;
            active = true;
            LINES.clear();
            lastWaitMessage = "";
            lastWaitAt = 0L;
        }
        clearPersisted(context);
        add(context, "START", "🔵", title == null ? "Proses dimulai" : title);
    }

    public static void step(Context context, String message) {
        add(context, "INFO", "🟢", message);
    }

    public static void detail(Context context, String message) {
        add(context, "DETAIL", "🔎", message);
    }

    public static void wait(Context context, String message) {
        long now = System.currentTimeMillis();
        synchronized (LOCK) {
            if (message != null && message.equals(lastWaitMessage) && now - lastWaitAt < 1200L) {
                return;
            }
            lastWaitMessage = message == null ? "" : message;
            lastWaitAt = now;
        }
        add(context, "WAIT", "🟡", message);
    }

    public static void success(Context context, String message) {
        add(context, "SUCCESS", "🟢", message);
    }

    public static void fail(Context context, String message) {
        add(context, "FAIL", "🔴", message);
    }

    public static void warn(Context context, String message) {
        add(context, "WARN", "🟠", message);
    }

    public static void finish(Context context, String message) {
        add(context, "DONE", "🔵", message);
        synchronized (LOCK) { active = false; }
        postNotification(context == null ? null : context.getApplicationContext());
    }

    public static String maskUrl(String url) {
        if (url == null || url.isEmpty()) return "(kosong)";
        try {
            android.net.Uri u = android.net.Uri.parse(url);
            String c = u.getQueryParameter("c");
            if (c != null) {
                return url.substring(0, Math.max(0, url.indexOf("?c="))) + "?c=****";
            }
        } catch (Exception ignored) {}
        return url.length() > 70 ? url.substring(0, 67) + "..." : url;
    }

    public static String snapshot() {
        synchronized (LOCK) {
            StringBuilder sb = new StringBuilder();
            for (String line : LINES) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(line);
            }
            return sb.toString();
        }
    }

    public static String fullSnapshot(Context context) {
        if (context == null) return snapshot();
        File f = new File(context.getFilesDir(), "dana_debug_trace.log");
        if (!f.exists()) return snapshot();
        try {
            byte[] data = java.nio.file.Files.readAllBytes(f.toPath());
            return new String(data, StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.e(TAG, "Gagal membaca trace file", e);
            return snapshot();
        }
    }

    public static boolean isActive() {
        synchronized (LOCK) { return active; }
    }

    public static void clearPersisted(Context context) {
        if (context == null) return;
        try {
            File f = new File(context.getFilesDir(), "dana_debug_trace.log");
            if (f.exists()) f.delete();
        } catch (Exception e) {
            Log.e(TAG, "Gagal membersihkan trace file", e);
        }
    }

    private static void add(Context context, String level, String icon, String message) {
        long now = System.currentTimeMillis();
        String time = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date(now));
        long elapsed;
        int n;
        String line;
        synchronized (LOCK) {
            if (!active && LINES.isEmpty()) {
                startedAt = now;
                active = true;
            }
            elapsed = Math.max(0L, now - startedAt);
            n = ++seq;
            String safe = sanitize(message);
            line = String.format(Locale.US, "%s +%6dms %s [%03d] %s %s",
                    time, elapsed, level, n, icon, safe);
            while (LINES.size() >= MAX_NOTIFICATION_LINES) LINES.removeFirst();
            LINES.addLast(line);
            Log.i(TAG, line);
        }
        persistLine(context, line);
        if (context != null) postNotification(context.getApplicationContext());
    }

    private static void persistLine(Context context, String line) {
        if (context == null || line == null) return;
        try {
            File f = new File(context.getFilesDir(), "dana_debug_trace.log");
            FileOutputStream out = new FileOutputStream(f, true);
            out.write((line + "\n").getBytes(StandardCharsets.UTF_8));
            out.close();
            trimPersistedFile(f);
        } catch (Exception e) {
            Log.e(TAG, "Gagal menyimpan trace", e);
        }
    }

    private static void trimPersistedFile(File f) {
        try {
            byte[] data = java.nio.file.Files.readAllBytes(f.toPath());
            String all = new String(data, StandardCharsets.UTF_8);
            String[] lines = all.split("\\R");
            if (lines.length <= MAX_PERSISTED_LINES) return;
            StringBuilder sb = new StringBuilder();
            int start = lines.length - MAX_PERSISTED_LINES;
            for (int i = start; i < lines.length; i++) {
                if (lines[i].isEmpty()) continue;
                sb.append(lines[i]).append('\n');
            }
            FileOutputStream out = new FileOutputStream(f, false);
            out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            out.close();
        } catch (Exception e) {
            Log.e(TAG, "Gagal trim trace", e);
        }
    }

    private static String sanitize(String message) {
        if (message == null) return "(null)";
        String s = message.replace('\n', ' ').replace('\r', ' ');
        s = s.replaceAll("(?i)(token\\s*[=:]\\s*)[^\\s,}]+", "$1****");
        s = s.replaceAll("(?i)(authorization\\s*[=:]\\s*)[^\\s,}]+", "$1****");
        s = s.replaceAll("https://link\\.dana\\.id/danakaget\\?c=[^\\s&]+", "https://link.dana.id/danakaget?c=****");
        if (s.length() > 420) s = s.substring(0, 417) + "...";
        return s;
    }

    private static void postNotification(Context context) {
        if (context == null) return;
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL, "DANA Debug Process", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Full timeline troubleshooting DANA Native Receiver");
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(context, MainActivity.class);
            open.putExtra("show_debug", true);
            PendingIntent pi = PendingIntent.getActivity(context, NOTIF_ID, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            String body = snapshot();
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(context, CHANNEL)
                    : new Notification.Builder(context);
            Notification.BigTextStyle style = new Notification.BigTextStyle()
                    .setBigContentTitle("DANA Receiver • FULL DEBUG")
                    .bigText(body);
            Notification n = b.setContentTitle("DANA Receiver • FULL DEBUG")
                    .setContentText(lastLine(body))
                    .setStyle(style)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .setOnlyAlertOnce(true)
                    .setOngoing(active)
                    .setCategory(Notification.CATEGORY_STATUS)
                    .build();
            nm.notify(NOTIF_ID, n);
        } catch (Exception e) {
            Log.e(TAG, "Gagal update debug notification", e);
        }
    }

    private static String lastLine(String body) {
        if (body == null || body.isEmpty()) return "Belum ada log";
        int p = body.lastIndexOf('\n');
        String s = p >= 0 ? body.substring(p + 1) : body;
        return s.length() > 180 ? s.substring(0, 177) + "..." : s;
    }
}
