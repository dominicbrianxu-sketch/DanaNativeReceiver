package id.varino.danareceiver;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;

public class MainActivity extends Activity {
    private static final String PREFS = "dana_receiver";
    private EditText server, topic, token, botToken, botChatId, botReportChatId, botDeviceId;
    private TextView status;
    private TextView autoClickStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);

        // V30: three-page horizontal UI. No vertical scrolling is required on the
        // main screen, so it remains usable on devices where vertical scrolling
        // is unreliable. Users can swipe left/right or use the navigation buttons.
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 12);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView header = new TextView(this);
        header.setText("DANA Native Receiver V30");
        header.setTextSize(22);
        header.setPadding(8, 8, 8, 12);
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        android.widget.HorizontalScrollView pagesScroll = new android.widget.HorizontalScrollView(this);
        pagesScroll.setHorizontalScrollBarEnabled(false);
        pagesScroll.setFillViewport(true);
        pagesScroll.setSmoothScrollingEnabled(true);
        pagesScroll.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        pagesScroll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.HORIZONTAL);
        pages.setLayoutParams(new android.widget.HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout page1 = makePage();
        LinearLayout page2 = makePage();
        LinearLayout page3 = makePage();
        pages.addView(page1);
        pages.addView(page2);
        pages.addView(page3);
        pagesScroll.addView(pages);
        root.addView(pagesScroll);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(android.view.Gravity.CENTER_VERTICAL);
        nav.setPadding(0, 8, 0, 0);

        Button prev = new Button(this);
        prev.setText("◀ SEBELUMNYA");
        Button next = new Button(this);
        next.setText("BERIKUTNYA ▶");
        TextView pageNo = new TextView(this);
        pageNo.setText("  1 / 3  ");
        pageNo.setTextSize(16);
        pageNo.setGravity(android.view.Gravity.CENTER);

        nav.addView(prev, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        nav.addView(pageNo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        nav.addView(next, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(nav);

        final int[] currentPage = {0};
        Runnable updateNav = () -> {
            pageNo.setText("  " + (currentPage[0] + 1) + " / 3  ");
            prev.setEnabled(currentPage[0] > 0);
            next.setEnabled(currentPage[0] < 2);
        };
        java.util.function.IntConsumer goToPage = idx -> {
            currentPage[0] = Math.max(0, Math.min(2, idx));
            pagesScroll.smoothScrollTo(currentPage[0] * Math.max(1, pagesScroll.getWidth()), 0);
            updateNav.run();
        };
        prev.setOnClickListener(v -> goToPage.accept(currentPage[0] - 1));
        next.setOnClickListener(v -> goToPage.accept(currentPage[0] + 1));

        // Swipe left/right changes pages. Buttons remain available as a fallback.
        pagesScroll.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            int w = pagesScroll.getWidth();
            if (w > 0) {
                for (int i = 0; i < pages.getChildCount(); i++) {
                    pages.getChildAt(i).getLayoutParams().width = w;
                    pages.getChildAt(i).requestLayout();
                }
                pagesScroll.post(updateNav);
            }
        });
        pagesScroll.setOnTouchListener(new View.OnTouchListener() {
            float downX;
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    downX = e.getX();
                    return false;
                }
                if (e.getAction() == android.view.MotionEvent.ACTION_UP) {
                    float dx = e.getX() - downX;
                    if (Math.abs(dx) > 90) {
                        if (dx < 0) goToPage.accept(currentPage[0] + 1);
                        else goToPage.accept(currentPage[0] - 1);
                        return true;
                    }
                }
                return false;
            }
        });

        // PAGE 1 — Receiver
        TextView title1 = new TextView(this);
        title1.setText("1. DANA RECEIVER");
        title1.setTextSize(20);
        page1.addView(title1);
        TextView info1 = new TextView(this);
        info1.setText("Receiver, auto-click, Accessibility, dan tes buka DANA.");
        page1.addView(info1);

        server = field("Server ntfy", p.getString("server", "https://ntfy.sh"));
        topic = field("Topic", p.getString("topic", ""));
        token = field("Token", p.getString("token", ""));
        token.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        page1.addView(server); page1.addView(topic); page1.addView(token);

        Button saveStart = new Button(this);
        saveStart.setText("Simpan & Aktifkan Receiver"); page1.addView(saveStart);
        Button accessibility = new Button(this);
        accessibility.setText("Aktifkan Auto Klik DANA"); page1.addView(accessibility);
        autoClickStatus = new TextView(this); page1.addView(autoClickStatus);
        Button stop = new Button(this);
        stop.setText("Matikan Receiver"); page1.addView(stop);
        Button testDana = new Button(this);
        testDana.setText("Tes Buka Aplikasi DANA"); page1.addView(testDana);

        // PAGE 2 — Telegram
        TextView title2 = new TextView(this);
        title2.setText("2. TELEGRAM"); title2.setTextSize(20); page2.addView(title2);
        TextView info2 = new TextView(this);
        info2.setText("Command dan Report memakai Chat ID terpisah."); page2.addView(info2);
        botToken = field("Telegram Bot Token", p.getString("telegram_bot_token", ""));
        botToken.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        botChatId = field("Telegram Command Chat ID (Danabot)", p.getString("telegram_command_chat_id", p.getString("telegram_chat_id", "5837001530")));
        botReportChatId = field("Telegram Report Chat ID (Dana Report)", p.getString("telegram_report_chat_id", p.getString("telegram_chat_id", "5353300549")));
        botDeviceId = field("Telegram Device ID", p.getString("telegram_device_id", ""));
        page2.addView(botToken); page2.addView(botChatId); page2.addView(botReportChatId); page2.addView(botDeviceId);
        Button testTelegram = new Button(this);
        testTelegram.setText("TES KONEKSI TELEGRAM"); page2.addView(testTelegram);

        // PAGE 3 — Debug / Status
        TextView title3 = new TextView(this);
        title3.setText("3. DEBUG & STATUS"); title3.setTextSize(20); page3.addView(title3);
        TextView info3 = new TextView(this);
        info3.setText("Debug lengkap dan status receiver."); page3.addView(info3);
        Button debug = new Button(this);
        debug.setText("LIHAT DEBUG LENGKAP"); page3.addView(debug);
        status = new TextView(this);
        status.setText("\nStatus: memuat..."); page3.addView(status);

        saveStart.setOnClickListener(v -> {
            String s = server.getText().toString().trim();
            String t = topic.getText().toString().trim();
            String k = token.getText().toString().trim();
            String bt = botToken.getText().toString().trim();
            String bc = botChatId.getText().toString().trim();
            String br = botReportChatId.getText().toString().trim();
            String bd = botDeviceId.getText().toString().trim();
            p.edit().putString("server", s).putString("topic", t).putString("token", k)
                    .putString("telegram_bot_token", bt).putString("telegram_chat_id", bc)
                    .putString("telegram_command_chat_id", bc).putString("telegram_report_chat_id", br)
                    .putString("telegram_device_id", bd)
                    .putBoolean("telegram_bot_enabled", !bt.isEmpty() && !bc.isEmpty())
                    .putBoolean("enabled", true).apply();
            if (bt.isEmpty() || bc.isEmpty() || br.isEmpty())
                status.setText("\nStatus: receiver aktif, tetapi Telegram command/report belum lengkap.");
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
            Intent i = new Intent(this, NtfyService.class); i.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            startTelegramBotService();
            status.setText("\nStatus: receiver AKTIF dan akan otomatis hidup lagi setelah HP restart.");
            refreshAccessibilityStatus();
        });
        accessibility.setOnClickListener(v -> { try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
        stop.setOnClickListener(v -> {
            p.edit().putBoolean("enabled", false).apply();
            Intent i = new Intent(this, NtfyService.class); i.setAction(NtfyService.ACTION_STOP); startService(i);
            status.setText("\nStatus: receiver dimatikan dan tidak akan otomatis hidup setelah restart.");
        });
        testDana.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://link.dana.id/danakaget?c=TEST")); i.setPackage("id.dana");
            try { startActivity(i); status.setText("\nStatus: perintah membuka aplikasi DANA dikirim."); }
            catch (Exception e) { status.setText("\nStatus: aplikasi DANA tidak ditemukan/Android menolak pembukaan."); }
        });
        testTelegram.setOnClickListener(v -> {
            SharedPreferences tp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String bt = tp.getString("telegram_bot_token", "").trim();
            String bc = tp.getString("telegram_report_chat_id", tp.getString("telegram_chat_id", "")).trim();
            if (bt.isEmpty() || bc.isEmpty()) { status.setText("\nStatus: isi Telegram Bot Token dan Chat ID terlebih dahulu."); return; }
            TelegramBotController.sendReport(this, "🧪 TEST TELEGRAM BERHASIL\n📱 Device: " + TelegramBotController.get(this).deviceId() + "\n💬 Chat ID: " + bc + "\nJika pesan ini masuk, koneksi Bot API → Telegram sudah OK.");
            status.setText("\nStatus: pesan test Telegram dikirim. Cek chat ID yang diisi.");
        });
        debug.setOnClickListener(v -> showDebugDialog());

        boolean enabled = p.getBoolean("enabled", false);
        if (enabled && !topic.getText().toString().trim().isEmpty() && !token.getText().toString().trim().isEmpty()) {
            Intent auto = new Intent(this, NtfyService.class); auto.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(auto); else startService(auto);
            startTelegramBotService(); status.setText("\nStatus: receiver AKTIF (otomatis).");
        } else status.setText("\nStatus: receiver belum aktif.");

        setContentView(root);
        pagesScroll.post(updateNav);
        startTelegramBotService();
        refreshAccessibilityStatus();
        if (getIntent().getBooleanExtra("show_debug", false)) pagesScroll.postDelayed(this::showDebugDialog, 250L);
    }

    private LinearLayout makePage() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(12, 8, 12, 24);
        page.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return page;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (autoClickStatus != null) refreshAccessibilityStatus();
    }

    private void startTelegramBotService() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("telegram_bot_enabled", false)) return;
        Intent i = new Intent(this, TelegramBotService.class);
        i.setAction(TelegramBotService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void refreshAccessibilityStatus() {
        boolean enabled = DanaAutoClickAccessibilityService.isEnabled(this);
        autoClickStatus.setText("Auto Klik: " + (enabled ? "AKTIF ✓" : "BELUM AKTIF — aktifkan di Pengaturan Aksesibilitas"));
    }

    private void showDebugDialog() {
        final String trace = DebugTrace.fullSnapshot(this);
        ScrollView scroll = new ScrollView(this);
        TextView view = new TextView(this);
        view.setText(trace.isEmpty() ? "Belum ada debug trace." : trace);
        view.setTextIsSelectable(true);
        view.setTextSize(11);
        view.setPadding(24, 24, 24, 24);
        scroll.addView(view);
        new android.app.AlertDialog.Builder(this)
                .setTitle("DANA • DEBUG LENGKAP")
                .setView(scroll)
                .setPositiveButton("Tutup", null)
                .setNeutralButton("Hapus Log", (d, w) -> {
                    DebugTrace.clearPersisted(this);
                })
                .show();
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }
}
