package id.varino.danareceiver;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREFS = "dana_receiver";
    private EditText server, topic, token, botToken, botChatId, botReportChatId, botDeviceId;
    private TextView status;
    private TextView autoClickStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 10, 12, 8);
        root.setBackgroundColor(0xFFFFFFFF);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView header = new TextView(this);
        header.setText("DANA Native Receiver V30");
        header.setTextSize(21);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(8, 2, 8, 6);
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // NAVIGATION SELALU DI PALING ATAS.
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setPadding(0, 0, 0, 6);

        Button prev = new Button(this);
        prev.setText("◀ PREVIEW");
        prev.setTextSize(12);
        Button next = new Button(this);
        next.setText("NEXT ▶");
        next.setTextSize(12);
        TextView pageNo = new TextView(this);
        pageNo.setText("  1 / 3  ");
        pageNo.setTextSize(15);
        pageNo.setGravity(Gravity.CENTER);

        nav.addView(prev, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        nav.addView(pageNo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        nav.addView(next, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(nav);

        HorizontalScrollView pagesScroll = new HorizontalScrollView(this);
        pagesScroll.setHorizontalScrollBarEnabled(false);
        pagesScroll.setFillViewport(true);
        pagesScroll.setSmoothScrollingEnabled(true);
        pagesScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        pagesScroll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.HORIZONTAL);
        pages.setLayoutParams(new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Setiap halaman punya ScrollView sendiri. Jadi tombol NEXT/PREVIEW tetap
        // berada di atas, sementara isi halaman tetap dapat digulir bila layar kecil.
        ScrollView page1Scroll = makePageScroll();
        ScrollView page2Scroll = makePageScroll();
        ScrollView page3Scroll = makePageScroll();
        LinearLayout page1 = pageContent();
        LinearLayout page2 = pageContent();
        LinearLayout page3 = pageContent();
        page1Scroll.addView(page1);
        page2Scroll.addView(page2);
        page3Scroll.addView(page3);
        pages.addView(page1Scroll);
        pages.addView(page2Scroll);
        pages.addView(page3Scroll);
        pagesScroll.addView(pages);
        root.addView(pagesScroll);

        final int[] currentPage = {0};

        Runnable updateNav = () -> {
            pageNo.setText("  " + (currentPage[0] + 1) + " / 3  ");
            prev.setEnabled(currentPage[0] > 0);
            next.setEnabled(currentPage[0] < 2);
        };

        java.util.function.IntConsumer goToPage = idx -> {
            currentPage[0] = Math.max(0, Math.min(2, idx));
            pagesScroll.post(() -> {
                int w = pagesScroll.getWidth();
                if (w > 0) pagesScroll.smoothScrollTo(currentPage[0] * w, 0);
            });
            updateNav.run();
        };

        prev.setOnClickListener(v -> goToPage.accept(currentPage[0] - 1));
        next.setOnClickListener(v -> goToPage.accept(currentPage[0] + 1));

        // Swipe kiri/kanan sebagai alternatif tombol.
        pagesScroll.setOnTouchListener(new View.OnTouchListener() {
            float downX;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getX();
                    return false;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    float dx = e.getX() - downX;
                    if (Math.abs(dx) > 90) {
                        if (dx < 0) goToPage.accept(currentPage[0] + 1);
                        else goToPage.accept(currentPage[0] - 1);
                        return true;
                    }
                }
                return false;
            }
        });

        pagesScroll.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            int w = pagesScroll.getWidth();
            int h = pagesScroll.getHeight();
            if (w > 0) {
                for (int i = 0; i < pages.getChildCount(); i++) {
                    View child = pages.getChildAt(i);
                    ViewGroup.LayoutParams lp = child.getLayoutParams();
                    if (lp.width != w || lp.height != h) {
                        lp.width = w;
                        lp.height = h;
                        child.setLayoutParams(lp);
                    }
                }
                pagesScroll.post(updateNav);
            }
        });

        // ==============================
        // PAGE 1 - DANA RECEIVER
        // ==============================
        addTitle(page1, "1. DANA RECEIVER");
        addInfo(page1, "Receiver DANA, auto-open, auto-click, QR, dan Accessibility.");

        server = field("Server ntfy", p.getString("server", "https://ntfy.sh"));
        topic = field("Topic", p.getString("topic", ""));
        token = field("Token", p.getString("token", ""));
        token.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        page1.addView(server);
        page1.addView(topic);
        page1.addView(token);

        Button saveStart = button("SIMPAN & AKTIFKAN RECEIVER");
        page1.addView(saveStart);
        Button accessibility = button("AKTIFKAN AUTO KLIK DANA");
        page1.addView(accessibility);
        autoClickStatus = new TextView(this);
        autoClickStatus.setPadding(4, 4, 4, 8);
        page1.addView(autoClickStatus);
        Button stop = button("MATIKAN RECEIVER");
        page1.addView(stop);
        Button testDana = button("TES BUKA APLIKASI DANA");
        page1.addView(testDana);

        // ==============================
        // PAGE 2 - TELEGRAM
        // ==============================
        addTitle(page2, "2. TELEGRAM");
        addInfo(page2, "Bot command dan laporan Telegram.");
        botToken = field("Telegram Bot Token", p.getString("telegram_bot_token", ""));
        botToken.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        // Dari trace terakhir: 5837001530 adalah chat yang masuk dari Danabot,
        // sedangkan 5353300549 adalah grup Dana Report.
        botChatId = field("Telegram Command Chat ID (Danabot)",
                p.getString("telegram_command_chat_id", "5837001530"));
        botReportChatId = field("Telegram Report Chat ID (Dana Report)",
                p.getString("telegram_report_chat_id", "5353300549"));
        botDeviceId = field("Telegram Device ID", p.getString("telegram_device_id", ""));
        page2.addView(botToken);
        page2.addView(botChatId);
        page2.addView(botReportChatId);
        page2.addView(botDeviceId);
        addInfo(page2, "Command Chat ID = chat tempat command bot diterima.\nReport Chat ID = grup tujuan laporan.");
        Button testTelegram = button("TES KONEKSI TELEGRAM");
        page2.addView(testTelegram);

        // ==============================
        // PAGE 3 - DEBUG & STATUS
        // ==============================
        addTitle(page3, "3. DEBUG & STATUS");
        addInfo(page3, "Status receiver dan debug trace.");
        Button debug = button("LIHAT DEBUG LENGKAP");
        page3.addView(debug);
        status = new TextView(this);
        status.setText("\nStatus: memuat...");
        status.setTextIsSelectable(true);
        status.setPadding(4, 8, 4, 20);
        page3.addView(status);

        // ==============================
        // ACTIONS
        // ==============================
        saveStart.setOnClickListener(v -> {
            String s = server.getText().toString().trim();
            String t = topic.getText().toString().trim();
            String k = token.getText().toString().trim();
            String bt = botToken.getText().toString().trim();
            String bc = botChatId.getText().toString().trim();
            String br = botReportChatId.getText().toString().trim();
            String bd = botDeviceId.getText().toString().trim();

            p.edit()
                    .putString("server", s)
                    .putString("topic", t)
                    .putString("token", k)
                    .putString("telegram_bot_token", bt)
                    .putString("telegram_chat_id", bc)
                    .putString("telegram_command_chat_id", bc)
                    .putString("telegram_report_chat_id", br)
                    .putString("telegram_device_id", bd)
                    .putBoolean("telegram_bot_enabled", !bt.isEmpty() && !bc.isEmpty())
                    .putBoolean("enabled", true)
                    .apply();

            if (bt.isEmpty() || bc.isEmpty() || br.isEmpty()) {
                status.setText("\nStatus: receiver aktif, tetapi Telegram command/report belum lengkap.");
            }

            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
            }

            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            startTelegramBotService();

            status.setText("\nStatus: receiver AKTIF dan akan otomatis hidup lagi setelah HP restart.");
            refreshAccessibilityStatus();
        });

        accessibility.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });

        stop.setOnClickListener(v -> {
            p.edit().putBoolean("enabled", false).apply();
            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_STOP);
            startService(i);
            status.setText("\nStatus: receiver dimatikan dan tidak akan otomatis hidup setelah restart.");
        });

        testDana.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://link.dana.id/danakaget?c=TEST"));
            i.setPackage("id.dana");
            try {
                startActivity(i);
                status.setText("\nStatus: perintah membuka aplikasi DANA dikirim.");
            } catch (Exception e) {
                status.setText("\nStatus: aplikasi DANA tidak ditemukan/Android menolak pembukaan.");
            }
        });

        testTelegram.setOnClickListener(v -> {
            SharedPreferences tp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String bt = tp.getString("telegram_bot_token", "").trim();
            String bc = tp.getString("telegram_report_chat_id", "").trim();
            if (bt.isEmpty() || bc.isEmpty()) {
                status.setText("\nStatus: isi Telegram Bot Token dan Report Chat ID terlebih dahulu.");
                return;
            }
            TelegramBotController.sendReport(this,
                    "🧪 TEST TELEGRAM BERHASIL\n📱 Device: " +
                            TelegramBotController.get(this).deviceId() +
                            "\n💬 Report Chat ID: " + bc +
                            "\nJika pesan ini masuk, koneksi Bot API → Telegram sudah OK.");
            status.setText("\nStatus: pesan test Telegram dikirim ke Report Chat ID.");
        });

        debug.setOnClickListener(v -> showDebugDialog());

        boolean enabled = p.getBoolean("enabled", false);
        if (enabled && !topic.getText().toString().trim().isEmpty()
                && !token.getText().toString().trim().isEmpty()) {
            Intent auto = new Intent(this, NtfyService.class);
            auto.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(auto); else startService(auto);
            startTelegramBotService();
            status.setText("\nStatus: receiver AKTIF (otomatis).");
        } else {
            status.setText("\nStatus: receiver belum aktif.");
        }

        setContentView(root);
        pagesScroll.post(updateNav);
        startTelegramBotService();
        refreshAccessibilityStatus();
        if (getIntent().getBooleanExtra("show_debug", false)) {
            pagesScroll.postDelayed(this::showDebugDialog, 250L);
        }
    }

    private ScrollView makePageScroll() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return scroll;
    }

    private LinearLayout pageContent() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(8, 6, 8, 24);
        page.setLayoutParams(new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return page;
    }

    private void addTitle(LinearLayout page, String text) {
        TextView title = new TextView(this);
        title.setText(text);
        title.setTextSize(20);
        title.setPadding(4, 6, 4, 4);
        page.addView(title);
    }

    private void addInfo(LinearLayout page, String text) {
        TextView info = new TextView(this);
        info.setText(text);
        info.setTextSize(14);
        info.setPadding(4, 2, 4, 8);
        page.addView(info);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (autoClickStatus != null) refreshAccessibilityStatus();
    }

    private void startTelegramBotService() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("telegram_bot_enabled", false)) return;
        Intent i = new Intent(this, TelegramBotService.class);
        i.setAction(TelegramBotService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void refreshAccessibilityStatus() {
        boolean enabled = DanaAutoClickAccessibilityService.isEnabled(this);
        autoClickStatus.setText("Auto Klik: " + (enabled ? "AKTIF ✓" : "BELUM AKTIF — aktifkan di Pengaturan Aksesibilitas"));
    }

    private void showDebugDialog() {
        final String trace = DebugTrace.fullSnapshot(this);
        ScrollView scroll = new ScrollView(this);
        TextView view = new TextView(this);
        view.setText(trace.isEmpty() ? "Belum ada debug trace." : trace);
        view.setTextIsSelectable(true);
        view.setTextSize(11);
        view.setPadding(24, 24, 24, 24);
        scroll.addView(view);
        new android.app.AlertDialog.Builder(this)
                .setTitle("DANA • DEBUG LENGKAP")
                .setView(scroll)
                .setPositiveButton("Tutup", null)
                .setNeutralButton("Hapus Log", (d, w) -> DebugTrace.clearPersisted(this))
                .show();
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setPadding(8, 4, 8, 4);
        e.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }
}
