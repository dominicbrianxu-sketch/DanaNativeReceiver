package id.varino.danareceiver;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Optional Telegram Bot API controller.
 *
 * This class is deliberately isolated from the DANA claim engine. If the bot
 * is not configured, the V27 DANA logic behaves exactly as before.
 *
 * Commands:
 * /start
 * /help
 * /status [device_id]
 * /on [device_id]
 * /off [device_id]
 * /settap <count> [device_id]
 * /setdelay <milliseconds> [device_id]
 * /debug [device_id]
 * /device
 *
 * For direct Bot API polling, use a separate bot token per APK when more than
 * one phone must independently receive commands. Telegram getUpdates is a
 * shared queue for a bot token; two APKs polling the same token compete for
 * the same updates.
 */
public final class TelegramBotController {
    private static final String TAG = "DanaTelegramBot";
    private static final String PREFS = "dana_receiver";
    private static final String KEY_BOT_TOKEN = "telegram_bot_token";
    private static final String KEY_CHAT_ID = "telegram_chat_id";
    private static final String KEY_COMMAND_CHAT_ID = "telegram_command_chat_id";
    private static final String KEY_REPORT_CHAT_ID = "telegram_report_chat_id";
    private static final String KEY_DEVICE_ID = "telegram_device_id";
    private static final String KEY_BOT_ENABLED = "telegram_bot_enabled";
    private static final String KEY_UPDATE_ID = "telegram_update_id";
    private static final int MAX_MESSAGE = 3800;
    private static final long POLL_TIMEOUT_SECONDS = 25L;
    private static final long RECONNECT_MS = 2500L;

    private static volatile TelegramBotController instance;

    private final Context app;
    private final ExecutorService pollExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService sendExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean running;

    private TelegramBotController(Context context) {
        this.app = context.getApplicationContext();
    }

    public static TelegramBotController get(Context context) {
        if (instance == null) {
            synchronized (TelegramBotController.class) {
                if (instance == null) instance = new TelegramBotController(context);
            }
        }
        return instance;
    }

    public static void start(Context context) {
        get(context).startInternal();
    }

    public static void stop(Context context) {
        get(context).stopInternal();
    }

    public static void sendReport(Context context, String text) {
        get(context).sendMessageAsync(text);
    }

    public static void sendClaimReport(Context context, boolean success, String url, String uiText) {
        String device = get(context).deviceId();
        String state = success ? "BERHASIL" : "GAGAL";
        String safeUrl = DebugTrace.maskUrl(url);
        String safeUi = uiText == null ? "" : uiText.replace('\n', ' ').replace('\r', ' ');
        if (safeUi.length() > 900) safeUi = safeUi.substring(0, 900) + "...";
        sendReport(context,
                "📲 DANA CLAIM " + state + "\n" +
                "📱 Device: " + device + "\n" +
                "🔗 URL: " + safeUrl + "\n" +
                "📝 UI: " + safeUi);
    }

    private void startInternal() {
        if (running) return;
        SharedPreferences p = prefs();
        if (!p.getBoolean(KEY_BOT_ENABLED, false)) return;
        if (token().isEmpty() || commandChatId().isEmpty()) return;
        running = true;
        DebugTrace.step(app, "🤖 Telegram Bot Controller mulai");
        DebugTrace.detail(app, "Telegram polling siap; commandChat=" + commandChatId() + " reportChat=" + reportChatId() + " device=" + deviceId());
        pollExecutor.execute(this::pollLoop);
    }

    private void stopInternal() {
        running = false;
        DebugTrace.step(app, "🤖 Telegram Bot Controller dihentikan");
    }

    private void pollLoop() {
        try {
            verifyTelegramConnection();
            deleteWebhook();
        } catch (Exception e) {
            DebugTrace.fail(app, "Telegram startup check gagal: " + e.getMessage());
        }
        sendMessageAsync("🟢 APK Bot Controller aktif\n📱 Device: " + deviceId() + "\n⌨️ Command Chat: " + commandChatId() + "\n📢 Report Chat: " + reportChatId());

        while (running) {
            try {
                String response = getUpdates();
                if (response == null || response.isEmpty()) {
                    Thread.sleep(RECONNECT_MS);
                    continue;
                }
                JSONObject root = new JSONObject(response);
                if (!root.optBoolean("ok", false)) {
                    String description = compact(root.optString("description", "unknown"));
                    DebugTrace.fail(app, "Telegram API error: " + description);
                    if (description.toLowerCase(Locale.US).contains("conflict")) {
                        DebugTrace.fail(app, "Telegram getUpdates 409: bot token sedang dipakai polling/webhook oleh proses lain");
                    }
                    Thread.sleep(RECONNECT_MS);
                    continue;
                }
                JSONArray result = root.optJSONArray("result");
                if (result == null) continue;
                for (int i = 0; i < result.length(); i++) {
                    JSONObject update = result.optJSONObject(i);
                    if (update == null) continue;
                    long id = update.optLong("update_id", -1L);
                    if (id >= 0) saveUpdateId(id + 1L);
                    DebugTrace.step(app, "🤖 Telegram update diterima update_id=" + id);
                    handleUpdate(update);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                Log.e(TAG, "Bot polling error", e);
                try { Thread.sleep(RECONNECT_MS); } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
    }

    private String getUpdates() throws Exception {
        long offset = prefs().getLong(KEY_UPDATE_ID, 0L);
        String base = "https://api.telegram.org/bot" + token() + "/getUpdates";
        String query = "timeout=" + POLL_TIMEOUT_SECONDS + "&allowed_updates=" +
                URLEncoder.encode("[\"message\"]", "UTF-8");
        if (offset > 0L) query += "&offset=" + offset;

        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(base + "?" + query).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(15000);
            c.setReadTimeout((int) ((POLL_TIMEOUT_SECONDS + 10L) * 1000L));
            String response = read(c);
            int code = c.getResponseCode();
            if (code != 200) {
                DebugTrace.fail(app, "Telegram getUpdates HTTP=" + code + " response=" + compact(response));
            } else {
                DebugTrace.detail(app, "Telegram getUpdates HTTP=200 bytes=" + response.length());
            }
            return response;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void handleUpdate(JSONObject update) {
        try {
            JSONObject message = update.optJSONObject("message");
            if (message == null) return;
            JSONObject chat = message.optJSONObject("chat");
            if (chat == null) return;

            String incomingChat = String.valueOf(chat.optLong("id", 0L));
            if (!isAllowedChat(incomingChat)) {
                DebugTrace.warn(app, "Telegram chat diabaikan: incoming=" + incomingChat + " commandAllowed=" + commandChatId());
                return;
            }

            String text = message.optString("text", "").trim();
            if (text.isEmpty()) return;
            DebugTrace.step(app, "🤖 Telegram command diterima: " + text);
            processCommand(text, incomingChat);
        } catch (Exception e) {
            Log.e(TAG, "handleUpdate error", e);
        }
    }

    private void processCommand(String text, String chat) {
        String[] a = text.trim().split("\\s+");
        if (a.length == 0) return;
        String command = a[0].toLowerCase(Locale.US);
        if (command.contains("@")) command = command.substring(0, command.indexOf('@'));
        if ("📊".equals(command) || text.equalsIgnoreCase("📊 STATUS")) command = "/status";
        else if (text.equalsIgnoreCase("🟢 ON")) command = "/on";
        else if (text.equalsIgnoreCase("🔴 OFF")) command = "/off";
        else if (text.equalsIgnoreCase("🧾 DEBUG")) command = "/debug";
        else if (text.equalsIgnoreCase("⚙️ SETTING")) command = "/help";

        if (!targetMatches(a)) return;

        switch (command) {
            case "/start":
            case "/help":
                sendMenu(chat, helpText());
                break;
            case "/device":
                reply(chat, "📱 Device ID: " + deviceId() + "\n" + statusText());
                break;
            case "/status":
                reply(chat, statusText());
                break;
            case "/on":
                setReceiver(true);
                reply(chat, "🟢 Receiver ON\n" + statusText());
                break;
            case "/off":
                setReceiver(false);
                reply(chat, "🔴 Receiver OFF\n" + statusText());
                break;
            case "/settap":
                if (a.length < 2) {
                    reply(chat, "Format: /settap 10 [device_id]");
                    return;
                }
                try {
                    int count = Integer.parseInt(a[1]);
                    if (count < 1 || count > 10) throw new NumberFormatException();
                    prefs().edit().putInt("remote_tap_count", count).apply();
                    reply(chat, "✅ Tap count = " + count + "\nBerlaku tanpa rebuild.");
                } catch (Exception e) {
                    reply(chat, "❌ Tap count harus 1-10.");
                }
                break;
            case "/setdelay":
                if (a.length < 2) {
                    reply(chat, "Format: /setdelay 650 [device_id]\nSatuan: milliseconds");
                    return;
                }
                try {
                    long ms = Long.parseLong(a[1]);
                    if (ms < 50L || ms > 10000L) throw new NumberFormatException();
                    prefs().edit().putLong("remote_tap_delay_ms", ms).apply();
                    reply(chat, "✅ Tap delay = " + ms + " ms\nBerlaku tanpa rebuild.");
                } catch (Exception e) {
                    reply(chat, "❌ Delay harus 50-10000 ms.");
                }
                break;
            case "/debug":
                String debug = DebugTrace.fullSnapshot(app);
                if (debug.isEmpty()) debug = "Belum ada debug trace.";
                sendLong(chat, "🧾 DEBUG " + deviceId() + "\n" + debug);
                break;
            default:
                reply(chat, "❓ Command tidak dikenal. Gunakan /help");
        }
    }

    private boolean targetMatches(String[] a) {
        if (a.length < 2) return true;
        String last = a[a.length - 1];
        if (last.startsWith("DANA-") || last.startsWith("device-")) {
            return deviceId().equalsIgnoreCase(last);
        }
        return true;
    }

    private void setReceiver(boolean on) {
        prefs().edit().putBoolean("enabled", on).apply();
        IntentHelper.startOrStop(app, on);
    }

    private String statusText() {
        SharedPreferences p = prefs();
        boolean enabled = p.getBoolean("enabled", false);
        boolean bot = p.getBoolean(KEY_BOT_ENABLED, false);
        boolean accessibility = DanaAutoClickAccessibilityService.isEnabled(app);
        int taps = p.getInt("remote_tap_count", 10);
        long delay = p.getLong("remote_tap_delay_ms", 650L);
        return "📱 Device: " + deviceId() +
                "\n🤖 Bot: " + (bot ? "AKTIF" : "OFF") +
                "\n📡 Receiver: " + (enabled ? "ON" : "OFF") +
                "\n♿ Accessibility: " + (accessibility ? "AKTIF" : "OFF") +
                "\n👆 Tap: " + taps +
                "\n⏱ Delay: " + delay + " ms";
    }

    private String helpText() {
        return "🤖 DANA Native Receiver\n\n" +
                "/status [device_id] - status APK\n" +
                "/on [device_id] - hidupkan receiver\n" +
                "/off [device_id] - matikan receiver\n" +
                "/settap 10 [device_id] - jumlah tap\n" +
                "/setdelay 650 [device_id] - delay antar tap (ms)\n" +
                "/debug [device_id] - kirim debug log\n" +
                "/device - lihat device ID\n" +
                "/help - bantuan\n\n" +
                "Default V27 tetap: 10 tap / 650 ms.";
    }

    private void sendMessageAsync(String text) {
        if (text == null || text.trim().isEmpty()) return;
        String chat = primaryChatId();
        if (token().isEmpty() || chat.isEmpty()) return;
        sendExecutor.execute(() -> sendLong(chat, text));
    }

    private void reply(String chat, String text) {
        if (chat == null || chat.isEmpty()) return;
        sendExecutor.execute(() -> sendLong(chat, text));
    }

    private void sendMenu(String chat, String text) {
        if (chat == null || chat.isEmpty()) return;
        sendExecutor.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL("https://api.telegram.org/bot" + token() + "/sendMessage");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                JSONObject body = new JSONObject();
                body.put("chat_id", chat);
                body.put("text", text);

                JSONObject keyboard = new JSONObject();
                keyboard.put("keyboard", new JSONArray()
                        .put(new JSONArray().put("📊 STATUS").put("🟢 ON").put("🔴 OFF"))
                        .put(new JSONArray().put("🧾 DEBUG").put("⚙️ SETTING")));
                keyboard.put("resize_keyboard", true);
                keyboard.put("is_persistent", true);
                body.put("reply_markup", keyboard);

                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = c.getOutputStream()) {
                    out.write(bytes);
                }
                String response = read(c);
                int code = c.getResponseCode();
                if (code == 200) DebugTrace.success(app, "🤖 Telegram sendMessage menu OK");
                else DebugTrace.fail(app, "Telegram sendMessage menu HTTP=" + code + " response=" + compact(response));
            } catch (Exception e) {
                DebugTrace.fail(app, "Telegram sendMenu exception=" + e.getClass().getSimpleName() + ": " + e.getMessage());
                Log.e(TAG, "sendMenu failed", e);
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private void sendLong(String chat, String text) {
        if (text == null) return;
        String s = text;
        int pos = 0;
        while (pos < s.length()) {
            int end = Math.min(pos + MAX_MESSAGE, s.length());
            if (end < s.length()) {
                int nl = s.lastIndexOf('\n', end);
                if (nl > pos + 100) end = nl;
            }
            sendMessage(chat, s.substring(pos, end));
            pos = end;
        }
    }

    private void sendMessage(String chat, String text) {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://api.telegram.org/bot" + token() + "/sendMessage");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            JSONObject body = new JSONObject();
            body.put("chat_id", chat);
            body.put("text", text);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = c.getOutputStream()) {
                out.write(bytes);
            }
            String response = read(c);
            int code = c.getResponseCode();
            if (code == 200) {
                DebugTrace.success(app, "🤖 Telegram sendMessage OK chat=" + chat);
            } else {
                DebugTrace.fail(app, "Telegram sendMessage HTTP=" + code + " response=" + compact(response));
            }
        } catch (Exception e) {
            DebugTrace.fail(app, "Telegram sendMessage exception=" + e.getClass().getSimpleName() + ": " + e.getMessage());
            Log.e(TAG, "sendMessage failed", e);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String compact(String value) {
        if (value == null) return "";
        String s = value.replace('\n', ' ').replace('\r', ' ');
        return s.length() > 240 ? s.substring(0, 237) + "..." : s;
    }

    private String read(HttpURLConnection c) throws Exception {
        InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    /**
     * Persist the next Telegram getUpdates offset.
     *
     * Telegram update_id values are monotonic. Saving the next offset prevents
     * the same command from being processed again after a restart.
     */
    private void saveUpdateId(long nextOffset) {
        if (nextOffset < 0L) return;

        SharedPreferences p = prefs();
        long current = p.getLong(KEY_UPDATE_ID, 0L);
        if (nextOffset > current) {
            p.edit().putLong(KEY_UPDATE_ID, nextOffset).apply();
        }
    }

    private SharedPreferences prefs() {
        return app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private String token() {
        return prefs().getString(KEY_BOT_TOKEN, "").trim();
    }

    /** Supports one or multiple Telegram chat IDs separated by comma/space/newline. */
    private String chatId() {
        return prefs().getString(KEY_CHAT_ID, "").trim();
    }

    /** Chat allowed to send bot commands. Falls back to legacy telegram_chat_id. */
    private String commandChatId() {
        String value = prefs().getString(KEY_COMMAND_CHAT_ID, "").trim();
        return value.isEmpty() ? chatId() : value;
    }

    /** Chat that receives reports/messages. Falls back to legacy telegram_chat_id. */
    private String reportChatId() {
        String value = prefs().getString(KEY_REPORT_CHAT_ID, "").trim();
        return value.isEmpty() ? chatId() : value;
    }

    private String primaryChatId() {
        String raw = reportChatId();
        if (raw.isEmpty()) return "";
        String[] ids = raw.split("[,\\s]+", -1);
        for (String id : ids) {
            if (!id.trim().isEmpty()) return id.trim();
        }
        return "";
    }

    private boolean isAllowedChat(String incoming) {
        if (incoming == null || incoming.trim().isEmpty()) return false;
        String raw = commandChatId();
        if (raw.isEmpty()) return false;
        String[] ids = raw.split("[,\\s]+", -1);
        for (String id : ids) {
            if (incoming.equals(id.trim())) return true;
        }
        return false;
    }

    private void verifyTelegramConnection() throws Exception {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://api.telegram.org/bot" + token() + "/getMe");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            String response = read(c);
            int code = c.getResponseCode();
            if (code != 200) {
                throw new Exception("getMe HTTP=" + code + " " + compact(response));
            }
            JSONObject root = new JSONObject(response);
            if (!root.optBoolean("ok", false)) {
                throw new Exception("getMe: " + compact(root.optString("description", "unknown")));
            }
            JSONObject result = root.optJSONObject("result");
            String username = result == null ? "?" : result.optString("username", "?");
            long id = result == null ? 0L : result.optLong("id", 0L);
            DebugTrace.success(app, "🤖 Telegram getMe OK bot=@" + username + " id=" + id);
            DebugTrace.detail(app, "Telegram command chats=" + commandChatId() + " report chat=" + reportChatId());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void deleteWebhook() {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://api.telegram.org/bot" + token() + "/deleteWebhook?drop_pending_updates=false");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            String response = read(c);
            int code = c.getResponseCode();
            if (code == 200) {
                DebugTrace.success(app, "🤖 Telegram webhook cleared; polling mode siap");
            } else {
                DebugTrace.fail(app, "Telegram deleteWebhook HTTP=" + code + " response=" + compact(response));
            }
        } catch (Exception e) {
            DebugTrace.fail(app, "Telegram deleteWebhook exception=" + e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    public String deviceId() {
        String stored = prefs().getString(KEY_DEVICE_ID, "").trim();
        if (!stored.isEmpty()) return stored;
        String androidId = Settings.Secure.getString(app.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null || androidId.trim().isEmpty()) androidId = "unknown";
        String id = "DANA-" + androidId.toUpperCase(Locale.US);
        prefs().edit().putString(KEY_DEVICE_ID, id).apply();
        return id;
    }

    public static final class IntentHelper {
        private IntentHelper() {}
        static void startOrStop(Context context, boolean on) {
            android.content.Intent i = new android.content.Intent(context, NtfyService.class);
            i.setAction(on ? NtfyService.ACTION_START : NtfyService.ACTION_STOP);
            if (on && Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
            else context.startService(i);
        }
    }
}
