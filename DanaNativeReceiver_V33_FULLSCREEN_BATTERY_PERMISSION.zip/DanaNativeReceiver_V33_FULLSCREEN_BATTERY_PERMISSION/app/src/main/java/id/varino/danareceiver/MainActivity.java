package id.varino.danareceiver;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String PREFS = "dana_receiver";
    private EditText server, topic, token, botToken, botChatId, botReportChatId, botDeviceId;
    private TextView status;
    private TextView autoClickStatus;
    // V33: status gabungan 2 izin sistem yang paling sering jadi penyebab
    // "notif diterima tapi DANA tidak otomatis kebuka" di Android 14/15 dan
    // di HP OEM (Xiaomi/Oppo/Vivo dkk) yang agresif membatasi background.
    private TextView systemPermStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);

        // Full-screen vertical ScrollView. This is intentionally the ROOT view so
        // the complete settings page can always be scrolled on small screens.
        // Extra system-bar insets keep the bottom controls above Android navigation.
        ScrollView scrollRoot = new ScrollView(this);
        scrollRoot.setFillViewport(true);
        scrollRoot.setVerticalScrollBarEnabled(true);
        scrollRoot.setScrollbarFadingEnabled(false);
        scrollRoot.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        scrollRoot.setNestedScrollingEnabled(true);
        scrollRoot.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 32, 32, 64);
        box.setLayoutParams(new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        scrollRoot.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            box.setPadding(32, 32 + top, 32, 64 + bottom);
            return insets;
        });

        // Judul & paragraf penjelasan panjang di layar utama sengaja DIHILANGKAN
        // (dulu di sini: TextView "title" + TextView "info"), supaya tampilan
        // langsung ke form pengaturan tanpa teks yang memenuhi layar.

        server = field("Server ntfy", p.getString("server", "https://ntfy.sh"));
        topic = field("Topic", p.getString("topic", ""));
        token = field("Token", p.getString("token", ""));
        token.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        botToken = field("Telegram Bot Token", p.getString("telegram_bot_token", ""));
        botToken.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        botChatId = field("Telegram Command Chat ID (Danabot)", p.getString("telegram_command_chat_id", p.getString("telegram_chat_id", "5837001530")));
        botReportChatId = field("Telegram Report Chat ID (Dana Report)", p.getString("telegram_report_chat_id", p.getString("telegram_chat_id", "5353300549")));
        botDeviceId = field("Telegram Device ID", p.getString("telegram_device_id", ""));

        box.addView(server);
        box.addView(topic);
        box.addView(token);
        box.addView(botToken);
        box.addView(botChatId);
        box.addView(botReportChatId);
        box.addView(botDeviceId);

        Button saveStart = new Button(this);
        saveStart.setText("Simpan & Aktifkan Receiver");
        box.addView(saveStart);

        Button accessibility = new Button(this);
        accessibility.setText("Aktifkan Auto Klik DANA");
        box.addView(accessibility);

        autoClickStatus = new TextView(this);
        box.addView(autoClickStatus);

        // V33: Sejak Android 14, izin USE_FULL_SCREEN_INTENT TIDAK LAGI otomatis
        // diberikan untuk app dengan targetSdk >= 34 (app ini targetSdk 35).
        // Tanpa izin ini di-approve manual oleh user, trampoline full-screen-intent
        // di NtfyService.fireFullScreenOpenTrampoline() akan diam-diam diturunkan
        // jadi notifikasi heads-up biasa oleh sistem -> DanaOpenActivity TIDAK
        // PERNAH tampil otomatis. Ini kemungkinan besar penyebab utama kasus
        // "notif masuk, DANA tidak kebuka sendiri" di HP Android 14/15.
        Button fullScreenIntentBtn = new Button(this);
        fullScreenIntentBtn.setText("🔓 Izinkan Notifikasi Full-Screen (wajib Android 14+)");
        box.addView(fullScreenIntentBtn);

        // V33: battery optimization & OEM autostart adalah penyebab umum lain --
        // sebelumnya cuma disebut di README/komentar kode, user harus cari sendiri
        // di Settings. Sekarang tombol ini langsung memicu dialog sistem resmi
        // REQUEST_IGNORE_BATTERY_OPTIMIZATIONS.
        Button batteryOptBtn = new Button(this);
        batteryOptBtn.setText("🔋 Matikan Optimasi Baterai (Unrestricted)");
        box.addView(batteryOptBtn);

        systemPermStatus = new TextView(this);
        systemPermStatus.setTextSize(12);
        systemPermStatus.setPadding(0, 8, 0, 8);
        box.addView(systemPermStatus);

        fullScreenIntentBtn.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT < 34) {
                status.setText("\nStatus: izin full-screen-intent otomatis aktif di Android versi ini (< 14), tidak perlu diatur manual.");
                return;
            }
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e2) {
                    status.setText("\nStatus: tidak bisa membuka pengaturan full-screen-intent otomatis. Buka manual: Setelan > Apl > DANA Native Receiver > Izin khusus.");
                }
            }
        });

        batteryOptBtn.setOnClickListener(v -> {
            try {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && Build.VERSION.SDK_INT >= 23 && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    status.setText("\nStatus: optimasi baterai untuk app ini sudah OFF (Unrestricted).");
                    refreshSystemPermStatus();
                    return;
                }
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                } catch (Exception e2) {
                    status.setText("\nStatus: tidak bisa membuka dialog optimasi baterai otomatis. Matikan manual lewat Setelan baterai.");
                }
            }
        });

        Button stop = new Button(this);
        stop.setText("Matikan Receiver");
        box.addView(stop);

        Button testDana = new Button(this);
        testDana.setText("Tes Buka Aplikasi DANA");
        box.addView(testDana);

        // Cadangan manual: kalau auto-open macet DAN notifikasi "BUKA DANA" ter-swipe/terlewat,
        // tombol ini membuka LANGSUNG link DANA Kaget terakhir yang tersimpan (pending_dana_url),
        // tanpa perlu buka notifikasi sama sekali.
        Button openPendingDana = new Button(this);
        openPendingDana.setText("🔓 Buka Link DANA Terakhir (Manual)");
        box.addView(openPendingDana);

        Button testTelegram = new Button(this);
        testTelegram.setText("TES KONEKSI TELEGRAM");
        box.addView(testTelegram);

        Button debug = new Button(this);
        debug.setText("LIHAT DEBUG LENGKAP");
        box.addView(debug);

        testTelegram.setOnClickListener(v -> {
            SharedPreferences tp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String bt = tp.getString("telegram_bot_token", "").trim();
            String bc = tp.getString("telegram_report_chat_id", tp.getString("telegram_chat_id", "")).trim();
            if (bt.isEmpty() || bc.isEmpty()) {
                status.setText("\nStatus: isi Telegram Bot Token dan Chat ID terlebih dahulu.");
                return;
            }
            TelegramBotController.sendReport(this,
                    "🧪 TEST TELEGRAM BERHASIL\n📱 Device: " +
                    TelegramBotController.get(this).deviceId() +
                    "\n💬 Chat ID: " + bc +
                    "\nJika pesan ini masuk, koneksi Bot API → Telegram sudah OK.");
            status.setText("\nStatus: pesan test Telegram dikirim. Cek chat ID yang diisi.");
        });

        debug.setOnClickListener(v -> showDebugDialog());

        status = new TextView(this);
        box.addView(status);

        saveStart.setOnClickListener(v -> {
            String s = server.getText().toString().trim();
            String t = topic.getText().toString().trim();
            String k = token.getText().toString().trim();
            String bt = botToken.getText().toString().trim();
            String bc = botChatId.getText().toString().trim();
            String br = botReportChatId.getText().toString().trim();
            String bd = botDeviceId.getText().toString().trim();

            p.edit().putString("server", s).putString("topic", t).putString("token", k)
                    .putString("telegram_bot_token", bt)
                    .putString("telegram_chat_id", bc)
                    .putString("telegram_command_chat_id", bc)
                    .putString("telegram_report_chat_id", br)
                    .putString("telegram_device_id", bd)
                    .putBoolean("telegram_bot_enabled", !bt.isEmpty() && !bc.isEmpty())
                    .putBoolean("enabled", true).apply();

            if (bt.isEmpty() || bc.isEmpty() || br.isEmpty()) {
                status.setText("\nStatus: receiver aktif, tetapi Telegram command/report belum lengkap.");
            }

            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
            }

            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            startTelegramBotService();
            status.setText("\nStatus: receiver AKTIF dan akan otomatis hidup lagi setelah HP restart.");
            refreshAccessibilityStatus();
            refreshSystemPermStatus();
        });

        accessibility.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });

        stop.setOnClickListener(v -> {
            p.edit().putBoolean("enabled", false).apply();
            Intent i = new Intent(this, NtfyService.class);
            i.setAction(NtfyService.ACTION_STOP);
            startService(i);
            status.setText("\nStatus: receiver dimatikan dan tidak akan otomatis hidup setelah restart.");
        });

        testDana.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://link.dana.id/danakaget?c=TEST"));
            i.setPackage("id.dana");
            try {
                startActivity(i);
                status.setText("\nStatus: perintah membuka aplikasi DANA dikirim.");
            } catch (Exception e) {
                status.setText("\nStatus: aplikasi DANA tidak ditemukan/Android menolak pembukaan.");
            }
        });

        openPendingDana.setOnClickListener(v -> {
            String pendingUrl = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString("pending_dana_url", "").trim();
            if (pendingUrl.isEmpty()) {
                status.setText("\nStatus: belum ada link DANA Kaget yang tertunda saat ini.");
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(pendingUrl));
            i.setPackage("id.dana");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(i);
                status.setText("\nStatus: link DANA terakhir dibuka manual (" + DebugTrace.maskUrl(pendingUrl) + ").");
            } catch (Exception e) {
                status.setText("\nStatus: gagal membuka DANA — aplikasi DANA tidak ditemukan/ditolak sistem.");
            }
        });

        boolean enabled = p.getBoolean("enabled", false);
        if (enabled && !topic.getText().toString().trim().isEmpty() && !token.getText().toString().trim().isEmpty()) {
            Intent auto = new Intent(this, NtfyService.class);
            auto.setAction(NtfyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(auto);
            else startService(auto);
            startTelegramBotService();
            status.setText("\nStatus: receiver AKTIF (otomatis).");
        } else {
            status.setText("\nStatus: receiver belum aktif.");
        }

        scrollRoot.addView(box);
        setContentView(scrollRoot);
        scrollRoot.post(() -> {
            scrollRoot.setFocusableInTouchMode(true);
            scrollRoot.requestFocus();
        });
        startTelegramBotService();
        refreshAccessibilityStatus();
        refreshSystemPermStatus();

        if (getIntent().getBooleanExtra("show_debug", false)) {
            box.postDelayed(this::showDebugDialog, 250L);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (autoClickStatus != null) refreshAccessibilityStatus();
        refreshSystemPermStatus();
    }

    private void startTelegramBotService() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("telegram_bot_enabled", false)) return;
        Intent i = new Intent(this, TelegramBotService.class);
        i.setAction(TelegramBotService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void refreshAccessibilityStatus() {
        boolean enabled = DanaAutoClickAccessibilityService.isEnabled(this);
        autoClickStatus.setText("Auto Klik: " + (enabled ? "AKTIF ✓" : "BELUM AKTIF — aktifkan di Pengaturan Aksesibilitas"));
    }

    /**
     * V33: tampilkan status 2 izin sistem yang paling sering bikin
     * "notif diterima tapi DANA tidak kebuka otomatis" kalau belum di-approve:
     * full-screen-intent (wajib di-approve manual sejak Android 14 untuk app
     * targetSdk>=34) dan battery optimization (bisa membunuh service/Accessibility
     * di background pada banyak HP OEM).
     */
    private void refreshSystemPermStatus() {
        if (systemPermStatus == null) return;

        String fullScreenLine;
        if (Build.VERSION.SDK_INT >= 34) {
            boolean granted = false;
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                granted = nm != null && nm.canUseFullScreenIntent();
            } catch (Exception ignored) {}
            fullScreenLine = "Full-screen notif: " + (granted ? "AKTIF ✓" : "❌ BELUM DIIZINKAN — auto-open DANA bisa gagal, tekan tombol di atas");
        } else {
            fullScreenLine = "Full-screen notif: otomatis aktif (Android < 14)";
        }

        String batteryLine;
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            boolean ignoring = pm != null && (Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(getPackageName()));
            batteryLine = "Optimasi baterai: " + (ignoring ? "OFF (Unrestricted) ✓" : "❌ MASIH DIBATASI — service bisa dimatikan sistem, tekan tombol di atas");
        } catch (Exception e) {
            batteryLine = "Optimasi baterai: (gagal memeriksa)";
        }

        systemPermStatus.setText(fullScreenLine + "\n" + batteryLine);
    }

    // Pola satu baris trace: "HH:mm:ss.SSS +   123ms LEVEL [001] ICON pesan..."
    private static final java.util.regex.Pattern DEBUG_LINE_PATTERN = java.util.regex.Pattern.compile(
            "^(\\S+)\\s+\\+\\s*(\\d+)ms\\s+(\\S+)\\s+\\[(\\d+)]\\s+(\\S+)\\s+(.*)$");

    private static final String DEBUG_MODE_LIST = "list";
    private static final String DEBUG_MODE_CARD = "card";

    private java.util.List<String> parseTraceLines(String trace) {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (trace == null || trace.trim().isEmpty()) return out;
        for (String line : trace.split("\\R")) {
            if (line != null && !line.trim().isEmpty()) out.add(line);
        }
        return out;
    }

    /** Dialog debug: teks mentah dihilangkan, diganti entri rapi + 2 mode tampilan yang bisa dipilih lewat ⚙ Pengaturan. */
    private void showDebugDialog() {
        final String trace = DebugTrace.fullSnapshot(this);
        final java.util.List<String> lines = parseTraceLines(trace);
        final SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        final String[] mode = { p.getString("debug_view_mode", DEBUG_MODE_LIST) };
        // Mulai dari entri PALING BARU di mode kartu, supaya langsung lihat kejadian terakhir.
        final int[] cardIndex = { Math.max(0, lines.size() - 1) };

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 16, 24, 8);

        // Header: judul + tombol Pengaturan (ganti mode tampilan)
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText("🐞 DANA • DEBUG LENGKAP");
        titleView.setTextSize(17);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(titleView, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button gearBtn = new Button(this);
        gearBtn.setText("⚙ Pengaturan");
        gearBtn.setTextSize(12);
        header.addView(gearBtn);
        root.addView(header);

        TextView subHeader = new TextView(this);
        subHeader.setTextSize(11);
        subHeader.setTextColor(0xFF888888);
        subHeader.setPadding(0, 4, 0, 12);
        root.addView(subHeader);

        // Wadah konten: isinya diganti sesuai mode (daftar / kartu), tinggi dibatasi
        // supaya dialog tetap rapi & tidak "meledak" memenuhi layar walau log panjang.
        FrameLayout container = new FrameLayout(this);
        int screenH = getResources().getDisplayMetrics().heightPixels;
        container.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int) (screenH * 0.55)));
        root.addView(container);

        final Runnable[] rerender = new Runnable[1];
        rerender[0] = () -> {
            container.removeAllViews();
            if (lines.isEmpty()) {
                TextView empty = new TextView(this);
                empty.setText("Belum ada debug trace.");
                empty.setPadding(8, 16, 8, 16);
                container.addView(empty);
                subHeader.setText("0 entri");
                return;
            }
            if (DEBUG_MODE_CARD.equals(mode[0])) {
                subHeader.setText(lines.size() + " entri • Mode: Kartu (geser kiri/kanan atau tombol)");
                container.addView(buildDebugCardView(lines, cardIndex));
            } else {
                subHeader.setText(lines.size() + " entri • Mode: Daftar (scroll atas-bawah)");
                container.addView(buildDebugListView(lines));
            }
        };
        rerender[0].run();

        gearBtn.setOnClickListener(v -> {
            String[] options = {
                    "📜 Mode Daftar (scroll atas-bawah)",
                    "🗂 Mode Kartu (geser preview / next)"
            };
            int checked = DEBUG_MODE_CARD.equals(mode[0]) ? 1 : 0;
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Pilih Tampilan Debug")
                    .setSingleChoiceItems(options, checked, (d, which) -> {
                        mode[0] = which == 1 ? DEBUG_MODE_CARD : DEBUG_MODE_LIST;
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putString("debug_view_mode", mode[0]).apply();
                        if (DEBUG_MODE_CARD.equals(mode[0])) {
                            cardIndex[0] = Math.max(0, lines.size() - 1);
                        }
                        d.dismiss();
                        rerender[0].run();
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        });

        new android.app.AlertDialog.Builder(this)
                .setView(root)
                .setPositiveButton("Tutup", null)
                .setNeutralButton("Hapus Log", (d, w) -> DebugTrace.clearPersisted(this))
                .show();
    }

    /** Mode DAFTAR: tetap bisa discroll atas-bawah, tapi tiap baris jadi kartu kecil rapi (bukan 1 blok teks). */
    private View buildDebugListView(java.util.List<String> lines) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(4, 4, 4, 4);
        for (String raw : lines) {
            list.addView(buildDebugEntryCard(raw));
        }
        scroll.addView(list);
        return scroll;
    }

    /** Satu entri log dirapikan jadi kartu kecil: baris meta (ikon/level/waktu) + pesan. */
    private View buildDebugEntryCard(String raw) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(20, 14, 20, 14);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, 0, 0, 10);
        row.setLayoutParams(rowLp);

        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xFFF5F5F5);
        bg.setCornerRadius(16f);
        bg.setStroke(1, 0xFFDDDDDD);
        row.setBackground(bg);

        TextView meta = new TextView(this);
        meta.setTextSize(11);
        meta.setTextColor(0xFF888888);
        TextView msg = new TextView(this);
        msg.setTextIsSelectable(true);
        msg.setTextSize(13);
        msg.setPadding(0, 6, 0, 0);

        java.util.regex.Matcher m = DEBUG_LINE_PATTERN.matcher(raw);
        if (m.matches()) {
            meta.setText(m.group(5) + " " + m.group(3) + "  •  #" + m.group(4) + "  •  " + m.group(1) + "  (+" + m.group(2) + "ms)");
            msg.setText(m.group(6));
        } else {
            meta.setText("LOG");
            msg.setText(raw);
        }
        row.addView(meta);
        row.addView(msg);
        return row;
    }

    /** Mode KARTU: 1 entri per layar, navigasi via swipe kiri/kanan atau tombol Preview/Next. */
    private View buildDebugCardView(java.util.List<String> lines, int[] indexHolder) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        FrameLayout cardHolder = new FrameLayout(this);
        cardHolder.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        ScrollView cardScroll = new ScrollView(this);
        cardScroll.setFillViewport(true);
        LinearLayout cardInner = new LinearLayout(this);
        cardInner.setOrientation(LinearLayout.VERTICAL);
        cardInner.setPadding(28, 24, 28, 24);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xFFF5F5F5);
        bg.setCornerRadius(20f);
        bg.setStroke(1, 0xFFDDDDDD);
        cardInner.setBackground(bg);

        TextView meta = new TextView(this);
        meta.setTextSize(12);
        meta.setTextColor(0xFF888888);
        TextView msg = new TextView(this);
        msg.setTextIsSelectable(true);
        msg.setTextSize(15);
        msg.setPadding(0, 10, 0, 0);
        cardInner.addView(meta);
        cardInner.addView(msg);
        cardScroll.addView(cardInner);
        cardHolder.addView(cardScroll);
        wrap.addView(cardHolder);

        TextView pageIndicator = new TextView(this);
        pageIndicator.setTextSize(12);
        pageIndicator.setGravity(android.view.Gravity.CENTER);
        pageIndicator.setPadding(0, 10, 0, 6);
        wrap.addView(pageIndicator);

        LinearLayout navRow = new LinearLayout(this);
        navRow.setOrientation(LinearLayout.HORIZONTAL);
        navRow.setGravity(android.view.Gravity.CENTER);
        Button prevBtn = new Button(this);
        prevBtn.setText("◀ Preview");
        Button nextBtn = new Button(this);
        nextBtn.setText("Next ▶");
        navRow.addView(prevBtn);
        navRow.addView(nextBtn);
        wrap.addView(navRow);

        final Runnable[] renderCard = new Runnable[1];
        renderCard[0] = () -> {
            int i = indexHolder[0];
            String raw = lines.get(i);
            java.util.regex.Matcher m = DEBUG_LINE_PATTERN.matcher(raw);
            if (m.matches()) {
                meta.setText(m.group(5) + " " + m.group(3) + "  •  #" + m.group(4) + "  •  " + m.group(1) + "  (+" + m.group(2) + "ms)");
                msg.setText(m.group(6));
            } else {
                meta.setText("LOG");
                msg.setText(raw);
            }
            pageIndicator.setText((i + 1) + " / " + lines.size());
            prevBtn.setEnabled(i > 0);
            nextBtn.setEnabled(i < lines.size() - 1);
            cardScroll.scrollTo(0, 0);
        };
        renderCard[0].run();

        prevBtn.setOnClickListener(v -> {
            if (indexHolder[0] > 0) { indexHolder[0]--; renderCard[0].run(); }
        });
        nextBtn.setOnClickListener(v -> {
            if (indexHolder[0] < lines.size() - 1) { indexHolder[0]++; renderCard[0].run(); }
        });

        // Geser kiri = Next, geser kanan = Preview (Preview/Next tetap tersedia sebagai tombol juga).
        final android.view.GestureDetector gesture = new android.view.GestureDetector(this,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    private static final int SWIPE_MIN_DISTANCE = 100;
                    private static final int SWIPE_MAX_OFF_PATH = 250;
                    private static final int SWIPE_THRESHOLD_VELOCITY = 150;

                    @Override
                    public boolean onFling(android.view.MotionEvent e1, android.view.MotionEvent e2, float velocityX, float velocityY) {
                        if (e1 == null || e2 == null) return false;
                        float dx = e2.getX() - e1.getX();
                        float dy = e2.getY() - e1.getY();
                        if (Math.abs(dy) > SWIPE_MAX_OFF_PATH) return false;
                        if (Math.abs(dx) > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                            if (dx < 0) {
                                if (indexHolder[0] < lines.size() - 1) { indexHolder[0]++; renderCard[0].run(); }
                            } else {
                                if (indexHolder[0] > 0) { indexHolder[0]--; renderCard[0].run(); }
                            }
                            return true;
                        }
                        return false;
                    }
                });
        cardHolder.setOnTouchListener((v, event) -> gesture.onTouchEvent(event));

        return wrap;
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }
}
