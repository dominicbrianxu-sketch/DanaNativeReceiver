package id.varino.danareceiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

public class NtfyService extends Service {
    public static final String ACTION_START = "id.varino.danareceiver.START";
    public static final String ACTION_STOP = "id.varino.danareceiver.STOP";

    private static final String TAG = "DanaReceiver";
    private static final String PREFS = "dana_receiver";
    private static final String CHANNEL = "dana_receiver";
    private static final String DANA_CHANNEL = "dana_trigger";
    private static final int NOTIF_ID = 1001;
    private static final int RESULT_ID = 1002;
    private static final int FULLSCREEN_TRAMPOLINE_ID = 1003;
    private static final long URL_DEDUP_MS = 20_000L;
    // V31: kalau UI DANA belum terkonfirmasi Accessibility dalam waktu ini
    // setelah percobaan buka terakhir, watchdog otomatis mencoba ulang.
    private static final long DANA_OPEN_RETRY_DELAY_MS = 3000L;
    private static final int DANA_OPEN_MAX_RETRIES = 2;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private static final Pattern DANA =
            Pattern.compile("^https://link\\.dana\\.id/danakaget\\?c=[^\\s]+$");

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean running = false;
    private final Set<String> handledEvents = new HashSet<>();
    private final Map<String, Long> handledUrls = new HashMap<>();

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        Log.i(TAG, "Service dibuat");
        DebugTrace.step(this, "Receiver service dibuat");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            running = false;
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("enabled", false);
        if (!enabled) {
            Log.i(TAG, "Service dipanggil tetapi receiver belum diaktifkan.");
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            Notification n = notification("Mendengarkan trigger DANA...");
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal startForeground", e);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!running) {
            running = true;
            DebugTrace.step(this, "Listen loop dimulai; receiver running=true");
            executor.execute(this::listenLoop);
        }
        return START_STICKY;
    }

    private void listenLoop() {
        long backoff = 2000;
        while (running) {
            HttpURLConnection c = null;
            try {
                SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
                if (!p.getBoolean("enabled", false)) {
                    Log.i(TAG, "Receiver dinonaktifkan; menghentikan listen loop.");
                    running = false;
                    stopForeground(true);
                    stopSelf();
                    return;
                }
                String server = p.getString("server", "https://ntfy.sh").trim().replaceAll("/+$", "");
                String topic = p.getString("topic", "").trim();

                if (topic.isEmpty()) {
                    DebugTrace.fail(this, "NTFY tidak dapat connect: topic kosong");
                    updateNotification("Topic belum diisi.");
                    Thread.sleep(5000);
                    continue;
                }

                String url = server + "/" + Uri.encode(topic) + "/json";
                DebugTrace.step(this, "Menghubungkan ke ntfy server=" + server + " topic=" + topic);
                Log.i(TAG, "Menghubungkan ke ntfy: " + server + "/" + topic + "/json");
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(90000);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("Cache-Control", "no-cache");
                c.setRequestProperty("Connection", "keep-alive");
                c.connect();

                int code = c.getResponseCode();
                DebugTrace.detail(this, "NTFY HTTP response=" + code + " contentType=" + c.getContentType());
                if (code != 200) {
                    throw new Exception("HTTP " + code);
                }

                backoff = 2000;
                updateNotification("Terhubung ke ntfy: " + topic);
                DebugTrace.success(this, "NTFY terhubung");

                InputStream in = c.getInputStream();
                BufferedReader r = new BufferedReader(
                        new InputStreamReader(in, StandardCharsets.UTF_8));

                String line;
                while (running && (line = r.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    DebugTrace.detail(this, "NTFY event line diterima; bytes=" + line.getBytes(StandardCharsets.UTF_8).length);
                    handleEvent(line);
                }
                if (running) DebugTrace.warn(this, "NTFY stream berakhir tanpa exception; reconnect akan dilakukan");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                DebugTrace.fail(this, "NTFY koneksi exception=" + e.getClass().getSimpleName() + " msg=" + e.getMessage());
                Log.e(TAG, "Koneksi ntfy gagal", e);
                if (running) {
                    updateNotification("Koneksi ntfy putus. Auto-reconnect aktif...");
                    try { Thread.sleep(backoff); } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                    backoff = Math.min(backoff * 2, 60000);
                }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private void handleEvent(String line) {
        try {
            JSONObject evt = new JSONObject(line);
            String event = evt.optString("event", "");
            DebugTrace.detail(this, "NTFY parsed event=" + event + " id=" + evt.optString("id", "(none)"));
            if (!"message".equals(event)) {
                DebugTrace.detail(this, "Event diabaikan karena bukan message");
                return;
            }

            String raw = evt.optString("message", "");
            DebugTrace.detail(this, "Payload message diterima; length=" + raw.length());
            JSONObject data;
            try {
                data = new JSONObject(raw);
            } catch (Exception e) {
                Log.w(TAG, "Pesan ntfy bukan JSON payload DANA");
                DebugTrace.fail(this, "Payload ntfy bukan JSON yang valid");
                updateNotification("Trigger ditolak: format payload tidak valid.");
                return;
            }

            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            String expected = p.getString("token", "").trim();
            String got = data.optString("token", "").trim();
            String url = data.optString("url", "").trim();
            DebugTrace.detail(this, "Payload fields: tokenPresent=" + !got.isEmpty() + " url=" + DebugTrace.maskUrl(url));

            // Token wajib cocok. Jangan menerima trigger tanpa token.
            if (expected.isEmpty()) {
                Log.e(TAG, "Token receiver kosong; trigger ditolak demi keamanan.");
                DebugTrace.fail(this, "Trigger ditolak: token receiver kosong");
                updateNotification("Trigger ditolak: token receiver kosong.");
                return;
            }
            if (!expected.equals(got)) {
                Log.w(TAG, "Trigger ditolak: token tidak cocok.");
                DebugTrace.fail(this, "Trigger ditolak: token tidak cocok");
                updateNotification("Trigger ditolak: token tidak cocok.");
                return;
            }

            if (!DANA.matcher(url).matches()) {
                Log.w(TAG, "Trigger ditolak: URL bukan DANA Kaget");
                DebugTrace.fail(this, "Trigger ditolak: URL bukan DANA Kaget");
                updateNotification("Trigger ditolak: URL bukan DANA Kaget.");
                return;
            }

            String eventId = evt.optString("id", "");
            String dedup = eventId + "|" + url;
            DebugTrace.detail(this, "Dedup check eventId=" + (eventId.isEmpty() ? "(none)" : eventId) + " urlAgeWindow=" + URL_DEDUP_MS + "ms");
            long now = System.currentTimeMillis();
            synchronized (handledEvents) {
                Long lastUrl = handledUrls.get(url);
                if ((lastUrl != null && now - lastUrl < URL_DEDUP_MS) || handledEvents.contains(dedup)) {
                    DebugTrace.warn(this, "Trigger duplikat diabaikan; eventId=" + (eventId.isEmpty() ? "(none)" : eventId));
                    Log.i(TAG, "Trigger duplikat diabaikan");
                    DebugTrace.warn(this, "Trigger duplikat diabaikan");
                    return;
                }
                handledEvents.add(dedup);
                handledUrls.put(url, now);
                if (handledEvents.size() > 500) handledEvents.clear();
                if (handledUrls.size() > 200) handledUrls.clear();
            }

            DebugTrace.start(this, "Trigger DANA diterima");
            DebugTrace.success(this, "Token cocok + URL valid: " + DebugTrace.maskUrl(url));
            Log.i(TAG, "Trigger DANA valid diterima");
            updateNotification("Trigger DANA diterima. Mencoba membuka UI DANA...");
            DebugTrace.step(this, "Menyimpan pending claim");
            openDana(url);
        } catch (Exception e) {
            Log.e(TAG, "Error memproses event ntfy", e);
            DebugTrace.fail(this, "Exception memproses event: " + e.getClass().getSimpleName());
            updateNotification("Error memproses trigger. Cek receiver.");
        }
    }

    private void openDana(String url) {
        // V7: simpan pending claim lebih dulu agar AccessibilityService sudah
        // armed ketika UI DANA muncul.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("pending_dana_url", url)
                .apply();
        boolean persisted = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString("pending_dana_url", "").trim().length() > 0;
        DebugTrace.success(this, "Pending claim tersimpan; persisted=" + persisted + " url=" + DebugTrace.maskUrl(url));

        // V31: catat waktu trigger SEBELUM percobaan apa pun, dipakai watchdog
        // untuk membandingkan apakah UI DANA sudah terkonfirmasi SETELAH trigger
        // ini (bukan konfirmasi basi dari trigger sebelumnya).
        long triggeredAt = System.currentTimeMillis();

        attemptOpenDana(url, 0);
        scheduleOpenWatchdog(url, triggeredAt, 0);
    }

    /**
     * Satu percobaan membuka DANA lewat 2 jalur sekaligus:
     *  - Jalur LANGSUNG (cepat): startActivity dari Service. Sering berhasil,
     *     tapi Android 10+ / OEM tertentu bisa mendiamkannya TANPA exception,
     *     sehingga tampak "sukses" di log padahal DANA tidak benar-benar terbuka.
     *  - Jalur TRAMPOLINE (kuat): full-screen-intent notification yang
     *     membuka DanaOpenActivity. Ini jalur resmi Android yang dikecualikan
     *     dari pembatasan Background Activity Launch, jadi jauh lebih andal.
     * Keduanya dijalankan setiap percobaan supaya peluang berhasil maksimal.
     */
    private void attemptOpenDana(String url, int attemptNumber) {
        // V27: nyalakan layar (best-effort dismiss lock non-aman) SEBELUM
        // startActivity, supaya kalau layar sedang mati, DANA tetap benar-benar
        // tampil dan proses tap Accessibility punya window aktif untuk ditapping.
        ScreenWaker.wake(this);
        DebugTrace.detail(this, "ScreenWaker dipanggil sebelum membuka DANA (percobaan #" + (attemptNumber + 1) + ")");

        try {
            Intent openDanaDirect = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            openDanaDirect.setPackage("id.dana");
            openDanaDirect.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            DebugTrace.detail(this, "Mencoba startActivity package=id.dana flags=NEW_TASK|CLEAR_TOP (jalur langsung)");
            startActivity(openDanaDirect);
            DebugTrace.success(this, "Intent pembukaan DANA (jalur langsung) dikirim");
            Log.i(TAG, "Intent pembukaan DANA (jalur langsung) dikirim, percobaan #" + (attemptNumber + 1));
        } catch (Exception e) {
            DebugTrace.detail(this, "Jalur langsung exception detail=" + e.getMessage());
            Log.e(TAG, "Jalur langsung gagal membuka DANA dari background.", e);
            DebugTrace.fail(this, "Intent DANA (jalur langsung) ditolak/exception: " + e.getClass().getSimpleName());
        }

        // Jalur kuat: selalu dijalankan juga, terlepas jalur langsung di atas
        // sukses/gagal -- karena "sukses" di jalur langsung bisa saja cuma
        // berarti Android menerima panggilannya, bukan berarti DANA benar-benar
        // tampil di layar.
        fireFullScreenOpenTrampoline(url);

        updateNotification("Perintah buka DANA dikirim (percobaan #" + (attemptNumber + 1) + "). Menunggu konfirmasi UI DANA...");

        // Notifikasi manual "BUKA DANA" cukup ditampilkan/dibunyikan sekali di
        // percobaan pertama, supaya retry otomatis di belakang layar tidak
        // bikin notifikasi/bunyi berulang-ulang mengganggu.
        if (attemptNumber == 0) {
            showDanaFallbackNotification(url, "DANA Kaget diterima. Jika DANA belum terbuka otomatis, tekan BUKA DANA.");
        }
    }

    /**
     * Jalur trampoline: kirim notifikasi full-screen-intent yang membuka
     * DanaOpenActivity (Activity transparan milik app sendiri). Begitu Activity
     * itu benar-benar tampil sebagai foreground yang sah, ia memanggil
     * startActivity ke DANA dari sana -- panggilan ini jauh lebih jarang
     * diblokir dibanding dipanggil langsung dari Service.
     */
    private void fireFullScreenOpenTrampoline(String url) {
        try {
            Intent trampoline = new Intent(this, DanaOpenActivity.class);
            trampoline.putExtra(DanaOpenActivity.EXTRA_URL, url);
            trampoline.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NO_HISTORY);

            PendingIntent fullScreenPi = PendingIntent.getActivity(
                    this,
                    Math.abs(url.hashCode()) + 1,
                    trampoline,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, DANA_CHANNEL)
                    : new Notification.Builder(this);
            Notification n = b.setContentTitle("DANA Kaget — membuka otomatis")
                    .setContentText("Membuka aplikasi DANA...")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setPriority(Notification.PRIORITY_MAX)
                    .setCategory(Notification.CATEGORY_CALL)
                    .setFullScreenIntent(fullScreenPi, true)
                    .setContentIntent(fullScreenPi)
                    .setOnlyAlertOnce(true)
                    .setAutoCancel(true)
                    .build();

            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(FULLSCREEN_TRAMPOLINE_ID, n);
            DebugTrace.detail(this, "Full-screen-intent trampoline notification dikirim");
        } catch (Exception e) {
            DebugTrace.fail(this, "Gagal mengirim full-screen-intent trampoline: " + e.getClass().getSimpleName());
            Log.e(TAG, "Gagal mengirim full-screen-intent trampoline", e);
        }
    }

    /**
     * Watchdog: beberapa detik setelah percobaan buka DANA, cek apakah
     * AccessibilityService sudah mengonfirmasi UI DANA benar-benar tampil
     * (last_dana_ui_seen_at). Kalau belum, dan claim untuk URL ini masih
     * berlaku, otomatis coba lagi -- sampai batas maksimum retry.
     */
    private void scheduleOpenWatchdog(String url, long triggeredAt, int attemptNumber) {
        if (attemptNumber >= DANA_OPEN_MAX_RETRIES) return;
        mainHandler.postDelayed(() -> {
            long lastSeen = getSharedPreferences(PREFS, MODE_PRIVATE).getLong("last_dana_ui_seen_at", 0L);
            if (lastSeen >= triggeredAt) {
                DebugTrace.detail(this, "Watchdog: UI DANA sudah terkonfirmasi, retry tidak diperlukan.");
                return;
            }
            String stillPending = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString("pending_dana_url", "");
            if (!url.equals(stillPending)) {
                DebugTrace.detail(this, "Watchdog: claim untuk URL ini sudah tidak berlaku, retry dibatalkan.");
                return;
            }

            DebugTrace.warn(this, "Watchdog: UI DANA belum terdeteksi " + DANA_OPEN_RETRY_DELAY_MS
                    + "ms setelah percobaan sebelumnya -> retry otomatis percobaan #" + (attemptNumber + 2));
            attemptOpenDana(url, attemptNumber + 1);
            scheduleOpenWatchdog(url, triggeredAt, attemptNumber + 1);
        }, DANA_OPEN_RETRY_DELAY_MS);
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setContentTitle("DANA Native Receiver")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void showResultNotification(String text, String url) {
        showDanaFallbackNotification(url, text);
    }

    private void showDanaFallbackNotification(String url, String text) {
        try {
            Intent openDana = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            openDana.setPackage("id.dana");
            openDana.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(
                    this,
                    Math.abs(url.hashCode()),
                    openDana,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, DANA_CHANNEL)
                    : new Notification.Builder(this);
            Notification n = b.setContentTitle("DANA Kaget terdeteksi")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .addAction(new Notification.Action.Builder(
                            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_view),
                            "BUKA DANA", pi).build())
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .build();
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(RESULT_ID, n);
        } catch (Exception e) {
            Log.e(TAG, "Gagal membuat fallback notification", e);
        }
    }

    private void updateNotification(String text) {
        if (!running) return;
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, notification(text));
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "DANA Receiver", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);

            NotificationChannel dana = new NotificationChannel(
                    DANA_CHANNEL, "DANA Trigger", NotificationManager.IMPORTANCE_HIGH);
            dana.setDescription("Notifikasi fallback ketika Android tidak mengizinkan pembukaan DANA dari background.");
            nm.createNotificationChannel(dana);
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        running = false;
        executor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null); // V31: batalkan watchdog retry yang masih terjadwal
        Log.i(TAG, "Service dihentikan");
        super.onDestroy();
    }
}
