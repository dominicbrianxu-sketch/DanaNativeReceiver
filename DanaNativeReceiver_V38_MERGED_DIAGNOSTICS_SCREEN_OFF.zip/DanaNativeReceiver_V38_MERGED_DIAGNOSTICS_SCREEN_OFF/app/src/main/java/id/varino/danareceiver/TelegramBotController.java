package id.varino.danareceiver;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Telegram Bot Controller — V32 INLINE KEYBOARD FULL
 *
 * Semua fitur bisa diakses lewat tombol, tanpa perlu ketik / command manual.
 *
 * Reply keyboard (persistent bawah layar):
 *   [📊 STATUS]  [🟢 ON]       [🔴 OFF]
 *   [👆 SET TAP] [⏱ SET DELAY] [🧾 DEBUG]
 *   [📱 DEVICE]  [⚙️ HELP]
 *
 * Inline keyboard (muncul saat tombol SET TAP / SET DELAY ditekan):
 *   TAP COUNT  : [3x] [4x] [5x] [7x] [10x]
 *   TAP DELAY  : [300ms] [500ms] [650ms] [800ms] [1000ms] [1500ms]
 */
public final class TelegramBotController {
    private static final String TAG = "DanaTelegramBot";
    private static final String PREFS = "dana_receiver";
    private static final String KEY_BOT_TOKEN        = "telegram_bot_token";
    private static final String KEY_CHAT_ID          = "telegram_chat_id";
    private static final String KEY_COMMAND_CHAT_ID  = "telegram_command_chat_id";
    private static final String KEY_REPORT_CHAT_ID   = "telegram_report_chat_id";
    private static final String KEY_DEVICE_ID        = "telegram_device_id";
    private static final String KEY_BOT_ENABLED      = "telegram_bot_enabled";
    private static final String KEY_UPDATE_ID        = "telegram_update_id";
    private static final int    MAX_MESSAGE          = 3800;
    private static final long   POLL_TIMEOUT_SECONDS = 25L;
    private static final long   RECONNECT_MS         = 2500L;

    // ── Teks tombol reply keyboard (yang muncul permanen di bawah) ──────────
    private static final String BTN_STATUS    = "📊 STATUS";
    private static final String BTN_ON        = "🟢 ON";
    private static final String BTN_OFF       = "🔴 OFF";
    private static final String BTN_SET_TAP   = "👆 SET TAP";
    private static final String BTN_SET_DELAY = "⏱ SET DELAY";
    private static final String BTN_DEBUG     = "🧾 DEBUG";
    private static final String BTN_DEBUG_FILE = "📥 DOWNLOAD LOG";
    private static final String BTN_DEVICE    = "📱 DEVICE";
    private static final String BTN_HELP      = "⚙️ HELP";

    private static volatile TelegramBotController instance;

    private final Context       app;
    private final ExecutorService pollExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService sendExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean running;

    private TelegramBotController(Context context) {
        this.app = context.getApplicationContext();
    }

    public static TelegramBotController get(Context context) {
        if (instance == null) {
            synchronized (TelegramBotController.class) {
                if (instance == null) instance = new TelegramBotController(context);
            }
        }
        return instance;
    }

    public static void start(Context context)  { get(context).startInternal(); }
    public static void stop(Context context)   { get(context).stopInternal(); }

    public static void sendReport(Context context, String text) {
        get(context).sendMessageAsync(text);
    }

    public static void sendClaimReport(Context context, boolean success, String url, String uiText) {
        String device = get(context).deviceId();
        String state  = success ? "BERHASIL" : "GAGAL";
        String safeUrl = DebugTrace.maskUrl(url);
        String safeUi  = uiText == null ? "" : uiText.replace('\n', ' ').replace('\r', ' ');
        if (safeUi.length() > 900) safeUi = safeUi.substring(0, 900) + "...";
        sendReport(context,
                "📲 DANA CLAIM " + state + "\n" +
                "📱 Device: " + device + "\n" +
                "🔗 URL: " + safeUrl + "\n" +
                "📝 UI: " + safeUi);
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    private void startInternal() {
        if (running) return;
        SharedPreferences p = prefs();
        if (!p.getBoolean(KEY_BOT_ENABLED, false)) return;
        if (token().isEmpty() || commandChatId().isEmpty()) return;
        running = true;
        DebugTrace.step(app, "🤖 Telegram Bot Controller mulai");
        DebugTrace.detail(app, "Telegram polling siap; commandChat=" + commandChatId()
                + " reportChat=" + reportChatId() + " device=" + deviceId());
        pollExecutor.execute(this::pollLoop);
    }

    private void stopInternal() {
        running = false;
        DebugTrace.step(app, "🤖 Telegram Bot Controller dihentikan");
    }

    // ── Poll loop ────────────────────────────────────────────────────────────

    private void pollLoop() {
        try { verifyTelegramConnection(); deleteWebhook(); }
        catch (Exception e) { DebugTrace.fail(app, "Telegram startup check gagal: " + e.getMessage()); }

        // Kirim pesan selamat datang + tampilkan keyboard utama
        sendMenuAsync(primaryChatId(),
                "🟢 APK Bot Controller aktif\n" +
                "📱 Device : " + deviceId() + "\n" +
                "⌨️ Command: " + commandChatId() + "\n" +
                "📢 Report : " + reportChatId() + "\n\n" +
                "Pilih aksi dari tombol di bawah 👇");

        while (running) {
            try {
                String response = getUpdates();
                if (response == null || response.isEmpty()) { Thread.sleep(RECONNECT_MS); continue; }
                JSONObject root = new JSONObject(response);
                if (!root.optBoolean("ok", false)) {
                    String desc = compact(root.optString("description", "unknown"));
                    DebugTrace.fail(app, "Telegram API error: " + desc);
                    if (desc.toLowerCase(Locale.US).contains("conflict"))
                        DebugTrace.fail(app, "Telegram 409: token dipakai polling/webhook lain");
                    Thread.sleep(RECONNECT_MS);
                    continue;
                }
                JSONArray result = root.optJSONArray("result");
                if (result == null) continue;
                for (int i = 0; i < result.length(); i++) {
                    JSONObject update = result.optJSONObject(i);
                    if (update == null) continue;
                    long id = update.optLong("update_id", -1L);
                    if (id >= 0) saveUpdateId(id + 1L);
                    DebugTrace.step(app, "🤖 Telegram update diterima update_id=" + id);
                    handleUpdate(update);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); break;
            } catch (Exception e) {
                Log.e(TAG, "Bot polling error", e);
                try { Thread.sleep(RECONNECT_MS); } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt(); break;
                }
            }
        }
    }

    // ── getUpdates — tambahkan callback_query ────────────────────────────────

    private String getUpdates() throws Exception {
        long offset = prefs().getLong(KEY_UPDATE_ID, 0L);
        String base  = "https://api.telegram.org/bot" + token() + "/getUpdates";
        // V32: listen juga ke callback_query supaya inline-keyboard bekerja
        String query = "timeout=" + POLL_TIMEOUT_SECONDS + "&allowed_updates=" +
                URLEncoder.encode("[\"message\",\"callback_query\"]", "UTF-8");
        if (offset > 0L) query += "&offset=" + offset;

        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(base + "?" + query).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(15000);
            c.setReadTimeout((int) ((POLL_TIMEOUT_SECONDS + 10L) * 1000L));
            String response = read(c);
            int code = c.getResponseCode();
            if (code != 200) DebugTrace.fail(app, "Telegram getUpdates HTTP=" + code);
            else DebugTrace.detail(app, "Telegram getUpdates HTTP=200 bytes=" + response.length());
            return response;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    // ── handleUpdate — pesan biasa + callback_query ──────────────────────────

    private void handleUpdate(JSONObject update) {
        try {
            // Inline keyboard tap → callback_query
            JSONObject cb = update.optJSONObject("callback_query");
            if (cb != null) { handleCallbackQuery(cb); return; }

            // Pesan teks biasa (termasuk tombol reply keyboard)
            JSONObject message = update.optJSONObject("message");
            if (message == null) return;
            JSONObject chat = message.optJSONObject("chat");
            if (chat == null) return;
            String incomingChat = String.valueOf(chat.optLong("id", 0L));
            if (!isAllowedChat(incomingChat)) {
                DebugTrace.warn(app, "Telegram chat diabaikan: " + incomingChat);
                return;
            }
            String text = message.optString("text", "").trim();
            if (text.isEmpty()) return;
            DebugTrace.step(app, "🤖 Telegram command: " + text);
            processCommand(text, incomingChat);
        } catch (Exception e) {
            Log.e(TAG, "handleUpdate error", e);
        }
    }

    // ── Callback query dari inline keyboard ──────────────────────────────────

    private void handleCallbackQuery(JSONObject cb) {
        try {
            String cbId   = cb.optString("id", "");
            String data   = cb.optString("data", "");
            JSONObject msg  = cb.optJSONObject("message");
            JSONObject chat = msg != null ? msg.optJSONObject("chat") : null;
            String chatId   = chat != null ? String.valueOf(chat.optLong("id", 0L)) : "";

            if (!isAllowedChat(chatId)) {
                answerCallbackQuery(cbId, "❌ Tidak diizinkan");
                return;
            }

            DebugTrace.step(app, "🤖 Callback query data=" + data);

            if (data.startsWith("tap:")) {
                // ── Atur jumlah tap ─────────────────────────────────────────
                int count = Integer.parseInt(data.substring(4));
                prefs().edit().putInt("remote_tap_count", count).apply();
                answerCallbackQuery(cbId, "✅ Tap diset " + count + "x");
                reply(chatId,
                        "✅ *Jumlah tap diubah ke " + count + "x*\n\n" + statusText());

            } else if (data.startsWith("delay:")) {
                // ── Atur jeda antar tap ──────────────────────────────────────
                long ms = Long.parseLong(data.substring(6));
                prefs().edit().putLong("remote_tap_delay_ms", ms).apply();
                answerCallbackQuery(cbId, "✅ Delay diset " + ms + "ms");
                reply(chatId,
                        "✅ *Jeda tap diubah ke " + ms + " ms*\n\n" + statusText());

            } else if (data.equals("cancel")) {
                answerCallbackQuery(cbId, "Dibatalkan");

            } else {
                answerCallbackQuery(cbId, "?");
            }
        } catch (Exception e) {
            Log.e(TAG, "handleCallbackQuery error", e);
        }
    }

    // ── processCommand — reply keyboard + command teks ───────────────────────

    private void processCommand(String text, String chat) {
        String[] a = text.trim().split("\\s+");
        if (a.length == 0) return;
        String command = a[0].toLowerCase(Locale.US);
        if (command.contains("@")) command = command.substring(0, command.indexOf('@'));

        // Mapping tombol reply keyboard → command internal
        if      (text.equalsIgnoreCase(BTN_STATUS))    command = "/status";
        else if (text.equalsIgnoreCase(BTN_ON))        command = "/on";
        else if (text.equalsIgnoreCase(BTN_OFF))       command = "/off";
        else if (text.equalsIgnoreCase(BTN_DEBUG))     command = "/debug";
        else if (text.equalsIgnoreCase(BTN_DEBUG_FILE)) command = "/debugdownload";
        else if (text.equalsIgnoreCase(BTN_HELP))      command = "/help";
        else if (text.equalsIgnoreCase(BTN_DEVICE))    command = "/device";
        else if (text.equalsIgnoreCase(BTN_SET_TAP))   command = "/menutap";
        else if (text.equalsIgnoreCase(BTN_SET_DELAY)) command = "/menudelay";
        // Legacy emoji shortcut (jaga kompatibilitas)
        else if ("📊".equals(command))                 command = "/status";

        if (!targetMatches(a)) return;

        switch (command) {
            case "/start":
            case "/help":
                sendMenuAsync(chat,
                        "🤖 *DANA Native Receiver*\n\n" +
                        "Pilih aksi dari tombol di bawah 👇\n\n" +
                        "👆 *SET TAP*   — atur jumlah tap (klik amplop DANA)\n" +
                        "⏱ *SET DELAY* — atur jeda antar tap\n" +
                        "📊 *STATUS*    — lihat status lengkap\n" +
                        "🟢 *ON* / 🔴 *OFF* — hidupkan/matikan receiver\n" +
                        "🧾 *DEBUG*     — lihat log debug\n" +
                        "📥 *DOWNLOAD LOG* — download file log debug\n" +
                        "📱 *DEVICE*    — lihat Device ID\n\n" +
                        "Command teks juga masih bisa:\n" +
                        "/settap 5 • /setdelay 650 • /on • /off • /status • /debug");
                break;

            case "/device":
                reply(chat, "📱 Device ID: " + deviceId() + "\n" + statusText());
                break;

            case "/status":
                reply(chat, statusText());
                break;

            case "/on":
                setReceiver(true);
                reply(chat, "🟢 Receiver ON\n" + statusText());
                break;

            case "/off":
                setReceiver(false);
                reply(chat, "🔴 Receiver OFF\n" + statusText());
                break;

            // ── Inline keyboard: pilih jumlah tap ───────────────────────────
            case "/menutap":
            case "/settap":
                if (command.equals("/settap") && a.length >= 2) {
                    // Format lama: /settap 5 [device_id] → langsung set
                    try {
                        int count = Integer.parseInt(a[1]);
                        if (count < 1 || count > 10) throw new NumberFormatException();
                        prefs().edit().putInt("remote_tap_count", count).apply();
                        reply(chat, "✅ Tap count = " + count + "\n" + statusText());
                    } catch (Exception e) {
                        reply(chat, "❌ Tap count harus 1–10.\nContoh: /settap 5");
                    }
                } else {
                    // Tampilkan inline keyboard pilih jumlah tap
                    int current = prefs().getInt("remote_tap_count", 10);
                    sendInlineKeyboard(chat,
                            "👆 *Pilih jumlah tap klik amplop DANA*\n" +
                            "Saat ini: *" + current + "x*",
                            buildTapKeyboard());
                }
                break;

            // ── Inline keyboard: pilih jeda tap ─────────────────────────────
            case "/menudelay":
            case "/setdelay":
                if (command.equals("/setdelay") && a.length >= 2) {
                    // Format lama: /setdelay 650 [device_id] → langsung set
                    try {
                        long ms = Long.parseLong(a[1]);
                        if (ms < 50L || ms > 10000L) throw new NumberFormatException();
                        prefs().edit().putLong("remote_tap_delay_ms", ms).apply();
                        reply(chat, "✅ Tap delay = " + ms + " ms\n" + statusText());
                    } catch (Exception e) {
                        reply(chat, "❌ Delay harus 50–10000 ms.\nContoh: /setdelay 650");
                    }
                } else {
                    long current = prefs().getLong("remote_tap_delay_ms", 650L);
                    sendInlineKeyboard(chat,
                            "⏱ *Pilih jeda antar tap*\n" +
                            "Saat ini: *" + current + " ms*\n" +
                            "_Semakin kecil = semakin cepat_",
                            buildDelayKeyboard());
                }
                break;

            case "/debug":
                String debug = DebugTrace.fullSnapshot(app);
                if (debug.isEmpty()) debug = "Belum ada debug trace.";
                sendLong(chat, "🧾 DEBUG " + deviceId() + "\n" + debug);
                break;

            case "/debugdownload":
                // /debugdownload [DEVICE-ID]
                // Tanpa target = perangkat ini. Dengan target = hanya perangkat
                // yang ID-nya cocok yang boleh mengirim file.
                if (a.length >= 2 && !deviceId().equalsIgnoreCase(a[1])) {
                    reply(chat, "⏭️ Perintah DOWNLOAD LOG ditujukan ke " + a[1] + ".\n" +
                            "📱 Perangkat ini: " + deviceId());
                    break;
                }
                sendDebugLogFile(chat);
                break;

            default:
                reply(chat, "❓ Command tidak dikenal.\nKetuk ⚙️ HELP untuk daftar fitur.");
        }
    }

    // ── Builder inline keyboard ──────────────────────────────────────────────

    /** Inline keyboard pilihan jumlah tap: 3 / 4 / 5 / 7 / 10 */
    private JSONArray buildTapKeyboard() {
        try {
            return new JSONArray()
                    .put(new JSONArray()
                            .put(inlineBtn("3x",  "tap:3"))
                            .put(inlineBtn("4x",  "tap:4"))
                            .put(inlineBtn("5x",  "tap:5")))
                    .put(new JSONArray()
                            .put(inlineBtn("7x",  "tap:7"))
                            .put(inlineBtn("10x", "tap:10")))
                    .put(new JSONArray()
                            .put(inlineBtn("❌ Batal", "cancel")));
        } catch (Exception e) { return new JSONArray(); }
    }

    /** Inline keyboard pilihan jeda tap dalam ms */
    private JSONArray buildDelayKeyboard() {
        try {
            return new JSONArray()
                    .put(new JSONArray()
                            .put(inlineBtn("300 ms",  "delay:300"))
                            .put(inlineBtn("500 ms",  "delay:500"))
                            .put(inlineBtn("650 ms",  "delay:650")))
                    .put(new JSONArray()
                            .put(inlineBtn("800 ms",  "delay:800"))
                            .put(inlineBtn("1000 ms", "delay:1000"))
                            .put(inlineBtn("1500 ms", "delay:1500")))
                    .put(new JSONArray()
                            .put(inlineBtn("❌ Batal", "cancel")));
        } catch (Exception e) { return new JSONArray(); }
    }

    private JSONObject inlineBtn(String label, String data) throws Exception {
        return new JSONObject().put("text", label).put("callback_data", data);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private boolean targetMatches(String[] a) {
        if (a.length < 2) return true;
        String last = a[a.length - 1];
        if (last.startsWith("DANA-") || last.startsWith("device-"))
            return deviceId().equalsIgnoreCase(last);
        return true;
    }

    private void setReceiver(boolean on) {
        prefs().edit().putBoolean("enabled", on).apply();
        IntentHelper.startOrStop(app, on);
    }

    private String statusText() {
        SharedPreferences p = prefs();
        boolean enabled     = p.getBoolean("enabled", false);
        boolean bot         = p.getBoolean(KEY_BOT_ENABLED, false);
        boolean accessibility = DanaAutoClickAccessibilityService.isEnabled(app);
        int  taps  = p.getInt("remote_tap_count", 10);
        long delay = p.getLong("remote_tap_delay_ms", 650L);
        return "📱 Device      : " + deviceId()                  + "\n" +
               "🤖 Bot         : " + (bot          ? "AKTIF" : "OFF") + "\n" +
               "📡 Receiver    : " + (enabled       ? "ON ✅" : "OFF ❌") + "\n" +
               "♿ Auto Klik   : " + (accessibility ? "AKTIF ✅" : "OFF ❌") + "\n" +
               "👆 Jumlah Tap  : " + taps + "x\n" +
               "⏱ Jeda Tap    : " + delay + " ms";
    }

    // ── Send helpers ─────────────────────────────────────────────────────────

    private void sendMessageAsync(String text) {
        if (text == null || text.trim().isEmpty()) return;
        String chat = primaryChatId();
        if (token().isEmpty() || chat.isEmpty()) return;
        sendExecutor.execute(() -> sendLong(chat, text));
    }

    /**
     * Kirim pesan + reply keyboard utama (tombol permanen di bawah).
     * Di-cache ke sendExecutor agar tidak bentrok dengan pesan lain.
     */
    private void sendMenuAsync(String chat, String text) {
        if (chat == null || chat.isEmpty()) return;
        sendExecutor.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL("https://api.telegram.org/bot" + token() + "/sendMessage");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                // Reply keyboard — 3 baris tombol
                JSONObject keyboard = new JSONObject()
                        .put("keyboard", new JSONArray()
                                .put(new JSONArray()
                                        .put(BTN_STATUS)
                                        .put(BTN_ON)
                                        .put(BTN_OFF))
                                .put(new JSONArray()
                                        .put(BTN_SET_TAP)
                                        .put(BTN_SET_DELAY)
                                        .put(BTN_DEBUG))
                                .put(new JSONArray().put(BTN_DEBUG_FILE))
                                .put(new JSONArray()
                                        .put(BTN_DEVICE)
                                        .put(BTN_HELP)))
                        .put("resize_keyboard", true)
                        .put("is_persistent", true);

                JSONObject body = new JSONObject()
                        .put("chat_id", chat)
                        .put("text", text)
                        .put("parse_mode", "Markdown")
                        .put("reply_markup", keyboard);

                writeAndSend(c, body);
                DebugTrace.success(app, "🤖 Telegram sendMenu OK");
            } catch (Exception e) {
                DebugTrace.fail(app, "Telegram sendMenu exception=" + e.getClass().getSimpleName());
                Log.e(TAG, "sendMenu failed", e);
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    /**
     * Kirim pesan dengan inline keyboard (tombol yang muncul di dalam chat,
     * bisa ditekan untuk memicu callback_query).
     */
    private void sendInlineKeyboard(String chat, String text, JSONArray inlineRows) {
        if (chat == null || chat.isEmpty()) return;
        sendExecutor.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL("https://api.telegram.org/bot" + token() + "/sendMessage");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                JSONObject inlineKeyboard = new JSONObject()
                        .put("inline_keyboard", inlineRows);

                JSONObject body = new JSONObject()
                        .put("chat_id", chat)
                        .put("text", text)
                        .put("parse_mode", "Markdown")
                        .put("reply_markup", inlineKeyboard);

                writeAndSend(c, body);
                DebugTrace.success(app, "🤖 Telegram sendInlineKeyboard OK");
            } catch (Exception e) {
                DebugTrace.fail(app, "Telegram sendInlineKeyboard exception=" + e.getClass().getSimpleName());
                Log.e(TAG, "sendInlineKeyboard failed", e);
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    /** Answer callback query — wajib dipanggil agar spinner inline keyboard hilang */
    private void answerCallbackQuery(String callbackQueryId, String notifText) {
        sendExecutor.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL("https://api.telegram.org/bot" + token() + "/answerCallbackQuery");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                JSONObject body = new JSONObject()
                        .put("callback_query_id", callbackQueryId)
                        .put("text", notifText)
                        .put("show_alert", false);
                writeAndSend(c, body);
            } catch (Exception e) {
                DebugTrace.fail(app, "answerCallbackQuery exception=" + e.getClass().getSimpleName());
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private void reply(String chat, String text) {
        if (chat == null || chat.isEmpty()) return;
        sendExecutor.execute(() -> sendLong(chat, text));
    }

    private void sendLong(String chat, String text) {
        if (text == null) return;
        int pos = 0;
        while (pos < text.length()) {
            int end = Math.min(pos + MAX_MESSAGE, text.length());
            if (end < text.length()) {
                int nl = text.lastIndexOf('\n', end);
                if (nl > pos + 100) end = nl;
            }
            sendMessage(chat, text.substring(pos, end));
            pos = end;
        }
    }

    /**
     * Mengirim file debug lengkap sebagai document Telegram.
     * Tidak memakai sendMessage sehingga log panjang tidak terpotong.
     */
    private void sendDebugLogFile(String chat) {
        if (chat == null || chat.trim().isEmpty() || token().isEmpty()) return;
        sendExecutor.execute(() -> {
            HttpURLConnection c = null;
            FileInputStream in = null;
            try {
                java.io.File logFile = new java.io.File(app.getFilesDir(), "dana_debug_trace.log");
                if (!logFile.exists() || logFile.length() == 0L) {
                    reply(chat, "⚠️ Tidak ada debug log pada " + deviceId() + ".");
                    return;
                }

                URL u = new URL("https://api.telegram.org/bot" + token() + "/sendDocument");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setDoOutput(true);
                String boundary = "----DanaDebug" + System.currentTimeMillis();
                c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

                try (OutputStream out = c.getOutputStream()) {
                    writeMultipartField(out, boundary, "chat_id", chat);
                    writeMultipartField(out, boundary, "caption",
                            "🐞 DANA DEBUG LOG\n📱 Device: " + deviceId() +
                            "\n📦 Size: " + logFile.length() + " bytes");

                    out.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
                    out.write(("Content-Disposition: form-data; name=\"document\"; filename=\"dana_debug_trace_"
                            + safeFilePart(deviceId()) + ".log\"\r\n").getBytes(StandardCharsets.UTF_8));
                    out.write("Content-Type: text/plain; charset=utf-8\r\n\r\n".getBytes(StandardCharsets.UTF_8));

                    in = new FileInputStream(logFile);
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    out.write("\r\n".getBytes(StandardCharsets.UTF_8));
                    out.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
                }

                String response = read(c);
                int code = c.getResponseCode();
                if (code == 200) {
                    DebugTrace.success(app, "📥 Telegram DOWNLOAD LOG terkirim; bytes=" + logFile.length());
                } else {
                    DebugTrace.fail(app, "Telegram sendDocument HTTP=" + code + " " + compact(response));
                    reply(chat, "❌ Gagal mengirim log. HTTP=" + code);
                }
            } catch (Exception e) {
                DebugTrace.fail(app, "sendDocument exception=" + e.getClass().getSimpleName() + " msg=" + e.getMessage());
                Log.e(TAG, "sendDebugLogFile failed", e);
                reply(chat, "❌ Gagal mengirim file debug: " + e.getClass().getSimpleName());
            } finally {
                try { if (in != null) in.close(); } catch (Exception ignored) {}
                if (c != null) c.disconnect();
            }
        });
    }

    private static void writeMultipartField(OutputStream out, String boundary, String name, String value) throws Exception {
        out.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
        out.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    private static String safeFilePart(String value) {
        if (value == null || value.isEmpty()) return "device";
        return value.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private void sendMessage(String chat, String text) {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://api.telegram.org/bot" + token() + "/sendMessage");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            JSONObject body = new JSONObject()
                    .put("chat_id", chat)
                    .put("text", text)
                    .put("parse_mode", "Markdown");
            writeAndSend(c, body);
        } catch (Exception e) {
            DebugTrace.fail(app, "sendMessage exception=" + e.getClass().getSimpleName());
            Log.e(TAG, "sendMessage failed", e);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void writeAndSend(HttpURLConnection c, JSONObject body) throws Exception {
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
        String response = read(c);
        int code = c.getResponseCode();
        if (code == 200) DebugTrace.success(app, "🤖 Telegram API OK");
        else DebugTrace.fail(app, "Telegram API HTTP=" + code + " " + compact(response));
    }

    // ── Utility ──────────────────────────────────────────────────────────────

    private static String compact(String value) {
        if (value == null) return "";
        String s = value.replace('\n', ' ').replace('\r', ' ');
        return s.length() > 240 ? s.substring(0, 237) + "..." : s;
    }

    private String read(HttpURLConnection c) throws Exception {
        InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private void saveUpdateId(long nextOffset) {
        if (nextOffset < 0L) return;
        SharedPreferences p = prefs();
        long current = p.getLong(KEY_UPDATE_ID, 0L);
        if (nextOffset > current) p.edit().putLong(KEY_UPDATE_ID, nextOffset).apply();
    }

    private SharedPreferences prefs() { return app.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    private String token()       { return prefs().getString(KEY_BOT_TOKEN, "").trim(); }
    private String chatId()      { return prefs().getString(KEY_CHAT_ID, "").trim(); }
    private String commandChatId() {
        String v = prefs().getString(KEY_COMMAND_CHAT_ID, "").trim();
        return v.isEmpty() ? chatId() : v;
    }
    private String reportChatId() {
        String v = prefs().getString(KEY_REPORT_CHAT_ID, "").trim();
        return v.isEmpty() ? chatId() : v;
    }
    private String primaryChatId() {
        String raw = reportChatId();
        if (raw.isEmpty()) return "";
        for (String id : raw.split("[,\\s]+", -1))
            if (!id.trim().isEmpty()) return id.trim();
        return "";
    }
    private boolean isAllowedChat(String incoming) {
        if (incoming == null || incoming.trim().isEmpty()) return false;
        String raw = commandChatId();
        if (raw.isEmpty()) return false;
        for (String id : raw.split("[,\\s]+", -1))
            if (incoming.equals(id.trim())) return true;
        return false;
    }

    private void verifyTelegramConnection() throws Exception {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://api.telegram.org/bot" + token() + "/getMe");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            String response = read(c);
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("getMe HTTP=" + code + " " + compact(response));
            JSONObject root = new JSONObject(response);
            if (!root.optBoolean("ok", false))
                throw new Exception("getMe: " + compact(root.optString("description", "unknown")));
            JSONObject result = root.optJSONObject("result");
            String username = result == null ? "?" : result.optString("username", "?");
            long   id       = result == null ? 0L  : result.optLong("id", 0L);
            DebugTrace.success(app, "🤖 Telegram getMe OK bot=@" + username + " id=" + id);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void deleteWebhook() {
        HttpURLConnection c = null;
        try {
            URL u = new URL("https://api.telegram.org/bot" + token() + "/deleteWebhook?drop_pending_updates=false");
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            int code = c.getResponseCode();
            if (code == 200) DebugTrace.success(app, "🤖 Telegram webhook cleared; polling siap");
            else DebugTrace.fail(app, "Telegram deleteWebhook HTTP=" + code);
        } catch (Exception e) {
            DebugTrace.fail(app, "deleteWebhook exception=" + e.getClass().getSimpleName());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    public String deviceId() {
        String stored = prefs().getString(KEY_DEVICE_ID, "").trim();
        if (!stored.isEmpty()) return stored;
        String androidId = Settings.Secure.getString(app.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null || androidId.trim().isEmpty()) androidId = "unknown";
        String id = "DANA-" + androidId.toUpperCase(Locale.US);
        prefs().edit().putString(KEY_DEVICE_ID, id).apply();
        return id;
    }

    // ── IntentHelper ─────────────────────────────────────────────────────────

    public static final class IntentHelper {
        private IntentHelper() {}
        static void startOrStop(Context context, boolean on) {
            android.content.Intent i = new android.content.Intent(context, NtfyService.class);
            i.setAction(on ? NtfyService.ACTION_START : NtfyService.ACTION_STOP);
            if (on && Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
            else context.startService(i);
        }
    }
}
