package id.varino.danareceiver;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/**
 * Activity transparan "trampoline" untuk membuka DANA.
 *
 * Kenapa activity ini perlu ada:
 * Android 10+ membatasi Activity yang dibuka langsung dari sebuah Service yang
 * berjalan di background ("Background Activity Launch restriction"). Yang
 * bikin ini licin dideteksi: startActivity() dari Service TIDAK SELALU
 * melempar exception ketika dibatasi -- di banyak perangkat/OEM, sistem diam
 * saja dan tidak menampilkan apa-apa, padahal kode tetap mencatat "berhasil
 * dikirim". Itulah salah satu penyebab utama kasus "notif diterima tapi DANA
 * tidak otomatis kebuka".
 *
 * Full-screen-intent notification adalah salah satu jalur resmi yang
 * DIKECUALIKAN dari pembatasan tsb -- dipakai juga oleh aplikasi telepon
 * masuk/alarm. NtfyService memicu Activity ini lewat full-screen-intent, dan
 * begitu Activity ini benar-benar tampil (artinya context-nya sudah jadi
 * foreground yang sah), barulah ia memanggil startActivity ke DANA dari sini
 * -- panggilan ini jauh lebih jarang diblokir dibanding dipanggil langsung
 * dari Service.
 */
public class DanaOpenActivity extends Activity {
    public static final String EXTRA_URL = "dana_url";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String url = getIntent() != null ? getIntent().getStringExtra(EXTRA_URL) : null;
        DebugTrace.detail(this, "DanaOpenActivity tampil (trampoline foreground); url=" + DebugTrace.maskUrl(url));

        ScreenWaker.wake(this);

        if (url != null && !url.trim().isEmpty()) {
            try {
                Intent openDana = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                openDana.setPackage("id.dana");
                openDana.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(openDana);
                DebugTrace.success(this, "DanaOpenActivity berhasil memanggil startActivity DANA dari context foreground");
            } catch (Exception e) {
                DebugTrace.fail(this, "DanaOpenActivity gagal membuka DANA: " + e.getClass().getSimpleName());
            }
        } else {
            DebugTrace.warn(this, "DanaOpenActivity dipanggil tanpa URL yang valid");
        }

        // Trampoline: tidak perlu tetap hidup / tampil di recents.
        finish();
    }
}
