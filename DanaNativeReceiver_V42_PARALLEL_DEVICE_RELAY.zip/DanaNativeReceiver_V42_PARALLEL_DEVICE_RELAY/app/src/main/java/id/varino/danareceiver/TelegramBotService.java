package id.varino.danareceiver;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Keeps the Telegram Bot API controller alive independently from the DANA receiver. */
public class TelegramBotService extends Service {
    public static final String ACTION_START = "id.varino.danareceiver.TELEGRAM_START";
    public static final String ACTION_STOP = "id.varino.danareceiver.TELEGRAM_STOP";
    private static final String PREFS = "dana_receiver";
    private static final String CHANNEL = "dana_telegram_bot";
    private static final int NOTIF_ID = 1010;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            TelegramBotController.stop(this);
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean enabled = p.getBoolean("telegram_bot_enabled", false);
        boolean gateway = p.getBoolean("telegram_gateway", true);
        String token = p.getString("telegram_bot_token", "").trim();
        String chat = p.getString("telegram_chat_id", "").trim();
        if (!enabled || !gateway || token.isEmpty() || chat.isEmpty()) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = notification();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }

        TelegramBotController.start(this);
        return START_STICKY;
    }

    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return b.setContentTitle("DANA Telegram Controller")
                .setContentText("Bot API aktif")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.createNotificationChannel(new NotificationChannel(
                        CHANNEL, "DANA Telegram Controller", NotificationManager.IMPORTANCE_LOW));
            }
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
