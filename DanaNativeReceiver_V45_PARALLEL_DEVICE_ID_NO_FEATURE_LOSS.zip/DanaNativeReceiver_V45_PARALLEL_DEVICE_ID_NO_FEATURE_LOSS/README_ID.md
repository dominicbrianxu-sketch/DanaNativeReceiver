# DanaNativeReceiver V25

V25 menggunakan 10 titik kandidat tap di area amplop DANA Kaget. Setiap percobaan menggunakan titik berbeda. Jika hasil klaim berhasil dikonfirmasi oleh UI DANA, koordinat normalisasi tepat yang berhasil disimpan secara persisten di SharedPreferences dan diprioritaskan pada klaim berikutnya. Jika titik tersimpan gagal, sistem tetap melakukan scan kandidat lain. Gesture COMPLETED tidak dianggap sebagai bukti sukses.

VersionCode: 25
VersionName: 1.24-10point-learning-envelope-tap

V45: Device ID manual. Set HP 1 = "hp 1" and HP 2 = "hp 2". Only HP 1 is Telegram polling gateway; HP 2 is ntfy worker/relay. Device-specific debug logs remain separate and can be downloaded as TXT from Telegram.
