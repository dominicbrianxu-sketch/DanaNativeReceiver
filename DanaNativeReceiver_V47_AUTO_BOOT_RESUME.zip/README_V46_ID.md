# DanaNativeReceiver V46

V46 is a targeted startup-safety patch based on the supplied V45 source.

## Tujuan perbaikan

- HP 1 (`hp 1`) tetap menjadi satu-satunya Telegram Gateway/polling device.
- HP 2 (`hp 2`) tidak lagi mencoba menyalakan TelegramBotService dari MainActivity atau BootReceiver.
- NtfyService pada HP 2 tetap dapat berjalan sebagai Worker/receiver.
- Fitur DANA, accessibility auto-click, ntfy listener, dan laporan yang ada pada V45 tidak sengaja diubah.

## Build

`codemagic.yaml` sudah dinaikkan ke V46. Letakkan file YAML di root repository GitHub dan jalankan workflow `dana-native-receiver-v46-parallel-device-relay` pada Codemagic.

## Catatan penting

Pemeriksaan YAML dan guard sumber telah lulus. Kompilasi Android dan pengujian langsung di HP belum dilakukan di lingkungan ini. Jangan anggap APK lulus sebelum Codemagic menghasilkan APK dan APK diuji pada HP 1 serta HP 2.

Remote config dan kontrol build melalui Telegram belum ditanam pada patch ini. Keduanya memerlukan server/API dan kredensial yang disimpan aman di server, bukan ditulis ke source APK.
