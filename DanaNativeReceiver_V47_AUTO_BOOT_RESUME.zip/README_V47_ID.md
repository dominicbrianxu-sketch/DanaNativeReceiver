# Dana Native Receiver V47

V47 menambahkan pemulihan otomatis receiver setelah reboot/update dengan tetap mempertahankan pilihan pengguna.

## Setup sekali
1. Install APK dan pilih Device ID yang benar (HP 1 Gateway / HP 2 Worker).
2. Aktifkan DANA Auto Click di Pengaturan Aksesibilitas Android. Izin ini tidak bisa diberikan otomatis oleh APK.
3. Izinkan notifikasi dan Full-screen Intent jika Android memintanya.
4. Set baterai ke Unrestricted dan izinkan Auto Start pada perangkat yang menyediakan opsi tersebut.
5. Tekan Simpan & Aktifkan Receiver satu kali.

Setelah itu, BOOT_COMPLETED akan memulihkan receiver sesuai konfigurasi tersimpan. Tombol Matikan Receiver menonaktifkan pemulihan otomatis. HP 2 tetap Worker dan tidak menjalankan Telegram polling.
