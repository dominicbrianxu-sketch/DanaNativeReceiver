package id.varino.danareceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

/**
 * Stable-lock policy: this receiver NEVER downloads or installs APK updates.
 * MY_PACKAGE_REPLACED is delivered by Android only after an install/update has
 * already been completed by the user or device-management policy. This action
 * merely resumes previously opted-in services; it does not initiate an update.
 */
public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "DanaReceiverBoot";
    private static final String PREFS = "dana_receiver";

    @Override public void onReceive(Context context, Intent intent) {
        final String action = intent != null ? intent.getAction() : "";
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            return;
        }

        final SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        final String deviceId = p.getString("telegram_device_id", "hp 1").trim();
        final boolean gateway = "hp 1".equalsIgnoreCase(deviceId)
                || "hp1".equalsIgnoreCase(deviceId);
        // Keep the role authoritative and per-device. HP 2 never polls Telegram.
        p.edit().putBoolean("telegram_gateway", gateway).apply();

        final boolean botEnabled = gateway
                && p.getBoolean("telegram_bot_enabled", false)
                && !p.getString("telegram_bot_token", "").trim().isEmpty()
                && !p.getString("telegram_chat_id", "").trim().isEmpty();
        if (botEnabled) {
            startServiceSafely(context, TelegramBotService.class,
                    TelegramBotService.ACTION_START, "Telegram Gateway");
        } else {
            Log.i(TAG, "Telegram polling dilewati (Worker atau konfigurasi bot belum aktif).");
        }

        final boolean receiverEnabled = p.getBoolean("enabled", false);
        // Backward-compatible: installations created before V47 use `enabled`
        // as their opt-in. New installs persist the explicit auto-start flag.
        final boolean autoStart = p.getBoolean("auto_start_after_boot", receiverEnabled);
        if (!receiverEnabled || !autoStart) {
            Log.i(TAG, "Auto-start Receiver tidak aktif; tidak memulai NtfyService.");
            return;
        }

        final String server = p.getString("server", "https://ntfy.sh").trim();
        final String topic = p.getString("topic", "").trim();
        if (server.isEmpty() || topic.isEmpty()) {
            Log.e(TAG, "Auto-start dibatalkan: server/topic belum lengkap.");
            return;
        }

        startServiceSafely(context, NtfyService.class,
                NtfyService.ACTION_START, "DANA Receiver");
    }

    private static void startServiceSafely(Context context, Class<?> serviceClass,
                                           String action, String label) {
        try {
            Intent service = new Intent(context, serviceClass);
            service.setAction(action);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
            Log.i(TAG, label + " diminta berjalan otomatis setelah boot atau update manual yang sudah disetujui.");
        } catch (Exception e) {
            // Android/OEM may block background startup. Keep the failure visible
            // in logcat instead of crashing the boot broadcast receiver.
            Log.e(TAG, "Gagal memulai " + label + " setelah boot/update manual", e);
        }
    }
}
